package com.elarion.player

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// =====================================================================
//  LAYAR "TENTANG ELARION"
//  Berdiri sendiri: background, font, dan warna TIDAK ikut pilihan pengguna.
//  Untuk mengubah nama / tautan / daftar alat, cukup edit konstanta & teks di bawah.
// =====================================================================
private const val AUTHOR = "luckypen012-droid"
private const val GITHUB_URL = "https://github.com/luckypen012-droid/Media-player"
private const val GITHUB_SHOW = "github.com/luckypen012-droid/Media-player"
private const val YEAR = "2026"

private val Gold = Color(0xFFD8B76B)
private val GoldLight = Color(0xFFE8CB86)
private val GoldName = Color(0xFFF4E3B5)
private val Ivory = Color(0xFFF2EAD8)
private val IvorySoft = Color(0xFFCDBF9D)
private val Night = Color(0xFF05030F)

private val CinzelFam = FontFamily(
    Font(R.font.cinzel_regular, FontWeight.Normal), Font(R.font.cinzel_bold, FontWeight.Bold)
)
private val SerifFam = FontFamily(
    Font(R.font.ptserif_regular, FontWeight.Normal), Font(R.font.ptserif_bold, FontWeight.Bold)
)

@Composable
private fun AboutCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xCD0A0618))
            .border(1.dp, Gold.copy(alpha = 0.92f), shape).padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            title, fontFamily = CinzelFam, fontWeight = FontWeight.Bold, fontSize = 12.sp,
            letterSpacing = 3.sp, color = Gold, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun AboutLine(text: String, soft: Boolean = false) {
    Text(
        text, fontFamily = SerifFam, fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
        color = if (soft) IvorySoft else Ivory, modifier = Modifier.padding(vertical = 3.dp)
    )
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)

    // Status bar & nav bar menjadi gelap selama layar ini terbuka, lalu kembali ke warna background pilihan pengguna
    DisposableEffect(Unit) {
        val w = (ctx as? Activity)?.window
        val ctl = w?.let { WindowCompat.getInsetsController(it, it.decorView) }
        val dark = Color(0xFF080519).toArgb()
        w?.statusBarColor = dark
        w?.navigationBarColor = dark
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            val e = BgSample.edges(ctx, ThemeStore.bg.res)
            w?.statusBarColor = e.first.toArgb()
            w?.navigationBarColor = e.second.toArgb()
            ctl?.isAppearanceLightStatusBars = e.first.luminance() > 0.5f
            ctl?.isAppearanceLightNavigationBars = e.second.luminance() > 0.5f
        }
    }

    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }
    }

    Box(
        Modifier.fillMaxSize().background(Night)
            .pointerInput(Unit) { detectTapGestures { } }   // cegah ketukan tembus ke layar di bawahnya
    ) {
        Image(
            painter = painterResource(R.drawable.bg_elarion), contentDescription = null,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Night.copy(alpha = 0.69f)))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Night.copy(alpha = 0.43f)))
            )
        )

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(36.dp))

            // Logo bercahaya
            val logoShape = RoundedCornerShape(26.dp)
            Image(
                painter = painterResource(R.drawable.elarion_logo), contentDescription = "Elarion",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(96.dp)
                    .shadow(24.dp, logoShape, ambientColor = Gold, spotColor = Gold)
                    .clip(logoShape).border(1.5.dp, Gold, logoShape)
            )
            Spacer(Modifier.height(18.dp))

            Text(
                "ELARION", fontFamily = CinzelFam, fontWeight = FontWeight.Bold, fontSize = 34.sp,
                letterSpacing = 8.sp, color = GoldLight
            )
            Spacer(Modifier.height(10.dp))

            // Ornamen garis + berlian
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 40.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f).height(1.dp).background(Gold.copy(alpha = 0.65f)))
                Box(Modifier.padding(horizontal = 12.dp).size(8.dp).rotate(45f).background(Gold))
                Box(Modifier.weight(1f).height(1.dp).background(Gold.copy(alpha = 0.65f)))
            }
            Spacer(Modifier.height(10.dp))
            Text(
                if (version.isNotBlank()) "Versi $version   •   100% offline" else "100% offline",
                fontFamily = SerifFam, fontSize = 13.sp, color = IvorySoft
            )
            Spacer(Modifier.height(22.dp))

            AboutCard("DIBUAT OLEH") {
                Text(
                    AUTHOR, fontFamily = CinzelFam, fontWeight = FontWeight.Bold, fontSize = 22.sp,
                    color = GoldName, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                AboutLine("Perancang, penentu fitur, dan penguji")
                Text(
                    GITHUB_SHOW, fontFamily = SerifFam, fontSize = 13.sp, color = Gold,
                    textDecoration = TextDecoration.Underline, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp).clickable {
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(GITHUB_URL))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Throwable) { }
                    }
                )
            }
            Spacer(Modifier.height(14.dp))

            AboutCard("DIBANTU OLEH AI") {
                AboutLine("Claude")
                AboutLine("ChatGPT")
            }
            Spacer(Modifier.height(14.dp))

            AboutCard("DIBANGUN DENGAN") {
                AboutLine("Kotlin  •  Android SDK  •  Jetpack Compose  •  Material 3")
                AboutLine("Media3 / ExoPlayer  •  Gradle  •  JDK 17  •  GitHub Actions")
                AboutLine("Python  •  Pillow  •  NumPy  •  fontTools")
                AboutLine("Font: Nunito  •  Poppins  •  PT Serif  •  JetBrains Mono  •  Cinzel")
                AboutLine("Library berlisensi Apache 2.0, font berlisensi SIL OFL", soft = true)
            }
            Spacer(Modifier.height(22.dp))

            Text(
                "© $YEAR $AUTHOR   •   Lisensi MIT", fontFamily = SerifFam, fontSize = 13.sp,
                color = IvorySoft, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
        }

        // Tombol kembali
        Box(
            Modifier.padding(start = 14.dp, top = 12.dp).size(40.dp).clip(CircleShape)
                .border(1.5.dp, Gold.copy(alpha = 0.8f), CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { Icon24(Ic.ChevronDown, Gold, Modifier.rotate(90f), size = 22.dp) }
    }
}
