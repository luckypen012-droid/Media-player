package com.elarion.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// =====================================================================
//  DAFTAR BACKGROUND
//  CARA MENAMBAH BACKGROUND SENDIRI (cukup 2 langkah):
//   1) Taruh gambar 1080x2400 (PNG/JPG/WEBP, tanpa elemen aplikasi) di
//      app/src/main/res/drawable-nodpi/  dengan nama huruf kecil/angka/garis bawah, mis. bg_pantai.webp
//   2) Tambah SATU baris di daftar Backgrounds di bawah.
//  cardLight = keburaman kartu terang (0..1) bila teks gelap; makin terang gambarnya, makin kecil.
//  Warna status bar & nav bar diambil otomatis dari gambar.
// =====================================================================
data class BgOption(
    val id: String,
    val name: String,
    val res: Int,
    val cardLight: Float = 0.70f,
    val cardDark: Float = 0.62f,
)

val Backgrounds = listOf(
    BgOption("nebula", "Nebula violet", R.drawable.bg_main, cardLight = 0.45f),
    BgOption("senja", "Senja", R.drawable.bg_senja, cardLight = 0.55f),
    BgOption("laut", "Laut malam", R.drawable.bg_laut, cardLight = 0.68f),
    BgOption("hutan", "Hutan berkabut", R.drawable.bg_hutan, cardLight = 0.62f),
    BgOption("hitam", "Hitam polos", R.drawable.bg_hitam, cardLight = 0.82f, cardDark = 0.92f),
)

// =====================================================================
//  DAFTAR FONT (semua berlisensi SIL Open Font License, dikemas di res/font)
//  Huruf Jepang/Mandarin dll. otomatis memakai font sistem.
// =====================================================================
data class FontOpt(val id: String, val name: String, val desc: String, val family: FontFamily?)

private fun fam(regular: Int, bold: Int) =
    FontFamily(Font(regular, FontWeight.Normal), Font(bold, FontWeight.Bold))

val Fonts = listOf(
    FontOpt("sistem", "Bawaan", "Font bawaan HP", null),
    FontOpt("inter", "Inter", "Bersih & netral", fam(R.font.inter_regular, R.font.inter_bold)),
    FontOpt("nunito", "Nunito", "Membulat & ramah", fam(R.font.nunito_regular, R.font.nunito_bold)),
    FontOpt("poppins", "Poppins", "Modern & geometris", fam(R.font.poppins_regular, R.font.poppins_bold)),
    FontOpt("ptserif", "PT Serif", "Klasik berkait", fam(R.font.ptserif_regular, R.font.ptserif_bold)),
    FontOpt("jbmono", "JetBrains Mono", "Teknis, angka jelas", fam(R.font.jbmono_regular, R.font.jbmono_bold)),
)

// =====================================================================
//  PALET WARNA TEKS (satu pilihan). Terang -> kartu gelap, gelap -> kartu terang.
// =====================================================================
data class TextOpt(val id: String, val name: String, val color: Color)

val TextPalette = listOf(
    TextOpt("tinta", "Tinta (bawaan)", InkDark),
    TextOpt("malam", "Biru malam", Color(0xFF0F2A47)),
    TextOpt("putih", "Putih", Color.White),
    TextOpt("krem", "Krem", Color(0xFFF6EBD3)),
    TextOpt("lavender", "Lavender", Color(0xFFD9CCFF)),
    TextOpt("es", "Biru es", Color(0xFFBFE6FF)),
    TextOpt("mint", "Mint", Color(0xFFC6F5DE)),
    TextOpt("emas", "Emas", Color(0xFFFFD98A)),
)

private const val DEF_BG = "nebula"
private const val DEF_FONT = "sistem"
private const val DEF_TEXT = "tinta"

/** Pilihan tampilan: disimpan di SharedPreferences "elarion" (theme_bg, theme_font, theme_text). */
object ThemeStore {
    var bgId by mutableStateOf(DEF_BG)
        private set
    var fontId by mutableStateOf(DEF_FONT)
        private set
    var textId by mutableStateOf(DEF_TEXT)
        private set

    val bg: BgOption get() = Backgrounds.firstOrNull { it.id == bgId } ?: Backgrounds.first()
    val font: FontOpt get() = Fonts.firstOrNull { it.id == fontId } ?: Fonts.first()
    val textColor: Color get() = TextPalette.firstOrNull { it.id == textId }?.color ?: InkDark

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("elarion", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        bgId = p.getString("theme_bg", DEF_BG) ?: DEF_BG
        fontId = p.getString("theme_font", DEF_FONT) ?: DEF_FONT
        textId = p.getString("theme_text", DEF_TEXT) ?: DEF_TEXT
    }

    fun setBg(ctx: Context, id: String) { bgId = id; prefs(ctx).edit().putString("theme_bg", id).apply() }
    fun setFont(ctx: Context, id: String) { fontId = id; prefs(ctx).edit().putString("theme_font", id).apply() }
    fun setText(ctx: Context, id: String) { textId = id; prefs(ctx).edit().putString("theme_text", id).apply() }

    fun reset(ctx: Context) {
        bgId = DEF_BG; fontId = DEF_FONT; textId = DEF_TEXT
        prefs(ctx).edit().remove("theme_bg").remove("theme_font").remove("theme_text").apply()
    }
}

/** Membaca gambar background dalam ukuran kecil: warna tepi atas/bawah (status bar & nav bar) dan pratinjau. */
object BgSample {
    private val edgeCache = ConcurrentHashMap<Int, Pair<Color, Color>>()
    private val smallCache = ConcurrentHashMap<Int, Bitmap>()

    /** Pasangan (warna tepi atas, warna tepi bawah) dari gambar. */
    fun edges(ctx: Context, res: Int): Pair<Color, Color> {
        edgeCache[res]?.let { return it }
        val b = try {
            BitmapFactory.decodeResource(ctx.resources, res, BitmapFactory.Options().apply { inSampleSize = 16 })
        } catch (_: Throwable) { null }
        val r = if (b == null) Pair(Color.Black, Color.Black) else {
            val band = maxOf(1, (b.height * 0.05f).toInt())
            Pair(avg(b, 0, band), avg(b, b.height - band, b.height))
        }
        edgeCache[res] = r
        return r
    }

    private fun avg(b: Bitmap, y0: Int, y1: Int): Color {
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        for (y in y0 until y1) for (x in 0 until b.width) {
            val p = b.getPixel(x, y)
            r += ((p shr 16) and 0xFF).toLong(); g += ((p shr 8) and 0xFF).toLong(); bl += (p and 0xFF).toLong(); n++
        }
        if (n == 0L) return Color.Black
        return Color(android.graphics.Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt()))
    }

    /** Pratinjau kecil (hemat memori) untuk kotak pilihan background. */
    fun small(ctx: Context, res: Int, reqW: Int = 220): Bitmap? {
        smallCache[res]?.let { return it }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeResource(ctx.resources, res, o)
        var s = 1
        while (o.outWidth / (s * 2) >= reqW) s *= 2
        val b = try {
            BitmapFactory.decodeResource(ctx.resources, res, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (_: Throwable) { null }
        if (b != null) smallCache[res] = b
        return b
    }
}

// =====================================================================
//  LAYAR "TAMPILAN" (menu bawah ke-4)
// =====================================================================
@Composable
private fun SectionTitle(text: String) {
    val el = LocalEl.current
    Text(
        text, fontWeight = FontWeight.Bold, color = el.text,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(el.card)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    val el = LocalEl.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(el.card).padding(14.dp),
        content = content
    )
}

@Composable
private fun BgTile(o: BgOption, selected: Boolean, onClick: () -> Unit) {
    val el = LocalEl.current
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, o.res) {
        value = withContext(Dispatchers.IO) { BgSample.small(ctx, o.res) }
    }
    Column(Modifier.width(78.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        val shape = RoundedCornerShape(14.dp)
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.45f).clip(shape).background(Color(0xFF222222))
                .border(if (selected) 3.dp else 1.dp, if (selected) el.accent else Color(0x55808080), shape)
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    bitmap = b.asImageBitmap(), contentDescription = o.name,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(5.dp).size(22.dp)
                        .clip(CircleShape).background(el.accentFill),
                    contentAlignment = Alignment.Center
                ) { Icon24(Ic.Check, Color.White, size = 14.dp) }
            }
        }
        Text(
            o.name, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2, color = el.text,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun ColorDot(t: TextOpt, selected: Boolean, onClick: () -> Unit) {
    val el = LocalEl.current
    Column(Modifier.width(66.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(t.color)
                .border(if (selected) 3.dp else 1.5.dp, if (selected) el.accent else Color(0x66808080), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Icon24(Ic.Check, if (t.color.luminance() > 0.5f) InkDark else Color.White, size = 22.dp)
        }
        Text(
            t.name, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2, color = el.text,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun ThemeScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val el = LocalEl.current

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // ---- Background ----
        SectionTitle("Background")
        SectionCard {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Backgrounds.forEach { o ->
                    BgTile(o, o.id == ThemeStore.bgId) { ThemeStore.setBg(ctx, o.id) }
                }
            }
        }

        // ---- Font ----
        SectionTitle("Font")
        SectionCard {
            Fonts.forEach { f ->
                val sel = f.id == ThemeStore.fontId
                val sample = f.family ?: FontFamily.Default
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) el.accent.copy(alpha = 0.22f) else Color.Transparent)
                        .clickable { ThemeStore.setFont(ctx, f.id) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, fontFamily = sample, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = el.text)
                        Text(f.desc, fontSize = 12.sp, color = el.textSoft)
                    }
                    Text("Aa 0123", fontFamily = sample, fontSize = 18.sp, color = el.text)
                    if (sel) {
                        Spacer(Modifier.width(10.dp))
                        Icon24(Ic.Check, el.accent, size = 20.dp)
                    }
                }
            }
        }

        // ---- Warna teks ----
        SectionTitle("Warna teks")
        SectionCard {
            TextPalette.chunked(4).forEach { rowItems ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
                    rowItems.forEach { t -> ColorDot(t, t.id == ThemeStore.textId) { ThemeStore.setText(ctx, t.id) } }
                    repeat(4 - rowItems.size) { Spacer(Modifier.width(66.dp)) }
                }
            }
        }

        Button(
            onClick = {
                ThemeStore.reset(ctx)
                Toast.makeText(ctx, "Tampilan dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Color.White)
        ) { Text("Kembalikan ke bawaan") }
        Spacer(Modifier.height(6.dp))
    }
}
