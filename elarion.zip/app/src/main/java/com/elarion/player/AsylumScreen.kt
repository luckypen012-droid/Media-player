@file:OptIn(ExperimentalFoundationApi::class)

package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MIN_PIN = 4
private const val MAX_PIN = 12
/** Setelah keluar dari aplikasi lebih lama dari ini, Asylum terkunci lagi. */
private const val AUTO_LOCK_MS = 15_000L

object AsylumSession { var internalLeave = false }

// =====================================================================
//  Sidik jari
//  Android 9+: BiometricPrompt bawaan sistem (jendelanya diatur sistem, hanya teksnya yang kita isi).
//  Android 8: FingerprintManager langsung. Tombol di jendela mengembalikan ke papan angka Elarion.
// =====================================================================
@Suppress("DEPRECATION")
private fun legacyFingerReady(ctx: Context): Boolean = try {
    val fm = ctx.getSystemService(android.hardware.fingerprint.FingerprintManager::class.java)
    fm != null && fm.isHardwareDetected && fm.hasEnrolledFingerprints()
} catch (e: Throwable) { false }

private fun bioAvailable(ctx: Context) = legacyFingerReady(ctx)

private const val BIO_TITLE = "◈ Gerbang Asylum ◈"
private const val BIO_SUBTITLE = "Setiap rahasia punya rumahnya"
private const val BIO_DESC = "Hanya jarimu yang punya kunci ke ruang ini"
private const val BIO_NEGATIVE = "Masukkan kata sandi"

private class FingerSession(
    val ctx: Context,
    val onOk: () -> Unit,
    val onHint: (String) -> Unit,
    val onStopped: (String?) -> Unit,
) {
    private var cancel: android.os.CancellationSignal? = null

    fun start(): Boolean {
        if (cancel != null) return true
        return try {
            if (Build.VERSION.SDK_INT >= 28) startPrompt() else startLegacy()
        } catch (e: Throwable) {
            cancel = null
            false
        }
    }

    @androidx.annotation.RequiresApi(28)
    private fun startPrompt(): Boolean {
        val sig = android.os.CancellationSignal()
        val exec = ctx.mainExecutor
        val prompt = android.hardware.biometrics.BiometricPrompt.Builder(ctx)
            .setTitle(BIO_TITLE)
            .setSubtitle(BIO_SUBTITLE)
            .setDescription(BIO_DESC)
            .setNegativeButton(BIO_NEGATIVE, exec) { _, _ -> }
            .build()
        prompt.authenticate(sig, exec, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                cancel = null; onOk()
            }
            override fun onAuthenticationFailed() { onHint("Sidik jari tidak dikenali, coba lagi") }
            override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                if (helpString != null) onHint(helpString.toString())
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                if (sig.isCanceled) return
                cancel = null
                // 5 = dibatalkan sistem, 10 = ditutup pengguna, 13 = tombol "Masukkan kata sandi"
                if (errorCode == 5 || errorCode == 10 || errorCode == 13) onStopped(null)
                else onStopped(errString?.toString())
            }
        })
        cancel = sig
        return true
    }

    @Suppress("DEPRECATION")
    private fun startLegacy(): Boolean {
        val fm = ctx.getSystemService(android.hardware.fingerprint.FingerprintManager::class.java) ?: return false
        if (!fm.isHardwareDetected || !fm.hasEnrolledFingerprints()) return false
        val sig = android.os.CancellationSignal()
        fm.authenticate(null, sig, 0, object : android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: android.hardware.fingerprint.FingerprintManager.AuthenticationResult?) {
                cancel = null; onOk()
            }
            override fun onAuthenticationFailed() { onHint("Sidik jari tidak dikenali, coba lagi") }
            override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                if (helpString != null) onHint(helpString.toString())
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                if (!sig.isCanceled) { cancel = null; onStopped(errString?.toString()) }
            }
        }, null)
        cancel = sig
        return true
    }

    fun stop() {
        try { cancel?.cancel() } catch (_: Throwable) {}
        cancel = null
    }
}

// =====================================================================
//  Latar & papan angka
// =====================================================================
@Composable
private fun AsyBackground(res: Int) {
    Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
}

/** Getaran pendek tiap tombol keypad ditekan. Izin VIBRATE sudah ada di manifest. */
@Suppress("DEPRECATION")
private fun buzz(ctx: Context, view: android.view.View, ms: Long) {
    try {
        val vib = ctx.getSystemService(Vibrator::class.java)
        if (vib != null && vib.hasVibrator()) {
            vib.vibrate(VibrationEffect.createOneShot(ms, 160))
            return
        }
    } catch (_: Throwable) {}
    try { view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP) } catch (_: Throwable) {}
}

// Kartu keypad: kaca ungu tua tetap (tidak ikut warna teks tema) supaya angka putih selalu jelas
// di atas latar ungu Elarion maupun latar tema lain. Saat ditekan, kartu menyala keunguan.
private val KeyTop = Color(0xFF3A2C72)
private val KeyBottom = Color(0xFF211842)
private val KeyTopOn = Color(0xFF6A52D6)
private val KeyBottomOn = Color(0xFF4A38A8)
private val KeyRim = Color(0xFFCDBEFF)
private val KeyInk = Color(0xFFF4F0FF)

@Composable
private fun Key(label: String? = null, ic: Ic? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val top = if (pressed) KeyTopOn else KeyTop
    val bottom = if (pressed) KeyBottomOn else KeyBottom
    Box(
        Modifier.size(66.dp).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(top.copy(alpha = 0.86f), bottom.copy(alpha = 0.90f))))
            .border(1.dp, KeyRim.copy(alpha = if (pressed) 0.75f else 0.38f), CircleShape)
            .alpha(if (enabled) 1f else 0.38f)
            .clickable(interactionSource = src, indication = null, enabled = enabled) {
                buzz(ctx, view, if (ic == Ic.Check) 35L else 20L)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        if (label != null) Text(label, fontSize = 26.sp, fontWeight = FontWeight.Light, color = KeyInk)
        else if (ic != null) Icon24(ic, KeyInk, size = 24.dp)
    }
}

/** Bintang empat sudut sebagai lambang di layar kunci. */
@Composable
private fun StarMark(color: Color, side: Dp) {
    Canvas(Modifier.size(side)) {
        val w = this.size.width
        val c = w / 2f
        val k = w * 0.1f
        val path = Path()
        path.moveTo(c, 0f)
        path.quadraticBezierTo(c + k, c - k, w, c)
        path.quadraticBezierTo(c + k, c + k, c, w)
        path.quadraticBezierTo(c - k, c + k, 0f, c)
        path.quadraticBezierTo(c - k, c - k, c, 0f)
        path.close()
        drawPath(path, color)
    }
}

private val FP_SIZE = 76.dp

/**
 * Letak PUSAT ikon sidik jari diukur dari tepi bawah layar fisik, sebagai pecahan tinggi layar.
 * Ini perkiraan untuk sensor di bawah layar (bawah-tengah). Kalau ikon belum pas di atas sensor,
 * ubah angka ini: lebih besar = ikon naik, lebih kecil = ikon turun.
 */
private const val FP_CENTER_FROM_BOTTOM = 0.115f

@Composable
private fun PinPad(
    title: String, subtitle: String, error: String?, confirmLabel: String, resetKey: Int,
    fingerShown: Boolean = false, fingerHint: String = "", fingerScanning: Boolean = false,
    onFinger: () -> Unit = {},
    footer: @Composable () -> Unit = {},
    onSubmit: (String) -> Unit,
) {
    val el = LocalEl.current
    val view = LocalView.current
    val density = LocalDensity.current
    var pin by remember(resetKey) { mutableStateOf("") }
    var fpPx by remember { mutableFloatStateOf(-1f) }
    BoxWithConstraints(
        Modifier.fillMaxSize().onGloballyPositioned { c ->
            val rootH = view.rootView.height
            val bottom = c.positionInWindow().y + c.size.height
            fpPx = rootH * FP_CENTER_FROM_BOTTOM - (rootH - bottom)
        }
    ) {
        val centerFromBottom: Dp =
            if (fpPx < 0f) maxHeight * FP_CENTER_FROM_BOTTOM else with(density) { fpPx.toDp() }
        val fpBottom: Dp = maxOf(0.dp, centerFromBottom - FP_SIZE / 2)
        val reserve: Dp = if (fingerShown) fpBottom + FP_SIZE + 30.dp else 12.dp

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(start = 32.dp, end = 32.dp, top = 28.dp, bottom = reserve),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StarMark(el.accent, 50.dp)
            Spacer(Modifier.height(10.dp))
            Text("ELARION", color = el.accent, fontSize = 20.sp, letterSpacing = 8.sp)
            Spacer(Modifier.height(24.dp))
            Text(title, color = el.text, fontSize = 17.sp, textAlign = TextAlign.Center)
            if (subtitle.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = el.textSoft, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(16.dp))
            val many = pin.length > 8
            Row(
                Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(if (many) 8.dp else 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(maxOf(6, pin.length)) { i ->
                    Box(
                        Modifier.size(if (many) 11.dp else 13.dp).clip(CircleShape).then(
                            if (i < pin.length) Modifier.background(el.accent)
                            else Modifier.border(1.5.dp, el.textSoft, CircleShape)
                        )
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(error ?: " ", color = el.danger, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { r ->
                Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
                    r.forEach { d -> Key(d) { if (pin.length < MAX_PIN) pin += d } }
                }
                Spacer(Modifier.height(14.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
                Key(ic = Ic.Check, enabled = pin.length >= MIN_PIN) { onSubmit(pin) }
                Key("0") { if (pin.length < MAX_PIN) pin += "0" }
                Key(ic = Ic.Backspace, enabled = pin.isNotEmpty()) { pin = pin.dropLast(1) }
            }
            Spacer(Modifier.height(8.dp))
            footer()
        }

        // Ikon sidik jari: tepat di atas sensor di bawah layar, langsung dipindai (tanpa jendela sistem)
        if (fingerShown) {
            val pulse by rememberInfiniteTransition(label = "fp").animateFloat(
                initialValue = 0.35f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "fpa"
            )
            Text(
                fingerHint, color = el.textSoft, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = fpBottom + FP_SIZE + 6.dp)
            )
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = fpBottom).size(FP_SIZE)
                    .clip(CircleShape).background(el.accent.copy(alpha = 0.12f))
                    .border(1.5.dp, el.accent.copy(alpha = if (fingerScanning) 0.3f + 0.55f * pulse else 0.35f), CircleShape)
                    .clickable(onClick = onFinger),
                contentAlignment = Alignment.Center
            ) {
                Icon24(Ic.Fingerprint, if (fingerScanning) el.accent else el.textSoft, size = 44.dp)
            }
        }
    }
}

@Composable
private fun SetupPin(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var first by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }
    var askBio by remember { mutableStateOf(false) }
    val canBio = remember { bioAvailable(ctx) }
    PinPad(
        title = if (first == null) "Buat kata sandi" else "Ulangi kata sandi",
        subtitle = if (first == null) "4–12 angka, lalu ketuk tanda centang. Jika lupa, isi Asylum tidak bisa dibuka lagi."
        else "Ketik sekali lagi untuk memastikan",
        error = err, confirmLabel = if (first == null) "Lanjut" else "Simpan", resetKey = reset
    ) { pin ->
        val f = first
        if (f == null) { first = pin; err = null; reset++ }
        else if (f == pin) {
            AsylumAuth.setPin(ctx, pin)
            if (canBio) askBio = true else onDone()
        } else { first = null; err = "Tidak sama, ulangi dari awal"; reset++ }
    }
    if (askBio) AlertDialog(
        onDismissRequest = {}, containerColor = PanelColor,
        title = { Text("Pakai sidik jari?") },
        text = { Text("Kamu bisa membuka Elarion Asylum langsung dengan sidik jari. Kata sandi tetap dipakai sebagai cadangan.") },
        confirmButton = { TextButton(onClick = { AsylumAuth.setBio(ctx, true); onDone() }) { Text("Aktifkan") } },
        dismissButton = { TextButton(onClick = { onDone() }) { Text("Nanti") } }
    )
}

@Composable
private fun LockPad(onUnlocked: () -> Unit, onForgot: () -> Unit) {
    val ctx = LocalContext.current
    val el = LocalEl.current
    val owner = LocalLifecycleOwner.current
    val unlock by rememberUpdatedState(onUnlocked)
    val bioWanted = remember { AsylumAuth.bioOn(ctx) }
    val legacyOk = remember { bioWanted && legacyFingerReady(ctx) }
    var scanning by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("Sentuh sensor sidik jari") }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }

    val session = remember {
        FingerSession(
            ctx,
            onOk = { unlock() },
            onHint = { hint = it },
            onStopped = { m ->
                scanning = false
                hint = if (m == null) "Ketik kata sandi, atau ketuk ikon untuk sidik jari"
                else "$m. Ketuk ikon untuk mencoba lagi."
            }
        )
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START && legacyOk) {
                scanning = session.start()
                if (scanning) hint = "Sentuh sensor sidik jari"
            }
            if (e == Lifecycle.Event.ON_STOP) { session.stop(); scanning = false }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); session.stop() }
    }

    PinPad(
        title = "Masukkan kata sandi", subtitle = "", error = err,
        confirmLabel = "Buka", resetKey = reset,
        fingerShown = legacyOk, fingerHint = hint, fingerScanning = scanning,
        onFinger = {
            if (legacyOk && !scanning) { scanning = session.start(); if (scanning) hint = "Sentuh sensor sidik jari" }
        },
        footer = { TextButton(onClick = onForgot) { Text("Lupa kata sandi?", color = el.text) } }
    ) { pin ->
        val wait = AsylumAuth.lockedSeconds(ctx)
        if (wait > 0) {
            err = "Terlalu banyak salah. Coba lagi dalam $wait detik."; reset++
        } else if (AsylumAuth.verify(ctx, pin)) {
            onUnlocked()
        } else {
            val w = AsylumAuth.lockedSeconds(ctx)
            err = if (w > 0) "Terlalu banyak salah. Coba lagi dalam $w detik." else "Kata sandi salah"
            reset++
        }
    }
}

@Composable
private fun ChangePin(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val el = LocalEl.current
    var stage by remember { mutableIntStateOf(0) }
    var newPin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().pointerInput(Unit) {}) {
        AsyBackground(ThemeStore.bg.res)
        PinPad(
            title = when (stage) { 0 -> "Kata sandi lama"; 1 -> "Kata sandi baru"; else -> "Ulangi kata sandi baru" },
            subtitle = "", error = err, confirmLabel = if (stage == 2) "Simpan" else "Lanjut",
            resetKey = reset,
            footer = { TextButton(onClick = onClose) { Text("Batal", color = el.text) } }
        ) { pin ->
            reset++
            if (stage == 0) {
                if (AsylumAuth.lockedSeconds(ctx) > 0) {
                    err = "Terlalu banyak salah. Coba lagi nanti."
                } else if (AsylumAuth.verify(ctx, pin)) {
                    stage = 1; err = null
                } else {
                    err = "Kata sandi salah"
                }
            } else if (stage == 1) {
                newPin = pin; stage = 2; err = null
            } else {
                if (pin == newPin) {
                    AsylumAuth.setPin(ctx, pin)
                    Toast.makeText(ctx, "Kata sandi diganti", Toast.LENGTH_SHORT).show()
                    onClose()
                } else {
                    stage = 1; err = "Tidak sama, ulangi"
                }
            }
        }
    }
}

// =====================================================================
//  Layar utama Asylum
// =====================================================================
@Composable
fun AsylumScreen(onBack: () -> Unit, preselect: Set<String> = emptySet()) {
    val ctx = LocalContext.current
    val el = LocalEl.current
    remember { AsylumStore.load(ctx); true }
    var hasPin by remember { mutableStateOf(AsylumAuth.hasPin(ctx)) }
    var unlocked by remember { mutableStateOf(false) }
    var forgot by remember { mutableStateOf(false) }
    var blockShot by remember { mutableStateOf(AsylumAuth.blockShot(ctx)) }
    val inRoom = hasPin && unlocked
    val bgRes = if (inRoom) R.drawable.asylum_bg else ThemeStore.bg.res

    // Warna bilah sistem mengikuti latar; larangan screenshot sesuai pengaturan
    val window = (ctx as? Activity)?.window
    DisposableEffect(window) {
        val w = window ?: return@DisposableEffect onDispose {}
        val oldS = w.statusBarColor
        val oldN = w.navigationBarColor
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        val oldLightS = ctl.isAppearanceLightStatusBars
        val oldLightN = ctl.isAppearanceLightNavigationBars
        onDispose {
            w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            w.statusBarColor = oldS; w.navigationBarColor = oldN
            ctl.isAppearanceLightStatusBars = oldLightS; ctl.isAppearanceLightNavigationBars = oldLightN
        }
    }
    val edges = remember(bgRes) { BgSample.edges(ctx, bgRes) }
    SideEffect {
        val w = window ?: return@SideEffect
        if (blockShot) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        w.statusBarColor = edges.first.toArgb(); w.navigationBarColor = edges.second.toArgb()
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        ctl.isAppearanceLightStatusBars = edges.first.luminance() > 0.5f
        ctl.isAppearanceLightNavigationBars = edges.second.luminance() > 0.5f
    }

    // Kunci otomatis bila aplikasi ditinggalkan cukup lama (kecuali pindah ke pemutar video sendiri)
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var leftAt = 0L
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP) leftAt = SystemClock.elapsedRealtime()
            if (e == Lifecycle.Event.ON_START && leftAt > 0L) {
                val internal = AsylumSession.internalLeave
                AsylumSession.internalLeave = false
                if (!internal && SystemClock.elapsedRealtime() - leftAt > AUTO_LOCK_MS) unlocked = false
                leftAt = 0L
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().pointerInput(Unit) {}) {
        AsyBackground(bgRes)
        when {
            !hasPin -> SetupPin(onDone = { hasPin = true; unlocked = true })
            !unlocked -> LockPad(onUnlocked = { unlocked = true }, onForgot = { forgot = true })
            else -> Room(
                preselect, onExit = onBack, blockShot = blockShot,
                onBlockShot = { blockShot = it; AsylumAuth.setBlockShot(ctx, it) }
            )
        }
        if (!inRoom) {
            IconBtn(Ic.Close, onBack, Modifier.align(Alignment.TopStart).padding(8.dp), tint = el.text, bg = el.card, box = 40.dp, icon = 20.dp)
        }
    }

    if (forgot) AlertDialog(
        onDismissRequest = { forgot = false }, containerColor = PanelColor,
        title = { Text("Lupa kata sandi?") },
        text = {
            Text(
                "Demi keamanan, kata sandi tidak bisa dipulihkan. Satu-satunya jalan adalah mengatur ulang, " +
                    "dan itu akan MENGHAPUS PERMANEN semua foto dan video di dalam Elarion Asylum."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                AsylumStore.clearAll(ctx); hasPin = false; unlocked = false; forgot = false
            }) { Text("Hapus semua & atur ulang", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { forgot = false }) { Text("Batal") } }
    )
}

@Composable
private fun NameDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = PanelColor,
        title = { Text(title) },
        text = { OutlinedTextField(value = t, onValueChange = { t = it.take(40) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t) }) { Text(ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun InfoDialog(title: String, lines: List<Pair<String, String>>, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, containerColor = PanelColor,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                lines.forEach { (k, v) ->
                    Text(k, style = MaterialTheme.typography.labelMedium, color = InkSoft)
                    Text(v, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Tutup") } }
    )
}

private fun itemInfo(a: AsyItem, dims: Pair<Int, Int>?, folderName: String): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    out += "Nama file" to a.name
    out += "Jenis" to ((if (a.photo) "Foto" else "Video") + " • " + a.ext.uppercase())
    if (!a.photo) out += "Durasi" to fmt(a.durationMs)
    if (dims != null) out += "Resolusi" to (if (a.photo) "${dims.first} × ${dims.second} piksel" else resolutionLabel(dims.first, dims.second))
    out += "Ukuran" to fmtSize(a.size)
    if (!a.photo && a.durationMs > 0) out += "Perkiraan bitrate" to "${a.size * 8 / a.durationMs} kbps"
    out += "Masuk Asylum" to SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(a.added * 1000))
    out += "Folder" to folderName
    if (a.rel.isNotBlank()) out += "Lokasi asal" to a.rel
    return out
}

@Composable
private fun AsyNavItem(ic: Ic, label: String, selected: Boolean, onClick: () -> Unit) {
    val el = LocalEl.current
    Column(
        Modifier.width(92.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.width(56.dp).height(28.dp).clip(RoundedCornerShape(14.dp))
                .background(if (selected) el.navIndicator else Color.Transparent),
            contentAlignment = Alignment.Center
        ) { Icon24(ic, if (selected) el.accent else el.textSoft, size = 22.dp) }
        Text(label, fontSize = 11.sp, maxLines = 1, softWrap = false, color = if (selected) el.accent else el.textSoft)
    }
}

@Composable
private fun Room(preselect: Set<String>, onExit: () -> Unit, blockShot: Boolean, onBlockShot: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val el = LocalEl.current
    val store = AsylumStore
    var cur by remember { mutableStateOf("") }              // "" = Utama
    var tab by remember { mutableIntStateOf(0) }            // 0 video, 1 foto
    var listMode by remember { mutableStateOf(AsylumAuth.listMode(ctx)) }
    var selMode by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Set<String>>(emptySet()) }
    var picker by remember { mutableStateOf(preselect.isNotEmpty()) }
    var viewer by remember { mutableStateOf<Int?>(null) }
    var menu by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var renameF by remember { mutableStateOf<AsyFolder?>(null) }
    var deleteF by remember { mutableStateOf<AsyFolder?>(null) }
    var folderInfo by remember { mutableStateOf<AsyFolder?>(null) }
    var folderMenu by remember { mutableStateOf<String?>(null) }
    var itemMenu by remember { mutableStateOf<String?>(null) }
    var infoFor by remember { mutableStateOf<AsyItem?>(null) }
    var moveFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var deleteFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var restoreFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var changePin by remember { mutableStateOf(false) }
    var bioOn by remember { mutableStateOf(AsylumAuth.bioOn(ctx)) }
    val canBio = remember { bioAvailable(ctx) }

    fun exitSel() { selMode = false; sel = emptySet() }

    // ---- hapus file asli dari galeri (setelah berhasil disalin) ----
    var delQueue by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var legacyRetry by remember { mutableIntStateOf(0) }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (Build.VERSION.SDK_INT >= 30) {
            if (res.resultCode == Activity.RESULT_OK) {
                store.pendingOriginals = store.pendingOriginals - delQueue.toSet()
                store.lastMessage = "File asli sudah dihapus dari galeri."
            }
            delQueue = emptyList()
        } else {
            if (res.resultCode == Activity.RESULT_OK) legacyRetry++ else delQueue = emptyList()
        }
    }
    fun legacyDelete() {
        var q = delQueue
        while (q.isNotEmpty()) {
            val u = q.first()
            try {
                ctx.contentResolver.delete(u, null, null)
                store.pendingOriginals = store.pendingOriginals - u
                q = q.drop(1); delQueue = q
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    delQueue = q
                    delLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                    return
                }
                q = q.drop(1)
            } catch (e: Exception) { q = q.drop(1) }
        }
        delQueue = emptyList()
    }
    fun askDelete() {
        val list = store.pendingOriginals
        if (list.isEmpty()) return
        delQueue = list
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, list)
                delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) { delQueue = emptyList() }
        } else legacyDelete()
    }
    LaunchedEffect(legacyRetry) { if (legacyRetry > 0) legacyDelete() }
    LaunchedEffect(store.deleteTrigger) { if (store.deleteTrigger > 0 && delQueue.isEmpty()) askDelete() }
    LaunchedEffect(store.lastMessage) {
        store.lastMessage?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); store.lastMessage = null }
    }

    // ---- data yang tampil ----
    val all = store.items
    val here = all.filter { it.folder == cur }.sortedByDescending { it.added }
    val vids = here.filter { !it.photo }
    val pics = here.filter { it.photo }
    val shown = if (tab == 0) vids else pics
    val curFolder = store.folders.firstOrNull { it.id == cur }
    val selItems = all.filter { it.id in sel }

    BackHandler(enabled = cur != "") { cur = ""; exitSel() }
    BackHandler(enabled = selMode) { exitSel() }
    BackHandler(enabled = picker) { picker = false }
    BackHandler(enabled = viewer != null) { viewer = null }

    fun playVideo(i: Int) {
        val metas = vids.map { it.toMedia(ctx) }
        AsylumSession.internalLeave = true
        ctx.startActivity(
            Intent(ctx, VideoPlayerActivity::class.java).setData(metas[i].uri)
                .putStringArrayListExtra("playlist", ArrayList(metas.map { it.uri.toString() }))
                .putStringArrayListExtra("titles", ArrayList(vids.map { it.title }))
                .putExtra("index", i).putExtra("secure", true).putExtra("blockshot", blockShot)
        )
    }
    fun openItem(a: AsyItem) {
        if (selMode) { sel = if (a.id in sel) sel - a.id else sel + a.id }
        else if (a.photo) viewer = pics.indexOf(a)
        else playVideo(vids.indexOf(a))
    }

    // ---- potongan tampilan yang dipakai di kotak maupun daftar ----
    val itemMenuContent: @Composable (AsyItem) -> Unit = { a ->
        DropdownMenu(expanded = itemMenu == a.id, onDismissRequest = { itemMenu = null }) {
            DropdownMenuItem(
                text = { Text("Info") },
                leadingIcon = { Icon24(Ic.Info, LocalContentColor.current, size = 20.dp) },
                onClick = { itemMenu = null; infoFor = a })
            DropdownMenuItem(
                text = { Text("Pindahkan") },
                leadingIcon = { Icon24(Ic.Folder, LocalContentColor.current, size = 20.dp) },
                onClick = { itemMenu = null; moveFor = listOf(a) })
            DropdownMenuItem(
                text = { Text("Pulihkan") },
                leadingIcon = { Icon24(Ic.Restore, LocalContentColor.current, size = 20.dp) },
                onClick = { itemMenu = null; restoreFor = listOf(a) })
            DropdownMenuItem(
                text = { Text("Hapus", color = MaterialTheme.colorScheme.error) },
                leadingIcon = { Icon24(Ic.Trash, MaterialTheme.colorScheme.error, size = 20.dp) },
                onClick = { itemMenu = null; deleteFor = listOf(a) })
        }
    }

    val folderCard: @Composable (AsyFolder) -> Unit = { f ->
        val nv = all.count { it.folder == f.id && !it.photo }
        val np = all.count { it.folder == f.id && it.photo }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp))
                .background(el.card).clickable { cur = f.id; exitSel() }.padding(start = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon24(Ic.Folder, el.accent, size = 26.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp)) {
                Text(f.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$nv video • $np foto", style = MaterialTheme.typography.bodySmall, color = el.textSoft)
            }
            Box {
                IconBtn(Ic.More, { folderMenu = f.id }, tint = el.text, box = 44.dp, icon = 22.dp)
                DropdownMenu(expanded = folderMenu == f.id, onDismissRequest = { folderMenu = null }) {
                    DropdownMenuItem(
                        text = { Text("Info") },
                        leadingIcon = { Icon24(Ic.Info, LocalContentColor.current, size = 20.dp) },
                        onClick = { folderMenu = null; folderInfo = f })
                    DropdownMenuItem(text = { Text("Ubah nama") }, onClick = { folderMenu = null; renameF = f })
                    DropdownMenuItem(
                        text = { Text("Hapus folder", color = MaterialTheme.colorScheme.error) },
                        onClick = { folderMenu = null; deleteF = f })
                }
            }
        }
    }

    val gridCell: @Composable (AsyItem) -> Unit = { a ->
        val m = remember(a.id) { a.toMedia(ctx) }
        val on = a.id in sel
        Box(
            Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).combinedClickable(
                onClick = { openItem(a) },
                onLongClick = { selMode = true; sel = sel + a.id }
            )
        ) {
            Thumb(m, Modifier.fillMaxSize(), badge = if (a.photo) null else fmt(a.durationMs))
            if (selMode) {
                Box(Modifier.fillMaxSize().background(if (on) el.accentFill.copy(alpha = 0.35f) else Color.Transparent))
                Box(
                    Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape)
                        .background(if (on) el.accentFill else Color(0x66000000))
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) { if (on) Icon24(Ic.Check, Color.White, size = 14.dp) }
            } else {
                Box(Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(Color(0x73000000)).clickable { itemMenu = a.id },
                        contentAlignment = Alignment.Center
                    ) { Icon24(Ic.More, Color.White, size = 18.dp) }
                    itemMenuContent(a)
                }
            }
        }
    }

    val listRow: @Composable (AsyItem) -> Unit = { a ->
        val m = remember(a.id) { a.toMedia(ctx) }
        val on = a.id in sel
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp))
                .background(if (on) el.cardSel else el.card)
                .combinedClickable(onClick = { openItem(a) }, onLongClick = { selMode = true; sel = sel + a.id })
                .padding(start = 10.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selMode) {
                Checkbox(
                    checked = on, onCheckedChange = null,
                    colors = CheckboxDefaults.colors(checkedColor = el.accentFill, uncheckedColor = el.textSoft)
                )
                Spacer(Modifier.width(4.dp))
            }
            if (a.photo) Thumb(m, Modifier.size(62.dp))
            else Thumb(m, Modifier.width(104.dp).height(62.dp), badge = fmt(a.durationMs))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(a.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (a.photo) "Foto" else "Video") + " • " + fmtSize(a.size),
                    style = MaterialTheme.typography.bodySmall, color = el.textSoft
                )
            }
            if (!selMode) {
                Box {
                    IconBtn(Ic.More, { itemMenu = a.id }, tint = el.text, box = 44.dp, icon = 22.dp)
                    itemMenuContent(a)
                }
            } else Spacer(Modifier.width(16.dp))
        }
    }

    val emptyNote: @Composable () -> Unit = {
        Text(
            if (tab == 0) "Belum ada video di sini. Ketuk + di atas untuk memindahkan dari galeri."
            else "Belum ada foto di sini. Ketuk + di atas untuk memindahkan dari galeri.",
            Modifier.fillMaxWidth().padding(24.dp), color = el.textSoft, textAlign = TextAlign.Center
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ----- bilah atas -----
            if (selMode) {
                Row(
                    Modifier.fillMaxWidth().background(el.bar).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconBtn(Ic.Close, { exitSel() }, tint = el.text)
                    Text("${sel.size} dipilih", Modifier.weight(1f).padding(start = 4.dp), color = el.text, fontWeight = FontWeight.Bold)
                    TextButton(
                        onClick = {
                            val ids = shown.map { it.id }.toSet()
                            sel = if (ids.isNotEmpty() && ids.all { it in sel }) sel - ids else sel + ids
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = el.accent)
                    ) { Text("Pilih semua") }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    if (cur != "") IconBtn(Ic.ChevronDown, { cur = ""; exitSel() }, Modifier.rotate(90f), tint = el.text, bg = el.card, box = 40.dp, icon = 20.dp)
                    else IconBtn(Ic.Close, onExit, tint = el.text, bg = el.card, box = 40.dp, icon = 20.dp)
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(50)).background(el.card).padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            curFolder?.name ?: "Elarion Asylum", color = el.text, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    RoundBtn(if (listMode) Ic.Grid else Ic.Rows) {
                        listMode = !listMode; AsylumAuth.setListMode(ctx, listMode)
                    }
                    RoundBtn(Ic.Plus) {
                        if (store.busy) Toast.makeText(ctx, "Tunggu proses yang berjalan selesai", Toast.LENGTH_SHORT).show()
                        else picker = true
                    }
                    Box {
                        RoundBtn(Ic.More) { menu = true }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (cur == "") DropdownMenuItem(
                                text = { Text("Folder baru") },
                                leadingIcon = { Icon24(Ic.Folder, LocalContentColor.current, size = 20.dp) },
                                onClick = { menu = false; newFolder = true })
                            if (canBio) DropdownMenuItem(
                                text = { Text(if (bioOn) "Matikan sidik jari" else "Aktifkan sidik jari") },
                                leadingIcon = { Icon24(Ic.Fingerprint, LocalContentColor.current, size = 20.dp) },
                                onClick = { menu = false; bioOn = !bioOn; AsylumAuth.setBio(ctx, bioOn) })
                            DropdownMenuItem(
                                text = { Text("Ganti kata sandi") },
                                leadingIcon = { Icon24(Ic.Lock, LocalContentColor.current, size = 20.dp) },
                                onClick = { menu = false; changePin = true })
                            DropdownMenuItem(
                                text = { Text(if (blockShot) "Izinkan screenshot" else "Blokir screenshot") },
                                leadingIcon = { Icon24(Ic.Info, LocalContentColor.current, size = 20.dp) },
                                onClick = { menu = false; onBlockShot(!blockShot) })
                        }
                    }
                }
            }

            // ----- kartu proses -----
            if (store.busy) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp)).background(el.card).padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "${store.busyLabel} ${minOf(store.busyDone + 1, store.busyTotal)} dari ${store.busyTotal}",
                            Modifier.weight(1f), color = el.text, fontSize = 14.sp, fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = { store.cancelFlag = true }, colors = ButtonDefaults.textButtonColors(contentColor = el.accent)) { Text("Batal") }
                    }
                    Text(store.busyName, color = el.textSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { ((store.busyDone + store.busyFraction) / maxOf(1, store.busyTotal)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = el.accentFill, trackColor = el.bar
                    )
                    Text("Jangan tutup Elarion sampai selesai.", color = el.textSoft, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
            } else if (store.pendingOriginals.isNotEmpty() && delQueue.isEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp)).background(el.card).padding(start = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${store.pendingOriginals.size} file asli belum dihapus dari galeri.", Modifier.weight(1f), color = el.text, fontSize = 13.sp)
                    TextButton(onClick = { askDelete() }, colors = ButtonDefaults.textButtonColors(contentColor = el.accent)) { Text("Hapus") }
                }
            }

            // ----- isi -----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (listMode) {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        if (cur == "") items(store.folders, key = { "f" + it.id }) { f -> folderCard(f) }
                        if (shown.isEmpty()) item { emptyNote() }
                        items(shown, key = { it.id }) { a -> listRow(a) }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (cur == "") items(store.folders, key = { "f" + it.id }, span = { GridItemSpan(maxLineSpan) }) { f -> folderCard(f) }
                        if (shown.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { emptyNote() }
                        items(shown, key = { it.id }) { a -> gridCell(a) }
                    }
                }
            }

            // ----- bilah bawah -----
            if (selMode) {
                Row(Modifier.fillMaxWidth().background(el.bar)) {
                    ActionBtn(Ic.Folder, "Pindah", sel.isNotEmpty() && !store.busy, el.text, Modifier.weight(1f)) { moveFor = selItems }
                    ActionBtn(Ic.Restore, "Pulihkan", sel.isNotEmpty() && !store.busy, el.text, Modifier.weight(1f)) { restoreFor = selItems }
                    ActionBtn(Ic.Trash, "Hapus", sel.isNotEmpty() && !store.busy, el.danger, Modifier.weight(1f)) { deleteFor = selItems }
                }
            } else {
                Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
                    Row(
                        Modifier.clip(RoundedCornerShape(28.dp)).background(el.glass).padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AsyNavItem(Ic.Video, "Video ${vids.size}", tab == 0) { tab = 0; exitSel() }
                        AsyNavItem(Ic.Photo, "Foto ${pics.size}", tab == 1) { tab = 1; exitSel() }
                    }
                }
            }
        }

        // ----- pemilih, penampil foto, ganti sandi -----
        if (picker) Picker(preselect, onClose = { picker = false }) { list ->
            picker = false
            store.startImport(ctx, list, cur)
        }
        viewer?.let { start ->
            if (pics.isNotEmpty()) PhotoViewer(
                pics, start.coerceIn(0, pics.lastIndex), onClose = { viewer = null },
                onRestore = { restoreFor = listOf(it) }, onDelete = { deleteFor = listOf(it) }
            ) else { viewer = null }
        }
        if (changePin) ChangePin(onClose = { changePin = false })
    }

    // ----- dialog -----
    if (newFolder) NameDialog("Folder baru", "", "Buat", { newFolder = false }) { store.addFolder(ctx, it); newFolder = false }
    renameF?.let { f -> NameDialog("Ubah nama folder", f.name, "Simpan", { renameF = null }) { store.renameFolder(ctx, f.id, it); renameF = null } }
    deleteF?.let { f ->
        AlertDialog(
            onDismissRequest = { deleteF = null }, containerColor = PanelColor,
            title = { Text("Hapus folder \"${f.name}\"?") },
            text = { Text("Isinya tidak dihapus, tetapi dipindahkan kembali ke Utama.") },
            confirmButton = { TextButton(onClick = { store.deleteFolder(ctx, f.id); deleteF = null }) { Text("Hapus folder", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteF = null }) { Text("Batal") } }
        )
    }
    folderInfo?.let { f ->
        val inside = all.filter { it.folder == f.id }
        val v = inside.filter { !it.photo }
        val p = inside.filter { it.photo }
        InfoDialog(
            "Info folder",
            listOf(
                "Nama" to f.name,
                "Isi" to "${v.size} video, ${p.size} foto (${inside.size} item)",
                "Ukuran video" to fmtSize(v.sumOf { it.size }),
                "Ukuran foto" to fmtSize(p.sumOf { it.size }),
                "Total ukuran" to fmtSize(inside.sumOf { it.size }),
            ),
            onClose = { folderInfo = null }
        )
    }
    infoFor?.let { a ->
        var dims by remember(a.id) { mutableStateOf<Pair<Int, Int>?>(null) }
        LaunchedEffect(a.id) {
            dims = withContext(Dispatchers.IO) {
                try {
                    val file = AsylumStore.file(ctx, a)
                    if (a.photo) {
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(file.path, o)
                        if (o.outWidth > 0) Pair(o.outWidth, o.outHeight) else null
                    } else loadVideoSize(ctx, Uri.fromFile(file))
                } catch (e: Throwable) { null }
            }
        }
        InfoDialog(
            if (a.photo) "Info foto" else "Info video",
            itemInfo(a, dims, store.folders.firstOrNull { it.id == a.folder }?.name ?: "Utama"),
            onClose = { infoFor = null }
        )
    }
    moveFor?.let { list ->
        AlertDialog(
            onDismissRequest = { moveFor = null }, containerColor = PanelColor,
            title = { Text("Pindahkan ${list.size} item ke") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    (listOf(AsyFolder("", "Utama")) + store.folders).forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                store.moveItems(ctx, list.map { it.id }.toSet(), f.id); moveFor = null; exitSel()
                            }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon24(Ic.Folder, Violet, size = 20.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(f.name)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveFor = null }) { Text("Batal") } }
        )
    }
    deleteFor?.let { list ->
        AlertDialog(
            onDismissRequest = { deleteFor = null }, containerColor = PanelColor,
            title = { Text(if (list.size == 1) "Hapus permanen?" else "Hapus ${list.size} item permanen?") },
            text = { Text("File akan dihapus dari Elarion Asylum dan TIDAK bisa dikembalikan. Pilih Pulihkan jika ingin menyimpannya di galeri.") },
            confirmButton = {
                TextButton(onClick = { store.deleteItems(ctx, list); deleteFor = null; viewer = null; exitSel() }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal") } }
        )
    }
    restoreFor?.let { list ->
        val need = list.sumOf { it.size }
        AlertDialog(
            onDismissRequest = { restoreFor = null }, containerColor = PanelColor,
            title = { Text("Pulihkan ${list.size} item?") },
            text = { Text("File dikembalikan ke galeri dan pengelola berkas (lokasi asalnya, atau folder Movies/Pictures → Elarion), lalu dihapus dari Asylum. Total ${fmtSize(need)}.") },
            confirmButton = {
                TextButton(onClick = { store.startRestore(ctx, list); restoreFor = null; viewer = null; exitSel() }) { Text("Pulihkan") }
            },
            dismissButton = { TextButton(onClick = { restoreFor = null }) { Text("Batal") } }
        )
    }
}

// =====================================================================
//  Pemilih file dari galeri (telusuri per folder, atau semua sekaligus)
// =====================================================================
/** Penanda "semua folder" pada posisi penelusuran. */
private const val ALL_KEY = "\u0000semua"

@Composable
private fun PickFolderRow(cover: Media, name: String, info: String, picked: Int, onClick: () -> Unit) {
    val el = LocalEl.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(el.card)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(cover, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(name, color = el.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(info, color = el.textSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (picked > 0) {
            Box(Modifier.clip(RoundedCornerShape(50)).background(el.accentFill).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("$picked", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(4.dp))
        Icon24(Ic.ChevronDown, el.textSoft, Modifier.rotate(-90f), size = 20.dp)
    }
}

@Composable
private fun Picker(preselect: Set<String>, onClose: () -> Unit, onGo: (List<Media>) -> Unit) {
    val ctx = LocalContext.current
    val el = LocalEl.current
    var videos by remember { mutableStateOf<List<Media>>(emptyList()) }
    var pics by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    // null = daftar folder, ALL_KEY = semua file, selain itu = kunci folder yang sedang dibuka
    var dir by remember { mutableStateOf<String?>(if (preselect.isNotEmpty()) ALL_KEY else null) }
    var sel by remember { mutableStateOf(preselect) }
    var confirm by remember { mutableStateOf(false) }
    var noSpace by remember { mutableStateOf<String?>(null) }

    val hasImgPerm = remember(reload) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { reload++ }
    LaunchedEffect(reload) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            pics = ImageScanner.images(ctx)
        }
        loading = false
    }

    val source = if (tab == 0) videos else pics
    val groups = remember(tab, videos, pics) {
        source.groupBy { it.folderKey }
            .map { (k, v) -> FolderGroup(k, v.first().folderName, v) }
            .sortedBy { it.name.lowercase() }
    }
    val openDir = dir
    val shown: List<Media> =
        if (openDir == null) emptyList()
        else if (openDir == ALL_KEY) source
        else groups.firstOrNull { it.key == openDir }?.items ?: emptyList()
    val chosen = (videos + pics).filter { it.uri.toString() in sel }
    val total = chosen.sumOf { it.size }
    val unit = if (tab == 0) "video" else "foto"

    BackHandler(enabled = dir != null) { dir = null }

    Box(Modifier.fillMaxSize().pointerInput(Unit) {}) {
        AsyBackground(R.drawable.asylum_bg)
        Column(Modifier.fillMaxSize()) {
            // ----- bilah atas: kembali/tutup + tab Video/Foto -----
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                if (openDir == null) IconBtn(Ic.Close, onClose, tint = el.text, bg = el.card, box = 40.dp, icon = 20.dp)
                else IconBtn(Ic.ChevronDown, { dir = null }, Modifier.rotate(90f), tint = el.text, bg = el.card, box = 40.dp, icon = 20.dp)
                SegTabs(listOf("Video ${videos.size}", "Foto ${pics.size}"), tab, Modifier.weight(1f)) {
                    tab = it
                    if (dir != ALL_KEY) dir = null
                }
            }

            // ----- judul folder yang dibuka + pilih semua -----
            if (openDir != null) {
                val folderTitle = if (openDir == ALL_KEY) "Semua" else (groups.firstOrNull { it.key == openDir }?.name ?: "")
                val allOn = shown.isNotEmpty() && shown.all { it.uri.toString() in sel }
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(folderTitle, color = el.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${shown.size} $unit • ${fmtSize(shown.sumOf { it.size })}", color = el.textSoft, fontSize = 12.sp)
                    }
                    if (shown.isNotEmpty()) {
                        Box(
                            Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(el.card)
                                .clickable {
                                    val ids = shown.map { it.uri.toString() }.toSet()
                                    sel = if (allOn) sel - ids else sel + ids
                                }.padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(if (allOn) "Batal pilih" else "Pilih semua", color = el.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }

            // ----- isi -----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (tab == 1 && !hasImgPerm) {
                    Column(
                        Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(16.dp)).background(el.card).padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Elarion perlu izin untuk melihat foto agar bisa memindahkannya.", color = el.text, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { permLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES) },
                            colors = ButtonDefaults.buttonColors(containerColor = el.accentFill, contentColor = Color.White)
                        ) { Text("Izinkan akses foto") }
                    }
                } else if (loading) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center), color = el.accent)
                } else if (source.isEmpty()) {
                    Text("Tidak ada file ditemukan.", Modifier.align(Alignment.Center), color = el.text)
                } else if (openDir == null) {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            PickFolderRow(
                                source.first(), "Semua", "${source.size} $unit dari semua folder",
                                source.count { it.uri.toString() in sel }
                            ) { dir = ALL_KEY }
                        }
                        items(groups, key = { it.key }) { g ->
                            PickFolderRow(
                                g.items.first(), g.name, "${g.items.size} $unit • ${g.key.ifBlank { "Penyimpanan internal" }}",
                                g.items.count { it.uri.toString() in sel }
                            ) { dir = g.key }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown, key = { it.uri.toString() }) { m ->
                            val k = m.uri.toString()
                            val on = k in sel
                            Box(
                                Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                                    .clickable { sel = if (on) sel - k else sel + k }
                            ) {
                                Thumb(m, Modifier.fillMaxSize(), badge = if (m.video) fmt(m.durationMs) else null)
                                Box(Modifier.fillMaxSize().background(if (on) el.accentFill.copy(alpha = 0.35f) else Color.Transparent))
                                Box(
                                    Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape)
                                        .background(if (on) el.accentFill else Color(0x66000000))
                                        .border(2.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { if (on) Icon24(Ic.Check, Color.White, size = 14.dp) }
                            }
                        }
                    }
                }
            }

            // ----- bilah bawah: ringkasan pilihan + tombol -----
            Row(
                Modifier.fillMaxWidth().background(el.bar).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (chosen.isEmpty()) "Belum ada yang dipilih" else "${chosen.size} dipilih",
                        color = el.text, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        if (chosen.isEmpty()) "Buka folder, lalu ketuk file" else fmtSize(total),
                        color = el.textSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Button(
                    onClick = {
                        val free = AsylumStore.freeBytes(ctx)
                        if (total + 100_000_000L > free) {
                            noSpace = "Butuh ${fmtSize(total)} ruang kosong, tersedia ${fmtSize(free)}. " +
                                "Pilih lebih sedikit (sekitar ${fmtSize(maxOf(0L, free - 100_000_000L))} sekali jalan), lalu ulangi."
                        } else confirm = true
                    },
                    enabled = chosen.isNotEmpty(),
                    modifier = Modifier.height(46.dp), shape = RoundedCornerShape(26.dp),
                    contentPadding = PaddingValues(horizontal = 22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = el.accentFill, contentColor = Color.White,
                        disabledContainerColor = el.card, disabledContentColor = el.textSoft
                    )
                ) { Text("Pindahkan", fontSize = 15.sp, maxLines = 1) }
            }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = PanelColor,
        title = { Text("Pindahkan ${chosen.size} file?") },
        text = {
            Text(
                "File (${fmtSize(total)}) disalin ke Elarion Asylum, lalu file aslinya dihapus dari galeri dan pengelola berkas. " +
                    "Jika Elarion di-uninstall atau datanya dihapus, isi Asylum ikut hilang. Gunakan Pulihkan dulu sebelum itu."
            )
        },
        confirmButton = { TextButton(onClick = { confirm = false; onGo(chosen) }) { Text("Pindahkan") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } }
    )
    noSpace?.let { msg ->
        AlertDialog(
            onDismissRequest = { noSpace = null }, containerColor = PanelColor,
            title = { Text("Ruang tidak cukup") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { noSpace = null }) { Text("Mengerti") } }
        )
    }
}

// =====================================================================
//  Penampil foto (geser antar foto, cubit untuk zoom, ketuk dua kali masuk/keluar zoom)
// =====================================================================
@Composable
private fun PhotoViewer(
    list: List<AsyItem>, start: Int, onClose: () -> Unit,
    onRestore: (AsyItem) -> Unit, onDelete: (AsyItem) -> Unit,
) {
    val pager = rememberPagerState(initialPage = start) { list.size }
    val cur = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {}) {
        HorizontalPager(
            state = pager, modifier = Modifier.fillMaxSize(),
            pageSpacing = 12.dp, beyondBoundsPageCount = 1,
            key = { list[it.coerceIn(0, list.lastIndex)].id }
        ) { p -> ZoomImage(list[p], p == pager.currentPage) }
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color(0x66000000)).padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn(Ic.Close, onClose, tint = Color.White)
            Text(cur.title, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${pager.currentPage + 1}/${list.size}", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
        }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x66000000)).padding(vertical = 4.dp)
        ) {
            ActionBtn(Ic.Restore, "Pulihkan", true, Color.White, Modifier.weight(1f)) { onRestore(cur) }
            ActionBtn(Ic.Trash, "Hapus", true, Color(0xFFFF8A8A), Modifier.weight(1f)) { onDelete(cur) }
        }
    }
}

@Composable
private fun ZoomImage(item: AsyItem, isCurrent: Boolean) {
    val ctx = LocalContext.current
    val media = remember(item.id) { item.toMedia(ctx) }
    // Tampilkan thumbnail (sudah ada di cache dari kotak foto) dulu, lalu ganti dengan versi besar
    val bmp by produceState<Bitmap?>(null, item.id) {
        value = withContext(Dispatchers.IO) { Thumbs.thumb(ctx, media, 256) }
        val full = withContext(Dispatchers.IO) { Thumbs.imageFile(AsylumStore.file(ctx, item).path, 1800) }
        if (full != null) value = full
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var anim by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    fun clampOff(o: Offset, s: Float): Offset {
        val mx = box.width * (s - 1f) / 2f
        val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    fun animateTo(targetScale: Float, targetOff: Offset) {
        anim?.cancel()
        val s0 = scale
        val o0 = off
        anim = scope.launch {
            animate(0f, 1f, animationSpec = tween(280, easing = FastOutSlowInEasing)) { f, _ ->
                scale = s0 + (targetScale - s0) * f
                off = Offset(o0.x + (targetOff.x - o0.x) * f, o0.y + (targetOff.y - o0.y) * f)
            }
        }
    }
    // Foto yang ditinggalkan kembali ke ukuran normal
    LaunchedEffect(isCurrent) { if (!isCurrent) { anim?.cancel(); scale = 1f; off = Offset.Zero } }

    Box(
        Modifier.fillMaxSize().onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { tap ->
                    if (scale > 1.05f) animateTo(1f, Offset.Zero)
                    else {
                        val c = Offset(box.width / 2f, box.height / 2f)
                        animateTo(2.5f, clampOff((tap - c) * (1f - 2.5f), 2.5f))
                    }
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    anim?.cancel()
                    var pastSlop = false
                    var accPan = Offset.Zero
                    do {
                        val ev = awaitPointerEvent()
                        val multi = ev.changes.count { it.pressed } > 1
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        if (!pastSlop) {
                            accPan += pan
                            if (multi || (scale > 1f && accPan.getDistance() > viewConfiguration.touchSlop)) pastSlop = true
                        }
                        // Hanya "makan" sentuhan saat benar-benar mencubit/menggeser foto yang diperbesar,
                        // supaya ketukan dan geseran antar foto tetap lolos
                        if (pastSlop && (multi || scale > 1f)) {
                            val ns = (scale * zoom).coerceIn(1f, 5f)
                            scale = ns
                            off = if (ns <= 1f) Offset.Zero else clampOff(off + pan, ns)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                    if (scale < 1.03f && scale != 1f) { scale = 1f; off = Offset.Zero }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            val img = remember(b) { b.asImageBitmap() }
            Image(
                bitmap = img, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y
                }
            )
        } else CircularProgressIndicator(color = Color.White)
    }
}
