@file:OptIn(ExperimentalFoundationApi::class)

package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---- Palet Asylum (tetap gelap, tidak ikut tema Tampilan) ----
private val AsBg = Color(0xFF15112B)
private val AsCard = Color(0xFF221B42)
private val AsCard2 = Color(0xFF2D2457)
private val AsAccent = Color(0xFF8B5CF6)
private val AsText = Color(0xFFEDE9FE)
private val AsSoft = Color(0xFFA59CC9)
private val AsLight = Color(0xFFC4B5FD)
private val AsDim = Color(0xFF6D5FA8)
private val AsErr = Color(0xFFFF8A8A)

private const val MIN_PIN = 4
private const val MAX_PIN = 10
/** Setelah keluar dari aplikasi lebih lama dari ini, Asylum terkunci lagi. */
private const val AUTO_LOCK_MS = 15_000L

object AsylumSession { var internalLeave = false }

// =====================================================================
//  Sidik jari (BiometricPrompt bawaan sistem, Android 9 ke atas)
// =====================================================================
private fun bioAvailable(ctx: Context): Boolean {
    if (Build.VERSION.SDK_INT < 28) return false
    if (!ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) return false
    if (Build.VERSION.SDK_INT >= 29) {
        val bm = ctx.getSystemService(android.hardware.biometrics.BiometricManager::class.java)
        @Suppress("DEPRECATION")
        return bm != null && bm.canAuthenticate() == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS
    }
    return true
}

private fun showBio(ctx: Context, onOk: () -> Unit, onCancel: () -> Unit) {
    if (Build.VERSION.SDK_INT < 28) { onCancel(); return }
    try {
        val exec = ContextCompat.getMainExecutor(ctx)
        val prompt = android.hardware.biometrics.BiometricPrompt.Builder(ctx)
            .setTitle("Elarion Asylum")
            .setSubtitle("Sentuh sensor sidik jari")
            .setNegativeButton("Pakai kata sandi", exec) { _, _ -> onCancel() }
            .build()
        prompt.authenticate(
            android.os.CancellationSignal(), exec,
            object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) { onOk() }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { onCancel() }
            }
        )
    } catch (e: Exception) { onCancel() }
}

// =====================================================================
//  Papan angka
// =====================================================================
@Composable
private fun Key(label: String? = null, ic: Ic? = null, fill: Color = AsCard, onClick: () -> Unit) {
    Box(
        Modifier.size(68.dp).clip(CircleShape).background(fill).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (label != null) Text(label, fontSize = 26.sp, color = AsText)
        else if (ic != null) Icon24(ic, AsText, size = 26.dp)
    }
}

@Composable
private fun PinPad(
    title: String, subtitle: String, error: String?, confirmLabel: String, resetKey: Int,
    bioButton: Boolean, onBio: () -> Unit,
    footer: @Composable () -> Unit = {},
    onSubmit: (String) -> Unit,
) {
    var pin by remember(resetKey) { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 32.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(76.dp).clip(CircleShape).background(AsCard2), contentAlignment = Alignment.Center) {
            Icon24(Ic.Lock, AsLight, size = 36.dp)
        }
        Spacer(Modifier.height(14.dp))
        Text(title, color = AsText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = AsSoft, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.height(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(maxOf(MIN_PIN, pin.length)) { i ->
                Box(
                    Modifier.size(14.dp).clip(CircleShape).then(
                        if (i < pin.length) Modifier.background(AsAccent) else Modifier.border(2.dp, AsDim, CircleShape)
                    )
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(error ?: " ", color = AsErr, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                r.forEach { d -> Key(d) { if (pin.length < MAX_PIN) pin += d } }
            }
            Spacer(Modifier.height(14.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            if (bioButton) Key(ic = Ic.Fingerprint, fill = AsAccent) { onBio() } else Spacer(Modifier.size(68.dp))
            Key("0") { if (pin.length < MAX_PIN) pin += "0" }
            Key(ic = Ic.Backspace) { if (pin.isNotEmpty()) pin = pin.dropLast(1) }
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onSubmit(pin) }, enabled = pin.length >= MIN_PIN,
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AsAccent, contentColor = Color.White,
                disabledContainerColor = AsCard, disabledContentColor = AsSoft
            )
        ) { Text(confirmLabel, fontSize = 16.sp) }
        footer()
    }
}

@Composable
private fun SetupPin(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var first by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }
    var askBio by remember { mutableStateOf(false) }
    val canBio = remember { bioAvailable(ctx) }
    PinPad(
        title = if (first == null) "Buat kata sandi" else "Ulangi kata sandi",
        subtitle = if (first == null) "4–10 angka. Jika lupa, isi Asylum tidak bisa dibuka lagi."
        else "Ketik sekali lagi untuk memastikan",
        error = err, confirmLabel = if (first == null) "Lanjut" else "Simpan",
        resetKey = reset, bioButton = false, onBio = {}
    ) { pin ->
        val f = first
        if (f == null) { first = pin; err = null; reset++ }
        else if (f == pin) {
            AsylumAuth.setPin(ctx, pin)
            if (canBio) askBio = true else onDone()
        } else { first = null; err = "Tidak sama, ulangi dari awal"; reset++ }
    }
    if (askBio) AlertDialog(
        onDismissRequest = {}, containerColor = AsCard,
        title = { Text("Pakai sidik jari?", color = AsText) },
        text = { Text("Kamu bisa membuka Elarion Asylum dengan sidik jari. Kata sandi tetap dipakai sebagai cadangan.", color = AsSoft) },
        confirmButton = { TextButton(onClick = { AsylumAuth.setBio(ctx, true); onDone() }) { Text("Aktifkan", color = AsLight) } },
        dismissButton = { TextButton(onClick = { onDone() }) { Text("Nanti", color = AsSoft) } }
    )
}

@Composable
private fun LockPad(onUnlocked: () -> Unit, onForgot: () -> Unit) {
    val ctx = LocalContext.current
    val bioReady = remember { AsylumAuth.bioOn(ctx) && bioAvailable(ctx) }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { if (bioReady) showBio(ctx, onOk = onUnlocked, onCancel = {}) }
    PinPad(
        title = "Elarion Asylum", subtitle = "Masukkan kata sandi", error = err,
        confirmLabel = "Buka", resetKey = reset, bioButton = bioReady,
        onBio = { showBio(ctx, onOk = onUnlocked, onCancel = {}) },
        footer = { TextButton(onClick = onForgot) { Text("Lupa kata sandi?", color = AsLight) } }
    ) { pin ->
        val wait = AsylumAuth.lockedSeconds(ctx)
        if (wait > 0) {
            err = "Terlalu banyak salah. Coba lagi dalam $wait detik."; reset++
        } else if (AsylumAuth.verify(ctx, pin)) {
            onUnlocked()
        } else {
            val w = AsylumAuth.lockedSeconds(ctx)
            err = if (w > 0) "Terlalu banyak salah. Coba lagi dalam $w detik." else "Kata sandi salah"
            reset++
        }
    }
}

@Composable
private fun ChangePin(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var stage by remember { mutableIntStateOf(0) }
    var newPin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var reset by remember { mutableIntStateOf(0) }
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(AsBg).pointerInput(Unit) {}) {
        PinPad(
            title = when (stage) { 0 -> "Kata sandi lama"; 1 -> "Kata sandi baru"; else -> "Ulangi kata sandi baru" },
            subtitle = "", error = err, confirmLabel = if (stage == 2) "Simpan" else "Lanjut",
            resetKey = reset, bioButton = false, onBio = {},
            footer = { TextButton(onClick = onClose) { Text("Batal", color = AsSoft) } }
        ) { pin ->
            reset++
            if (stage == 0) {
                if (AsylumAuth.lockedSeconds(ctx) > 0) {
                    err = "Terlalu banyak salah. Coba lagi nanti."
                } else if (AsylumAuth.verify(ctx, pin)) {
                    stage = 1; err = null
                } else {
                    err = "Kata sandi salah"
                }
            } else if (stage == 1) {
                newPin = pin; stage = 2; err = null
            } else {
                if (pin == newPin) {
                    AsylumAuth.setPin(ctx, pin)
                    Toast.makeText(ctx, "Kata sandi diganti", Toast.LENGTH_SHORT).show()
                    onClose()
                } else {
                    stage = 1; err = "Tidak sama, ulangi"
                }
            }
        }
    }
}

// =====================================================================
//  Layar utama Asylum
// =====================================================================
@Composable
fun AsylumScreen(onBack: () -> Unit, preselect: Set<String> = emptySet()) {
    val ctx = LocalContext.current
    remember { AsylumStore.load(ctx); true }
    var hasPin by remember { mutableStateOf(AsylumAuth.hasPin(ctx)) }
    var unlocked by remember { mutableStateOf(false) }
    var forgot by remember { mutableStateOf(false) }

    // Layar tidak bisa di-screenshot / direkam, dan bilah sistem ikut gelap selama Asylum terbuka
    DisposableEffect(Unit) {
        val w = (ctx as? Activity)?.window ?: return@DisposableEffect onDispose {}
        val oldS = w.statusBarColor
        val oldN = w.navigationBarColor
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        val oldLightS = ctl.isAppearanceLightStatusBars
        val oldLightN = ctl.isAppearanceLightNavigationBars
        w.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        w.statusBarColor = AsBg.toArgb(); w.navigationBarColor = AsBg.toArgb()
        ctl.isAppearanceLightStatusBars = false; ctl.isAppearanceLightNavigationBars = false
        onDispose {
            w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            w.statusBarColor = oldS; w.navigationBarColor = oldN
            ctl.isAppearanceLightStatusBars = oldLightS; ctl.isAppearanceLightNavigationBars = oldLightN
        }
    }

    // Kunci otomatis bila aplikasi ditinggalkan cukup lama (kecuali pindah ke pemutar video sendiri)
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var leftAt = 0L
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP) leftAt = SystemClock.elapsedRealtime()
            if (e == Lifecycle.Event.ON_START && leftAt > 0L) {
                val internal = AsylumSession.internalLeave
                AsylumSession.internalLeave = false
                if (!internal && SystemClock.elapsedRealtime() - leftAt > AUTO_LOCK_MS) unlocked = false
                leftAt = 0L
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(AsBg).pointerInput(Unit) {}) {
        when {
            !hasPin -> SetupPin(onDone = { hasPin = true; unlocked = true })
            !unlocked -> LockPad(onUnlocked = { unlocked = true }, onForgot = { forgot = true })
            else -> Room(preselect, onExit = onBack, onLock = { unlocked = false })
        }
        if (!hasPin || !unlocked) {
            IconBtn(Ic.Close, onBack, Modifier.align(Alignment.TopStart).padding(8.dp), tint = AsText)
        }
    }

    if (forgot) AlertDialog(
        onDismissRequest = { forgot = false }, containerColor = AsCard,
        title = { Text("Lupa kata sandi?", color = AsText) },
        text = {
            Text(
                "Demi keamanan, kata sandi tidak bisa dipulihkan. Satu-satunya jalan adalah mengatur ulang, " +
                    "dan itu akan MENGHAPUS PERMANEN semua foto dan video di dalam Elarion Asylum.",
                color = AsSoft
            )
        },
        confirmButton = {
            TextButton(onClick = {
                AsylumStore.clearAll(ctx); hasPin = false; unlocked = false; forgot = false
            }) { Text("Hapus semua & atur ulang", color = AsErr) }
        },
        dismissButton = { TextButton(onClick = { forgot = false }) { Text("Batal", color = AsLight) } }
    )
}

@Composable
private fun NameDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = AsCard,
        title = { Text(title, color = AsText) },
        text = {
            OutlinedTextField(
                value = t, onValueChange = { t = it.take(40) }, singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = AsText, unfocusedTextColor = AsText, cursorColor = AsAccent,
                    focusedBorderColor = AsAccent, unfocusedBorderColor = AsDim
                )
            )
        },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t) }) { Text(ok, color = AsLight) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = AsSoft) } }
    )
}

@Composable
private fun Room(preselect: Set<String>, onExit: () -> Unit, onLock: () -> Unit) {
    val ctx = LocalContext.current
    val store = AsylumStore
    var cur by remember { mutableStateOf("") }              // "" = Utama
    var tab by remember { mutableIntStateOf(0) }            // 0 video, 1 foto
    var selMode by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Set<String>>(emptySet()) }
    var picker by remember { mutableStateOf(preselect.isNotEmpty()) }
    var viewer by remember { mutableStateOf<Int?>(null) }
    var menu by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var renameF by remember { mutableStateOf<AsyFolder?>(null) }
    var deleteF by remember { mutableStateOf<AsyFolder?>(null) }
    var folderMenu by remember { mutableStateOf<String?>(null) }
    var moveFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var deleteFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var restoreFor by remember { mutableStateOf<List<AsyItem>?>(null) }
    var changePin by remember { mutableStateOf(false) }
    var bioOn by remember { mutableStateOf(AsylumAuth.bioOn(ctx)) }
    val canBio = remember { bioAvailable(ctx) }

    fun exitSel() { selMode = false; sel = emptySet() }

    // ---- hapus file asli dari galeri (setelah berhasil disalin) ----
    var delQueue by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var legacyRetry by remember { mutableIntStateOf(0) }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (Build.VERSION.SDK_INT >= 30) {
            if (res.resultCode == Activity.RESULT_OK) {
                store.pendingOriginals = store.pendingOriginals - delQueue.toSet()
                store.lastMessage = "File asli sudah dihapus dari galeri."
            }
            delQueue = emptyList()
        } else {
            if (res.resultCode == Activity.RESULT_OK) legacyRetry++ else delQueue = emptyList()
        }
    }
    fun legacyDelete() {
        var q = delQueue
        while (q.isNotEmpty()) {
            val u = q.first()
            try {
                ctx.contentResolver.delete(u, null, null)
                store.pendingOriginals = store.pendingOriginals - u
                q = q.drop(1); delQueue = q
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    delQueue = q
                    delLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                    return
                }
                q = q.drop(1)
            } catch (e: Exception) { q = q.drop(1) }
        }
        delQueue = emptyList()
    }
    fun askDelete() {
        val list = store.pendingOriginals
        if (list.isEmpty()) return
        delQueue = list
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, list)
                delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) { delQueue = emptyList() }
        } else legacyDelete()
    }
    LaunchedEffect(legacyRetry) { if (legacyRetry > 0) legacyDelete() }
    LaunchedEffect(store.deleteTrigger) { if (store.deleteTrigger > 0 && delQueue.isEmpty()) askDelete() }
    LaunchedEffect(store.lastMessage) {
        store.lastMessage?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); store.lastMessage = null }
    }

    // ---- data yang tampil ----
    val all = store.items
    val here = all.filter { it.folder == cur }.sortedByDescending { it.added }
    val vids = here.filter { !it.photo }
    val pics = here.filter { it.photo }
    val shown = if (tab == 0) vids else pics
    val curFolder = store.folders.firstOrNull { it.id == cur }
    val selItems = all.filter { it.id in sel }

    BackHandler(enabled = cur != "") { cur = ""; exitSel() }
    BackHandler(enabled = selMode) { exitSel() }
    BackHandler(enabled = picker) { picker = false }
    BackHandler(enabled = viewer != null) { viewer = null }

    fun playVideo(i: Int) {
        val metas = vids.map { it.toMedia(ctx) }
        AsylumSession.internalLeave = true
        ctx.startActivity(
            Intent(ctx, VideoPlayerActivity::class.java).setData(metas[i].uri)
                .putStringArrayListExtra("playlist", ArrayList(metas.map { it.uri.toString() }))
                .putStringArrayListExtra("titles", ArrayList(vids.map { it.title }))
                .putExtra("index", i).putExtra("secure", true)
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            Spacer(Modifier.height(8.dp))
            // ----- bilah atas -----
            Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                if (selMode) {
                    IconBtn(Ic.Close, { exitSel() }, tint = AsText)
                    Text("${sel.size} dipilih", Modifier.weight(1f).padding(start = 4.dp), color = AsText, fontWeight = FontWeight.Bold)
                    TextButton(onClick = {
                        val ids = shown.map { it.id }.toSet()
                        sel = if (ids.isNotEmpty() && ids.all { it in sel }) sel - ids else sel + ids
                    }) { Text("Pilih semua", color = AsLight) }
                } else {
                    if (cur != "") IconBtn(Ic.ChevronDown, { cur = ""; exitSel() }, Modifier.rotate(90f), tint = AsText)
                    else IconBtn(Ic.Close, onExit, tint = AsText)
                    Text(
                        curFolder?.name ?: "Elarion Asylum", Modifier.weight(1f).padding(start = 4.dp),
                        color = AsText, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    IconBtn(Ic.Lock, onLock, tint = AsLight, bg = AsCard2)
                    Spacer(Modifier.width(8.dp))
                    Box {
                        IconBtn(Ic.More, { menu = true }, tint = AsText)
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (cur == "") DropdownMenuItem(
                                text = { Text("Folder baru", color = InkDark) },
                                leadingIcon = { Icon24(Ic.Folder, Violet, size = 20.dp) },
                                onClick = { menu = false; newFolder = true })
                            if (canBio) DropdownMenuItem(
                                text = { Text(if (bioOn) "Matikan sidik jari" else "Aktifkan sidik jari", color = InkDark) },
                                leadingIcon = { Icon24(Ic.Fingerprint, Violet, size = 20.dp) },
                                onClick = {
                                    menu = false; bioOn = !bioOn; AsylumAuth.setBio(ctx, bioOn)
                                })
                            DropdownMenuItem(
                                text = { Text("Ganti kata sandi", color = InkDark) },
                                leadingIcon = { Icon24(Ic.Lock, Violet, size = 20.dp) },
                                onClick = { menu = false; changePin = true })
                        }
                    }
                }
            }
            // ----- tab video / foto -----
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(AsCard).padding(4.dp)) {
                listOf("Video ${vids.size}", "Foto ${pics.size}").forEachIndexed { i, l ->
                    Box(
                        Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(50))
                            .background(if (tab == i) AsAccent else Color.Transparent)
                            .clickable { tab = i; exitSel() },
                        contentAlignment = Alignment.Center
                    ) { Text(l, color = if (tab == i) Color.White else AsLight, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) }
                }
            }
            Text(
                "Hanya terlihat di Elarion • ${all.size} item, ${fmtSize(all.sumOf { it.size })}",
                Modifier.padding(vertical = 8.dp), color = AsSoft, fontSize = 13.sp
            )

            // ----- kartu proses -----
            if (store.busy) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AsCard2).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${store.busyLabel} ${minOf(store.busyDone + 1, store.busyTotal)} dari ${store.busyTotal}",
                            Modifier.weight(1f), color = AsText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { store.cancelFlag = true }) { Text("Batal", color = AsLight) }
                    }
                    Text(store.busyName, color = AsSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { ((store.busyDone + store.busyFraction) / maxOf(1, store.busyTotal)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = AsAccent, trackColor = AsCard
                    )
                    Text("Jangan tutup Elarion sampai selesai.", color = AsSoft, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
            } else if (store.pendingOriginals.isNotEmpty() && delQueue.isEmpty()) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AsCard2).padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${store.pendingOriginals.size} file asli belum dihapus dari galeri.",
                        Modifier.weight(1f), color = AsText, fontSize = 13.sp)
                    TextButton(onClick = { askDelete() }) { Text("Hapus", color = AsLight) }
                }
                Spacer(Modifier.height(8.dp))
            }

            // ----- isi -----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (cur == "") {
                        items(store.folders, key = { "f" + it.id }, span = { GridItemSpan(maxLineSpan) }) { f ->
                            val nv = all.count { it.folder == f.id && !it.photo }
                            val np = all.count { it.folder == f.id && it.photo }
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 4.dp).clip(RoundedCornerShape(14.dp))
                                    .background(AsCard).clickable { cur = f.id; exitSel() }.padding(start = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon24(Ic.Folder, AsLight, size = 26.dp)
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp)) {
                                    Text(f.name, color = AsText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("$nv video • $np foto", color = AsSoft, fontSize = 12.sp)
                                }
                                Box {
                                    IconBtn(Ic.More, { folderMenu = f.id }, tint = AsText, box = 44.dp, icon = 22.dp)
                                    DropdownMenu(expanded = folderMenu == f.id, onDismissRequest = { folderMenu = null }) {
                                        DropdownMenuItem(text = { Text("Ubah nama", color = InkDark) },
                                            onClick = { folderMenu = null; renameF = f })
                                        DropdownMenuItem(text = { Text("Hapus folder", color = Color(0xFFBA1A1A)) },
                                            onClick = { folderMenu = null; deleteF = f })
                                    }
                                }
                            }
                        }
                    }
                    if (shown.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(
                                if (tab == 0) "Belum ada video di sini. Ketuk Masukkan untuk memindahkan dari galeri."
                                else "Belum ada foto di sini. Ketuk Masukkan untuk memindahkan dari galeri.",
                                Modifier.fillMaxWidth().padding(24.dp), color = AsSoft, textAlign = TextAlign.Center
                            )
                        }
                    }
                    items(shown, key = { it.id }) { a ->
                        val m = remember(a.id) { a.toMedia(ctx) }
                        val on = a.id in sel
                        Box(
                            Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).combinedClickable(
                                onClick = {
                                    if (selMode) sel = if (on) sel - a.id else sel + a.id
                                    else if (a.photo) viewer = pics.indexOf(a)
                                    else playVideo(vids.indexOf(a))
                                },
                                onLongClick = { selMode = true; sel = sel + a.id }
                            )
                        ) {
                            Thumb(m, Modifier.fillMaxSize(), badge = if (a.photo) null else fmt(a.durationMs))
                            if (selMode) {
                                Box(Modifier.fillMaxSize().background(if (on) AsAccent.copy(alpha = 0.35f) else Color.Transparent))
                                Box(
                                    Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape)
                                        .background(if (on) AsAccent else Color(0x66000000))
                                        .border(2.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { if (on) Icon24(Ic.Check, Color.White, size = 14.dp) }
                            }
                        }
                    }
                }
            }

            // ----- bilah bawah -----
            if (selMode) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(20.dp)).background(AsCard)) {
                    ActionBtn(Ic.Folder, "Pindah", sel.isNotEmpty() && !store.busy, AsText, Modifier.weight(1f)) { moveFor = selItems }
                    ActionBtn(Ic.Restore, "Pulihkan", sel.isNotEmpty() && !store.busy, AsText, Modifier.weight(1f)) { restoreFor = selItems }
                    ActionBtn(Ic.Trash, "Hapus", sel.isNotEmpty() && !store.busy, AsErr, Modifier.weight(1f)) { deleteFor = selItems }
                }
            } else {
                Button(
                    onClick = { picker = true }, enabled = !store.busy,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AsAccent, contentColor = Color.White,
                        disabledContainerColor = AsCard, disabledContentColor = AsSoft
                    )
                ) {
                    Icon24(Ic.Plus, Color.White, size = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Masukkan", fontSize = 16.sp)
                }
            }
        }

        // ----- picker & penampil foto & ganti sandi -----
        if (picker) Picker(preselect, cur, onClose = { picker = false }) { list ->
            picker = false
            store.startImport(ctx, list, cur)
        }
        viewer?.let { start ->
            if (pics.isNotEmpty()) PhotoViewer(
                pics, start.coerceIn(0, pics.lastIndex), onClose = { viewer = null },
                onRestore = { restoreFor = listOf(it) }, onDelete = { deleteFor = listOf(it) }
            ) else { viewer = null }
        }
        if (changePin) ChangePin(onClose = { changePin = false })
    }

    // ----- dialog -----
    if (newFolder) NameDialog("Folder baru", "", "Buat", { newFolder = false }) { store.addFolder(ctx, it); newFolder = false }
    renameF?.let { f -> NameDialog("Ubah nama folder", f.name, "Simpan", { renameF = null }) { store.renameFolder(ctx, f.id, it); renameF = null } }
    deleteF?.let { f ->
        AlertDialog(
            onDismissRequest = { deleteF = null }, containerColor = AsCard,
            title = { Text("Hapus folder \"${f.name}\"?", color = AsText) },
            text = { Text("Isinya tidak dihapus, tetapi dipindahkan kembali ke Utama.", color = AsSoft) },
            confirmButton = { TextButton(onClick = { store.deleteFolder(ctx, f.id); deleteF = null }) { Text("Hapus folder", color = AsErr) } },
            dismissButton = { TextButton(onClick = { deleteF = null }) { Text("Batal", color = AsLight) } }
        )
    }
    moveFor?.let { list ->
        AlertDialog(
            onDismissRequest = { moveFor = null }, containerColor = AsCard,
            title = { Text("Pindahkan ${list.size} item ke", color = AsText) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    (listOf(AsyFolder("", "Utama")) + store.folders).forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                store.moveItems(ctx, list.map { it.id }.toSet(), f.id); moveFor = null; exitSel()
                            }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon24(Ic.Folder, AsLight, size = 20.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(f.name, color = AsText)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveFor = null }) { Text("Batal", color = AsLight) } }
        )
    }
    deleteFor?.let { list ->
        AlertDialog(
            onDismissRequest = { deleteFor = null }, containerColor = AsCard,
            title = { Text(if (list.size == 1) "Hapus permanen?" else "Hapus ${list.size} item permanen?", color = AsText) },
            text = { Text("File akan dihapus dari Elarion Asylum dan TIDAK bisa dikembalikan. Pilih Pulihkan jika ingin menyimpannya di galeri.", color = AsSoft) },
            confirmButton = {
                TextButton(onClick = { store.deleteItems(ctx, list); deleteFor = null; viewer = null; exitSel() }) { Text("Hapus", color = AsErr) }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal", color = AsLight) } }
        )
    }
    restoreFor?.let { list ->
        val need = list.sumOf { it.size }
        AlertDialog(
            onDismissRequest = { restoreFor = null }, containerColor = AsCard,
            title = { Text("Pulihkan ${list.size} item?", color = AsText) },
            text = { Text("File dikembalikan ke galeri dan pengelola berkas (lokasi asalnya, atau folder Movies/Pictures → Elarion), lalu dihapus dari Asylum. Total ${fmtSize(need)}.", color = AsSoft) },
            confirmButton = {
                TextButton(onClick = { store.startRestore(ctx, list); restoreFor = null; viewer = null; exitSel() }) { Text("Pulihkan", color = AsLight) }
            },
            dismissButton = { TextButton(onClick = { restoreFor = null }) { Text("Batal", color = AsSoft) } }
        )
    }
}

// =====================================================================
//  Pemilih file dari galeri
// =====================================================================
@Composable
private fun Picker(preselect: Set<String>, dest: String, onClose: () -> Unit, onGo: (List<Media>) -> Unit) {
    val ctx = LocalContext.current
    var videos by remember { mutableStateOf<List<Media>>(emptyList()) }
    var pics by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf(preselect) }
    var confirm by remember { mutableStateOf(false) }
    var noSpace by remember { mutableStateOf<String?>(null) }

    val hasImgPerm = remember(reload) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { reload++ }
    LaunchedEffect(reload) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            pics = ImageScanner.images(ctx)
        }
        loading = false
    }

    val shown = if (tab == 0) videos else pics
    val chosen = (videos + pics).filter { it.uri.toString() in sel }
    val total = chosen.sumOf { it.size }

    Column(Modifier.fillMaxSize().background(AsBg).pointerInput(Unit) {}.padding(horizontal = 12.dp)) {
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Ic.Close, onClose, tint = AsText)
            Text("Pilih yang dimasukkan", Modifier.weight(1f).padding(start = 4.dp), color = AsText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = {
                val ids = shown.map { it.uri.toString() }.toSet()
                sel = if (ids.isNotEmpty() && ids.all { it in sel }) sel - ids else sel + ids
            }) { Text("Pilih semua", color = AsLight) }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(AsCard).padding(4.dp)) {
            listOf("Video ${videos.size}", "Foto ${pics.size}").forEachIndexed { i, l ->
                Box(
                    Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(50))
                        .background(if (tab == i) AsAccent else Color.Transparent).clickable { tab = i },
                    contentAlignment = Alignment.Center
                ) { Text(l, color = if (tab == i) Color.White else AsLight, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == 1 && !hasImgPerm) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Elarion perlu izin untuk melihat foto agar bisa memindahkannya.", color = AsSoft, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { permLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES) },
                        colors = ButtonDefaults.buttonColors(containerColor = AsAccent, contentColor = Color.White)
                    ) { Text("Izinkan akses foto") }
                }
            } else if (!loading && shown.isEmpty()) {
                Text("Tidak ada file ditemukan.", Modifier.align(Alignment.Center), color = AsSoft)
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(shown, key = { it.uri.toString() }) { m ->
                        val k = m.uri.toString()
                        val on = k in sel
                        Box(
                            Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp))
                                .clickable { sel = if (on) sel - k else sel + k }
                        ) {
                            Thumb(m, Modifier.fillMaxSize(), badge = if (m.video) fmt(m.durationMs) else null)
                            Box(Modifier.fillMaxSize().background(if (on) AsAccent.copy(alpha = 0.35f) else Color.Transparent))
                            Box(
                                Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape)
                                    .background(if (on) AsAccent else Color(0x66000000))
                                    .border(2.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (on) Icon24(Ic.Check, Color.White, size = 14.dp) }
                        }
                    }
                }
            }
        }
        Text(
            if (chosen.isEmpty()) "Belum ada yang dipilih" else "${chosen.size} dipilih • ${fmtSize(total)}",
            Modifier.padding(top = 8.dp), color = AsSoft, fontSize = 13.sp
        )
        Button(
            onClick = {
                val free = AsylumStore.freeBytes(ctx)
                if (total + 100_000_000L > free) {
                    noSpace = "Butuh ${fmtSize(total)} ruang kosong, tersedia ${fmtSize(free)}. " +
                        "Pilih lebih sedikit (sekitar ${fmtSize(maxOf(0L, free - 100_000_000L))} sekali jalan), lalu ulangi."
                } else confirm = true
            },
            enabled = chosen.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(52.dp), shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AsAccent, contentColor = Color.White,
                disabledContainerColor = AsCard, disabledContentColor = AsSoft
            )
        ) { Text("Pindahkan ke Asylum", fontSize = 16.sp) }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = AsCard,
        title = { Text("Pindahkan ${chosen.size} file?", color = AsText) },
        text = {
            Text(
                "File (${fmtSize(total)}) disalin ke Elarion Asylum, lalu file aslinya dihapus dari galeri dan pengelola berkas. " +
                    "Jika Elarion di-uninstall atau datanya dihapus, isi Asylum ikut hilang. Gunakan Pulihkan dulu sebelum itu.",
                color = AsSoft
            )
        },
        confirmButton = { TextButton(onClick = { confirm = false; onGo(chosen) }) { Text("Pindahkan", color = AsLight) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal", color = AsSoft) } }
    )
    noSpace?.let { msg ->
        AlertDialog(
            onDismissRequest = { noSpace = null }, containerColor = AsCard,
            title = { Text("Ruang tidak cukup", color = AsText) },
            text = { Text(msg, color = AsSoft) },
            confirmButton = { TextButton(onClick = { noSpace = null }) { Text("Mengerti", color = AsLight) } }
        )
    }
}

// =====================================================================
//  Penampil foto (geser antar foto, cubit untuk zoom, ketuk dua kali)
// =====================================================================
@Composable
private fun PhotoViewer(
    list: List<AsyItem>, start: Int, onClose: () -> Unit,
    onRestore: (AsyItem) -> Unit, onDelete: (AsyItem) -> Unit,
) {
    val pager = rememberPagerState(initialPage = start) { list.size }
    val cur = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {}) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { p -> ZoomImage(list[p]) }
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color(0x66000000)).padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn(Ic.Close, onClose, tint = Color.White)
            Text(cur.title, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${pager.currentPage + 1}/${list.size}", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
        }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x66000000)).padding(vertical = 4.dp)
        ) {
            ActionBtn(Ic.Restore, "Pulihkan", true, Color.White, Modifier.weight(1f)) { onRestore(cur) }
            ActionBtn(Ic.Trash, "Hapus", true, AsErr, Modifier.weight(1f)) { onDelete(cur) }
        }
    }
}

@Composable
private fun ZoomImage(item: AsyItem) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, item.id) {
        value = withContext(Dispatchers.IO) { Thumbs.imageFile(AsylumStore.file(ctx, item).path, 2048) }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    Box(
        Modifier.fillMaxSize().onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        if (ev.changes.size > 1 || scale > 1f) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            val mx = box.width * (scale - 1f) / 2f
                            val my = box.height * (scale - 1f) / 2f
                            off = if (scale <= 1f) Offset.Zero
                            else Offset((off.x + pan.x).coerceIn(-mx, mx), (off.y + pan.y).coerceIn(-my, my))
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y
                }
            )
        } else CircularProgressIndicator(color = AsAccent)
    }
}
