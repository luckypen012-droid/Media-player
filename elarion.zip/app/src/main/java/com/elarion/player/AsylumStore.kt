package com.elarion.player

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Satu file di dalam Elarion Asylum. Isi file disimpan di folder privat aplikasi. */
data class AsyItem(
    val id: String,
    val name: String,        // nama file asli, mis. "Liburan.mp4"
    val photo: Boolean,      // true = foto, false = video
    val folder: String,      // "" = Utama, selain itu id folder
    val size: Long,
    val durationMs: Long,
    val added: Long,         // detik
    val rel: String,         // lokasi asli (untuk Pulihkan)
    val mime: String,
) {
    val ext: String get() = Formats.ext(name).ifBlank { if (photo) "jpg" else "mp4" }
    val title: String get() = name.substringBeforeLast('.')
}

data class AsyFolder(val id: String, val name: String)

/** Kata sandi numerik (disimpan sebagai hash PBKDF2, bukan teks asli) + sidik jari + batas percobaan. */
object AsylumAuth {
    private const val ITER = 100_000
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("elarion_asylum", Context.MODE_PRIVATE)

    fun hasPin(ctx: Context) = prefs(ctx).getString("pin_hash", null) != null

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, ITER, 256)).encoded

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(ctx).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("fails", 0).putLong("lock_until", 0L)
            .apply()
    }

    fun verify(ctx: Context, pin: String): Boolean {
        val p = prefs(ctx)
        val salt = Base64.decode(p.getString("pin_salt", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(p.getString("pin_hash", "") ?: "", Base64.NO_WRAP)
        if (salt.isEmpty() || want.isEmpty()) return false
        val ok = MessageDigest.isEqual(hash(pin, salt), want)
        if (ok) {
            p.edit().putInt("fails", 0).putLong("lock_until", 0L).apply()
        } else {
            val f = p.getInt("fails", 0) + 1
            val e = p.edit().putInt("fails", f)
            // Setiap 5 kali salah: tunggu makin lama (30 dtk, 60 dtk, ...), maksimal 5 menit
            if (f % 5 == 0) {
                val wait = minOf(300_000L, 30_000L * (f / 5))
                e.putLong("lock_until", System.currentTimeMillis() + wait)
            }
            e.apply()
        }
        return ok
    }

    /** Sisa detik penguncian setelah terlalu banyak salah, 0 jika boleh mencoba. */
    fun lockedSeconds(ctx: Context): Int {
        val left = prefs(ctx).getLong("lock_until", 0L) - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    fun bioOn(ctx: Context) = prefs(ctx).getBoolean("bio", false)
    fun setBio(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("bio", on).apply() }
    fun clear(ctx: Context) { prefs(ctx).edit().clear().apply() }
}

/**
 * Penyimpanan Asylum: berkas ada di filesDir/asylum (tidak terlihat aplikasi lain / pengelola berkas),
 * daftar + folder ada di index.json. Pekerjaan berat jalan di scope milik objek ini, jadi tidak
 * terhenti saat layar berganti.
 */
object AsylumStore {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ioLock = Any()

    var items by mutableStateOf<List<AsyItem>>(emptyList()); private set
    var folders by mutableStateOf<List<AsyFolder>>(emptyList()); private set
    private var loaded = false

    // ---- status pekerjaan (dipantau layar) ----
    var busyLabel by mutableStateOf("")          // "" = tidak sibuk
    var busyDone by mutableStateOf(0)
    var busyTotal by mutableStateOf(0)
    var busyName by mutableStateOf("")
    var busyFraction by mutableStateOf(0f)
    @Volatile var cancelFlag = false
    /** File asli yang sudah tersalin tapi belum terhapus dari galeri. */
    var pendingOriginals by mutableStateOf<List<Uri>>(emptyList())
    var deleteTrigger by mutableStateOf(0)
    var lastMessage by mutableStateOf<String?>(null)

    val busy: Boolean get() = busyLabel.isNotEmpty()

    private fun dir(ctx: Context) = File(ctx.filesDir, "asylum").also { it.mkdirs() }
    fun file(ctx: Context, it: AsyItem) = File(dir(ctx), "${it.id}.${it.ext}")
    private fun indexFile(ctx: Context) = File(dir(ctx), "index.json")

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        dir(ctx).listFiles()?.forEach { if (it.name.endsWith(".part")) it.delete() }
        val f = indexFile(ctx)
        val bak = File(dir(ctx), "index.bak")
        val txt = try { f.readText() } catch (_: Exception) { null }
            ?: try { bak.readText() } catch (_: Exception) { null }
        if (txt == null) return
        try {
            val o = JSONObject(txt)
            val fa = o.optJSONArray("folders") ?: JSONArray()
            folders = (0 until fa.length()).map { i ->
                val x = fa.getJSONObject(i); AsyFolder(x.getString("id"), x.getString("name"))
            }
            val ia = o.optJSONArray("items") ?: JSONArray()
            items = (0 until ia.length()).map { i ->
                val x = ia.getJSONObject(i)
                AsyItem(
                    x.getString("id"), x.getString("name"), x.optBoolean("photo"), x.optString("folder"),
                    x.optLong("size"), x.optLong("dur"), x.optLong("added"), x.optString("rel"), x.optString("mime")
                )
            }
        } catch (_: Exception) {}
    }

    private fun save(ctx: Context) {
        synchronized(ioLock) {
            val o = JSONObject()
            o.put("folders", JSONArray().also { a ->
                folders.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
            })
            o.put("items", JSONArray().also { a ->
                items.forEach {
                    a.put(JSONObject().put("id", it.id).put("name", it.name).put("photo", it.photo)
                        .put("folder", it.folder).put("size", it.size).put("dur", it.durationMs)
                        .put("added", it.added).put("rel", it.rel).put("mime", it.mime))
                }
            })
            try {
                val f = indexFile(ctx)
                val tmp = File(dir(ctx), "index.tmp")
                tmp.writeText(o.toString())
                if (f.exists()) f.copyTo(File(dir(ctx), "index.bak"), overwrite = true)
                tmp.renameTo(f)
            } catch (_: Exception) {}
        }
    }

    // ---- folder ----
    fun addFolder(ctx: Context, name: String) {
        val n = name.trim().ifBlank { return }
        folders = folders + AsyFolder(java.util.UUID.randomUUID().toString().take(8), n)
        save(ctx)
    }
    fun renameFolder(ctx: Context, id: String, name: String) {
        val n = name.trim().ifBlank { return }
        folders = folders.map { if (it.id == id) it.copy(name = n) else it }
        save(ctx)
    }
    /** Menghapus folder TIDAK menghapus isinya: isinya kembali ke "Utama". */
    fun deleteFolder(ctx: Context, id: String) {
        items = items.map { if (it.folder == id) it.copy(folder = "") else it }
        folders = folders.filter { it.id != id }
        save(ctx)
    }
    fun moveItems(ctx: Context, ids: Set<String>, folder: String) {
        items = items.map { if (it.id in ids) it.copy(folder = folder) else it }
        save(ctx)
    }

    // ---- hapus permanen dari Asylum ----
    fun deleteItems(ctx: Context, list: List<AsyItem>) {
        val ids = list.map { it.id }.toSet()
        list.forEach {
            try { file(ctx, it).delete() } catch (_: Exception) {}
            ctx.getSharedPreferences("elarion", Context.MODE_PRIVATE).edit()
                .remove("pos_" + Uri.fromFile(file(ctx, it))).apply()
        }
        items = items.filter { it.id !in ids }
        save(ctx)
    }

    fun clearAll(ctx: Context) {
        dir(ctx).deleteRecursively()
        items = emptyList(); folders = emptyList()
        AsylumAuth.clear(ctx)
    }

    fun freeBytes(ctx: Context): Long = dir(ctx).usableSpace

    // ============================ MASUKKAN ============================
    /** Salin file ke Asylum, cocokkan ukurannya, baru minta galeri menghapus file aslinya. */
    fun startImport(ctx: Context, list: List<Media>, folder: String) {
        if (busy || list.isEmpty()) return
        val app = ctx.applicationContext
        cancelFlag = false
        busyLabel = "Memindahkan"; busyDone = 0; busyTotal = list.size; busyFraction = 0f
        scope.launch {
            val ok = ArrayList<Uri>()
            var failed = 0
            for (m in list) {
                if (cancelFlag) break
                busyName = m.fileName; busyFraction = 0f
                val id = java.util.UUID.randomUUID().toString().replace("-", "")
                val it = AsyItem(
                    id, m.fileName, !m.video, folder, m.size, m.durationMs,
                    System.currentTimeMillis() / 1000, m.path,
                    m.mime.ifBlank { guessMime(m.fileName, !m.video) }
                )
                val dest = file(app, it)
                val part = File(dest.path + ".part")
                try {
                    var copied = 0L
                    val total = maxOf(1L, m.size)
                    app.contentResolver.openInputStream(m.uri)!!.use { ins ->
                        part.outputStream().use { out ->
                            val buf = ByteArray(1 shl 17)
                            while (true) {
                                if (cancelFlag) throw InterruptedException()
                                val n = ins.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                copied += n
                                busyFraction = (copied.toFloat() / total).coerceIn(0f, 1f)
                            }
                        }
                    }
                    if (copied <= 0L || part.length() != copied) throw IllegalStateException("ukuran tidak cocok")
                    if (!part.renameTo(dest)) throw IllegalStateException("gagal menyimpan")
                    items = items + it.copy(size = copied)
                    save(app)
                    ok += m.uri
                } catch (e: InterruptedException) {
                    try { part.delete() } catch (_: Exception) {}
                    break
                } catch (e: Exception) {
                    try { part.delete() } catch (_: Exception) {}
                    failed++
                }
                busyDone++
            }
            busyLabel = ""; busyName = ""; busyFraction = 0f
            pendingOriginals = pendingOriginals + ok
            lastMessage = when {
                ok.isEmpty() && failed > 0 -> "Gagal memindahkan file."
                failed > 0 -> "${ok.size} file masuk Asylum, $failed gagal."
                else -> null
            }
            if (ok.isNotEmpty()) deleteTrigger++
        }
    }

    // ============================ PULIHKAN ============================
    fun startRestore(ctx: Context, list: List<AsyItem>) {
        if (busy || list.isEmpty()) return
        val app = ctx.applicationContext
        cancelFlag = false
        busyLabel = "Memulihkan"; busyDone = 0; busyTotal = list.size; busyFraction = 0f
        scope.launch {
            var ok = 0
            var failed = 0
            for (it in list) {
                if (cancelFlag) break
                busyName = it.name; busyFraction = 0f
                val good = try {
                    if (Build.VERSION.SDK_INT >= 29) restoreQ(app, it) else restoreLegacy(app, it)
                } catch (e: Exception) { false }
                if (good) {
                    ok++
                    try { file(app, it).delete() } catch (_: Exception) {}
                    app.getSharedPreferences("elarion", Context.MODE_PRIVATE).edit()
                        .remove("pos_" + Uri.fromFile(file(app, it))).apply()
                    items = items.filter { x -> x.id != it.id }
                    save(app)
                } else failed++
                busyDone++
            }
            busyLabel = ""; busyName = ""; busyFraction = 0f
            lastMessage = if (failed > 0) "$ok file dipulihkan, $failed gagal (tetap aman di Asylum)."
            else "$ok file dikembalikan ke galeri."
        }
    }

    private fun guessMime(name: String, photo: Boolean): String = when (Formats.ext(name)) {
        "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"
        "heic" -> "image/heic"; "heif" -> "image/heif"; "bmp" -> "image/bmp"
        else -> if (photo) "image/*" else "video/*"
    }

    private fun copyWithProgress(src: File, out: java.io.OutputStream) {
        val total = maxOf(1L, src.length())
        var done = 0L
        src.inputStream().use { ins ->
            val buf = ByteArray(1 shl 17)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                done += n
                busyFraction = (done.toFloat() / total).coerceIn(0f, 1f)
            }
        }
    }

    private fun restoreQ(ctx: Context, item: AsyItem): Boolean {
        val src = file(ctx, item)
        if (!src.exists()) return false
        val resolver = ctx.contentResolver
        val collection = if (item.photo) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val fallback = if (item.photo) "Pictures/Elarion/" else "Movies/Elarion/"
        val places = listOfNotNull(item.rel.takeIf { it.isNotBlank() }, fallback)
        for (rel in places) {
            var uri: Uri? = null
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                uri = resolver.insert(collection, cv) ?: continue
                resolver.openOutputStream(uri)!!.use { copyWithProgress(src, it) }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                return true
            } catch (e: Exception) {
                uri?.let { try { resolver.delete(it, null, null) } catch (_: Exception) {} }
            }
        }
        return false
    }

    private fun restoreLegacy(ctx: Context, item: AsyItem): Boolean {
        val src = file(ctx, item)
        if (!src.exists()) return false
        val orig = if (item.rel.isNotBlank()) File(item.rel) else null
        val base = if (orig != null && orig.isDirectory) orig else File(
            @Suppress("DEPRECATION")
            Environment.getExternalStoragePublicDirectory(
                if (item.photo) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES),
            "Elarion"
        ).also { it.mkdirs() }
        var dest = File(base, item.name)
        var n = 1
        while (dest.exists()) { dest = File(base, "${item.title} ($n).${item.ext}"); n++ }
        dest.outputStream().use { copyWithProgress(src, it) }
        if (dest.length() != src.length()) { dest.delete(); return false }
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), arrayOf(item.mime), null)
        return true
    }
}

/** Media "palsu" untuk berkas privat, supaya bisa memakai Thumb() dan pemutar video yang sudah ada. */
fun AsyItem.toMedia(ctx: Context): Media = Media(
    uri = Uri.fromFile(AsylumStore.file(ctx, this)), title = title, fileName = name, artist = null, album = null,
    durationMs = durationMs, size = size, dateAdded = added, mime = mime, path = "",
    width = 0, height = 0, video = !photo,
)

/** Daftar foto di galeri (untuk dipilih dan dimasukkan ke Asylum). */
object ImageScanner {
    val EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "heif", "bmp")

    fun images(ctx: Context): List<Media> {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cols = mutableListOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.MIME_TYPE
        )
        if (Build.VERSION.SDK_INT >= 29) cols += MediaStore.MediaColumns.RELATIVE_PATH
        else {
            @Suppress("DEPRECATION")
            cols += MediaStore.MediaColumns.DATA
        }
        val out = ArrayList<Media>()
        try {
            ctx.contentResolver.query(base, cols.toTypedArray(), null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                fun idx(n: String) = c.getColumnIndex(n)
                fun str(n: String): String? { val i = idx(n); return if (i >= 0) c.getString(i) else null }
                fun lng(n: String): Long { val i = idx(n); return if (i >= 0) c.getLong(i) else 0L }
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                while (c.moveToNext()) {
                    val name = str(MediaStore.MediaColumns.DISPLAY_NAME) ?: continue
                    if (Formats.ext(name) !in EXT) continue
                    val path = if (Build.VERSION.SDK_INT >= 29) str(MediaStore.MediaColumns.RELATIVE_PATH) ?: ""
                    else {
                        @Suppress("DEPRECATION")
                        (str(MediaStore.MediaColumns.DATA) ?: "").substringBeforeLast('/')
                    }
                    out += Media(
                        uri = android.content.ContentUris.withAppendedId(base, c.getLong(iId)),
                        title = name.substringBeforeLast('.'), fileName = name, artist = null, album = null,
                        durationMs = 0L, size = lng(MediaStore.MediaColumns.SIZE),
                        dateAdded = lng(MediaStore.MediaColumns.DATE_ADDED),
                        mime = str(MediaStore.MediaColumns.MIME_TYPE) ?: "", path = path,
                        width = 0, height = 0, video = false,
                    )
                }
            }
        } catch (_: Exception) {}
        return out
    }
}
