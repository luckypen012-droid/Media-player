@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun hasAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** Getaran singkat sebagai penanda (mis. masuk mode pilih). */
private fun vibrate(ctx: Context, ms: Long = 45) {
    try {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (_: Exception) {}
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    var ok by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = hasAccess(ctx)
    }
    LaunchedEffect(Unit) { if (!ok) launcher.launch(perms) }

    if (ok) Library() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Elarion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Izinkan akses ke video dan audio agar Elarion bisa menampilkan file di perangkatmu. Semua tetap offline.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Beri izin") }
    }
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("elarion", Context.MODE_PRIVATE) }
    val focusManager = LocalFocusManager.current

    var tab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf(emptyList<Media>()) }
    var audios by remember { mutableStateOf(emptyList<Media>()) }
    var loading by remember { mutableStateOf(true) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            audios = Scanner.audios(ctx)
        }
        loading = false
    }

    // ---- Favorit ----
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet()) }
    fun saveFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s.toSet()).apply() }
    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        saveFavs(if (k in favs) favs - k else favs + k)
    }
    fun setFavs(items: List<Media>, add: Boolean) {
        val keys = items.map { it.uri.toString() }
        saveFavs(if (add) favs + keys else favs - keys.toSet())
    }

    // ---- Urutan ----
    var sortKey by remember { mutableStateOf(prefs.getString("sort_key", "date") ?: "date") }
    var sortAsc by remember { mutableStateOf(prefs.getBoolean("sort_asc", false)) }
    var sortMenu by remember { mutableStateOf(false) }

    // ---- Pencarian ----
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val searchFocus = remember { FocusRequester() }
    LaunchedEffect(searching) {
        if (searching) {
            delay(120)
            try { searchFocus.requestFocus() } catch (_: Exception) {}
        }
    }

    // ---- Mode pilih (tekan lama) ----
    var selectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    fun exitSelect() { selectMode = false; selected = emptySet() }
    fun toggleSel(m: Media) {
        val k = m.uri.toString()
        selected = if (k in selected) selected - k else selected + k
    }
    fun switchTab(i: Int) { tab = i; query = ""; searching = false; exitSelect() }

    BackHandler(enabled = selectMode) { exitSelect() }
    BackHandler(enabled = searching && !selectMode) { searching = false; query = "" }

    // ---- Koneksi ke layanan audio ----
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var lastSeek by remember { mutableLongStateOf(0L) }
    var showNow by remember { mutableStateOf(false) }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                title = mediaMetadata.title?.toString() ?: ""
                artist = mediaMetadata.artist?.toString() ?: ""
            }
        }
        c.addListener(l)
        playing = c.isPlaying
        title = c.mediaMetadata.title?.toString() ?: ""
        artist = c.mediaMetadata.artist?.toString() ?: ""
        onDispose { c.removeListener(l) }
    }

    LaunchedEffect(controller) {
        while (isActive) {
            controller?.let { c ->
                if (SystemClock.elapsedRealtime() - lastSeek > 800) pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }

    val onSeek: (Long) -> Unit = { t ->
        controller?.seekTo(t)
        pos = t
        lastSeek = SystemClock.elapsedRealtime()
    }

    // ---- Hapus (satu atau banyak) ----
    var infoFor by remember { mutableStateOf<Media?>(null) }
    var menuFor by remember { mutableStateOf<Media?>(null) }
    var deleteFor by remember { mutableStateOf<List<Media>?>(null) }
    var pendingDelete by remember { mutableStateOf<List<Media>>(emptyList()) }
    var delDone by remember { mutableIntStateOf(0) }
    var legacyRetry by remember { mutableIntStateOf(0) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val items = pendingDelete
        if (Build.VERSION.SDK_INT >= 30) {
            if (res.resultCode == Activity.RESULT_OK) {
                saveFavs(favs - items.map { it.uri.toString() }.toSet())
                reloadKey++
                Toast.makeText(ctx, "${items.size} file dihapus", Toast.LENGTH_SHORT).show()
            }
            pendingDelete = emptyList()
        } else {
            if (res.resultCode == Activity.RESULT_OK) legacyRetry++
            else { pendingDelete = emptyList(); reloadKey++ }
        }
    }

    // Android 10 ke bawah: hapus satu per satu
    fun legacyDeleteNext() {
        var q = pendingDelete
        while (q.isNotEmpty()) {
            val m = q.first()
            try {
                ctx.contentResolver.delete(m.uri, null, null)
                delDone++
                saveFavs(favs - m.uri.toString())
                q = q.drop(1)
                pendingDelete = q
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pendingDelete = q
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                    return
                }
                q = q.drop(1)
            } catch (e: Exception) {
                q = q.drop(1)
            }
        }
        pendingDelete = emptyList()
        reloadKey++
        Toast.makeText(ctx, "$delDone file dihapus", Toast.LENGTH_SHORT).show()
    }
    LaunchedEffect(legacyRetry) { if (legacyRetry > 0) legacyDeleteNext() }

    fun requestDelete(items: List<Media>) {
        if (items.isEmpty()) return
        delDone = 0
        pendingDelete = items
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, items.map { it.uri })
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                pendingDelete = emptyList()
                Toast.makeText(ctx, "Gagal menghapus file", Toast.LENGTH_LONG).show()
            }
        } else {
            legacyDeleteNext()
        }
    }

    // ---- Bagikan (satu atau banyak) ----
    fun share(items: List<Media>) {
        if (items.isEmpty()) return
        val send = if (items.size == 1) {
            val m = items[0]
            Intent(Intent.ACTION_SEND).apply {
                type = m.mime.ifBlank { if (m.video) "video/*" else "audio/*" }
                putExtra(Intent.EXTRA_STREAM, m.uri)
                clipData = ClipData.newRawUri(null, m.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            val uris = ArrayList(items.map { it.uri })
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = when {
                    items.all { it.video } -> "video/*"
                    items.none { it.video } -> "audio/*"
                    else -> "*/*"
                }
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                val cd = ClipData.newRawUri(null, uris[0])
                for (i in 1 until uris.size) cd.addItem(ClipData.Item(uris[i]))
                clipData = cd
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        ctx.startActivity(Intent.createChooser(send,
            if (items.size == 1) "Bagikan ${items[0].title}" else "Bagikan ${items.size} file"))
    }

    fun open(m: Media, siblings: List<Media>) {
        if (m.video) {
            controller?.pause()
            ctx.startActivity(Intent(ctx, VideoPlayerActivity::class.java).setData(m.uri))
        } else {
            controller?.let { c ->
                val q = siblings.filter { !it.video }
                c.setMediaItems(q.map { it.toItem() }, q.indexOf(m).coerceAtLeast(0), 0L)
                c.prepare(); c.play()
            }
        }
    }

    // ---- Daftar yang ditampilkan: cari + urutkan ----
    val allMedia = videos + audios
    val base = when (tab) {
        0 -> videos
        1 -> audios
        else -> allMedia.filter { it.uri.toString() in favs }
    }
    val list = remember(base, query, sortKey, sortAsc) {
        val q = query.trim().lowercase()
        val filtered = if (q.isEmpty()) base else base.filter {
            it.title.lowercase().contains(q) || it.fileName.lowercase().contains(q) ||
                (it.artist?.lowercase()?.contains(q) == true) || (it.album?.lowercase()?.contains(q) == true)
        }
        val cmp: Comparator<Media> = when (sortKey) {
            "name" -> compareBy<Media> { it.title.lowercase() }
            "size" -> compareBy<Media> { it.size }
            else -> compareBy<Media> { it.dateAdded }
        }
        val sorted = filtered.sortedWith(cmp)
        if (sortAsc) sorted else sorted.reversed()
    }
    val favCount = allMedia.count { it.uri.toString() in favs }
    val selectedItems = allMedia.filter { it.uri.toString() in selected }
    val allVisibleSelected = list.isNotEmpty() && list.all { it.uri.toString() in selected }
    val allSelectedAreFav = selectedItems.isNotEmpty() && selectedItems.all { it.uri.toString() in favs }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { switchTab(0) }, text = { Text("Video (${videos.size})") })
                Tab(selected = tab == 1, onClick = { switchTab(1) }, text = { Text("Audio (${audios.size})") })
                Tab(selected = tab == 2, onClick = { switchTab(2) }, text = { Text("Favorit ($favCount)") })
            }

            if (selectMode) {
                // Bilah atas mode pilih
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { exitSelect() }) { Text("✕") }
                    Text("${selected.size} dipilih", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = {
                        selected = if (allVisibleSelected) selected - list.map { it.uri.toString() }.toSet()
                        else selected + list.map { it.uri.toString() }
                    }) { Text(if (allVisibleSelected) "Batalkan semua" else "Pilih semua") }
                }
            } else {
                // Baris cari + urutan
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        searching = !searching
                        if (!searching) query = ""
                    }) { Text(if (searching) "✕ Tutup" else "🔍 Cari") }
                    Text("${list.size} file", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box {
                        val label = when (sortKey) { "name" -> "Nama"; "size" -> "Ukuran"; else -> "Tanggal" }
                        TextButton(onClick = { sortMenu = true }) {
                            Text("Urutkan: $label ${if (sortAsc) "↑" else "↓"}")
                        }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            listOf("date" to "Tanggal", "name" to "Nama", "size" to "Ukuran").forEach { (k, l) ->
                                DropdownMenuItem(
                                    text = { Text(if (k == sortKey) "✓ $l ${if (sortAsc) "↑" else "↓"}" else l) },
                                    onClick = {
                                        if (k == sortKey) sortAsc = !sortAsc
                                        else { sortKey = k; sortAsc = (k == "name") }
                                        prefs.edit().putString("sort_key", sortKey).putBoolean("sort_asc", sortAsc).apply()
                                        sortMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
                if (searching) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                            .focusRequester(searchFocus),
                        singleLine = true,
                        placeholder = {
                            Text(when (tab) { 0 -> "Cari video…"; 1 -> "Cari audio…"; else -> "Cari di favorit…" })
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("✕") }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
                    )
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (!loading && list.isEmpty()) {
                    Text(
                        when {
                            query.isNotBlank() -> "Tidak ada hasil untuk \"$query\"."
                            tab == 0 -> "Belum ada file MP4 / MKV ditemukan."
                            tab == 1 -> "Belum ada file MP3 / OPUS ditemukan."
                            else -> "Belum ada favorit. Tekan lama sebuah file, atau ketuk ⋮, lalu pilih favorit."
                        },
                        Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(list, key = { _, m -> m.uri.toString() }) { _, m ->
                        val key = m.uri.toString()
                        val isFav = key in favs
                        val isSel = key in selected
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent)
                                .combinedClickable(
                                    onClick = { if (selectMode) toggleSel(m) else open(m, list) },
                                    onLongClick = {
                                        if (!selectMode) {
                                            selectMode = true
                                            selected = setOf(key)
                                            vibrate(ctx)
                                        } else toggleSel(m)
                                    }
                                )
                                .padding(start = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectMode) {
                                Checkbox(checked = isSel, onCheckedChange = { toggleSel(m) })
                                Spacer(Modifier.width(4.dp))
                            }
                            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                Text((if (isFav) "★ " else "") + m.title, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                val sub = listOfNotNull(
                                    if (tab == 2) (if (m.video) "Video" else "Audio") else null,
                                    m.artist, fmt(m.durationMs), fmtSize(m.size)
                                ).joinToString(" • ")
                                Text(sub, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (!selectMode) {
                                Box {
                                    IconButton(onClick = { menuFor = m }) { Text("⋮", fontSize = 22.sp) }
                                    DropdownMenu(expanded = menuFor == m, onDismissRequest = { menuFor = null }) {
                                        DropdownMenuItem(text = { Text("Bagikan") },
                                            onClick = { menuFor = null; share(listOf(m)) })
                                        DropdownMenuItem(
                                            text = { Text(if (isFav) "Hapus dari favorit" else "Tambah ke favorit") },
                                            onClick = { menuFor = null; toggleFav(m) })
                                        DropdownMenuItem(text = { Text("Info") },
                                            onClick = { menuFor = null; infoFor = m })
                                        DropdownMenuItem(text = { Text("Hapus") }, onClick = {
                                            menuFor = null
                                            if (Build.VERSION.SDK_INT >= 30) requestDelete(listOf(m))
                                            else deleteFor = listOf(m)
                                        })
                                    }
                                }
                            } else Spacer(Modifier.width(16.dp))
                        }
                        HorizontalDivider()
                    }
                }
            }

            // Bilah aksi bawah (mode pilih), dekat jempol
            if (selectMode) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { share(selectedItems) },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text("Bagikan") }
                    TextButton(
                        onClick = { setFavs(selectedItems, !allSelectedAreFav) },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text(if (allSelectedAreFav) "Hapus favorit" else "★ Favorit") }
                    TextButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 30) { requestDelete(selectedItems); exitSelect() }
                            else deleteFor = selectedItems
                        },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text("Hapus") }
                }
            }

            val c = controller
            if (c != null && title.isNotBlank()) {
                MiniPlayer(c, title, playing, pos, dur, onSeek, onOpen = { showNow = true })
            }
        }

        val c = controller
        if (showNow && c != null && title.isNotBlank()) {
            NowPlaying(c, title, artist, playing, pos, dur, onSeek, onClose = { showNow = false })
        }
    }

    // ---- Dialog Info ----
    infoFor?.let { m ->
        var dims by remember(m) { mutableStateOf<Pair<Int, Int>?>(null) }
        if (m.video) {
            LaunchedEffect(m) { dims = withContext(Dispatchers.IO) { loadVideoSize(ctx, m.uri) } }
        }
        AlertDialog(
            onDismissRequest = { infoFor = null },
            title = { Text("Info ${if (m.video) "video" else "audio"}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    infoLines(m, dims).forEach { (k, v) ->
                        Text(k, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { infoFor = null }) { Text("Tutup") } }
        )
    }

    // ---- Konfirmasi hapus (Android 10 ke bawah; Android 11+ memakai dialog sistem) ----
    deleteFor?.let { items ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text(if (items.size == 1) "Hapus file?" else "Hapus ${items.size} file?") },
            text = {
                Text(
                    if (items.size == 1) "\"${items[0].fileName}\" akan dihapus dari perangkat dan tidak bisa dikembalikan."
                    else "${items.size} file akan dihapus dari perangkat dan tidak bisa dikembalikan."
                )
            },
            confirmButton = {
                TextButton(onClick = { deleteFor = null; exitSelect(); requestDelete(items) }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal") } }
        )
    }
}

/** Seekbar halus: thumb mengikuti jari, seek hanya sekali saat jari dilepas. */
@Composable
fun SeekBar(pos: Long, dur: Long, preview: Long? = null, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shownFrac = if (preview != null && dur > 0) (preview.toFloat() / dur).coerceIn(0f, 1f) else (drag ?: frac)
    val shownMs = preview ?: drag?.let { (it * dur).toLong() } ?: pos
    Column {
        Slider(
            value = shownFrac,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { if (dur > 0) onSeek((it * dur).toLong()) }
                drag = null
            }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween) {
            Text(fmt(shownMs), style = MaterialTheme.typography.bodySmall)
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MiniPlayer(
    c: MediaController, title: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onOpen: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp)
    ) {
        Text("▲  $title", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp))
        SeekBar(pos, dur, null, onSeek)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) { Text(if (playing) "⏸" else "▶") }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭") }
        }
    }
}

/** Layar pemutar audio penuh. Geser kiri/kanan di MANA SAJA untuk maju/mundur. */
@Composable
fun NowPlaying(
    c: MediaController, title: String, artist: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    var swipe by remember { mutableStateOf<Long?>(null) }
    val posNow by rememberUpdatedState(pos)
    val durNow by rememberUpdatedState(dur)
    val seekNow by rememberUpdatedState(onSeek)

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                var start = 0L
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { start = posNow; total = 0f; swipe = start },
                    onDragEnd = { swipe?.let { seekNow(it) }; swipe = null },
                    onDragCancel = { swipe = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                        swipe = (start + total / size.width * 120_000f).toLong().coerceIn(0L, durNow)
                    }
                )
            }
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("⌄ Tutup", Modifier.align(Alignment.Start).clickable(onClick = onClose).padding(8.dp))
        Spacer(Modifier.weight(1f))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
        if (artist.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(artist, style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(32.dp))
        SeekBar(pos, dur, swipe, onSeek)
        Text("Geser kiri/kanan di mana saja untuk maju/mundur",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮", style = MaterialTheme.typography.headlineMedium) }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) {
                Text(if (playing) "⏸" else "▶", style = MaterialTheme.typography.headlineLarge)
            }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", style = MaterialTheme.typography.headlineMedium) }
        }
        Spacer(Modifier.weight(1f))
    }
}
