package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun hasAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    var ok by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = hasAccess(ctx)
    }
    LaunchedEffect(Unit) { if (!ok) launcher.launch(perms) }

    if (ok) Library() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Elarion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Izinkan akses ke video dan audio agar Elarion bisa menampilkan file di perangkatmu. Semua tetap offline.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Beri izin") }
    }
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("elarion", Context.MODE_PRIVATE) }

    var tab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf(emptyList<Media>()) }
    var audios by remember { mutableStateOf(emptyList<Media>()) }
    var loading by remember { mutableStateOf(true) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            audios = Scanner.audios(ctx)
        }
        loading = false
    }

    // ---- Favorit (disimpan di perangkat) ----
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet()) }
    fun saveFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s.toSet()).apply() }
    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        saveFavs(if (k in favs) favs - k else favs + k)
    }

    // ---- Urutan (disimpan di perangkat) ----
    var sortKey by remember { mutableStateOf(prefs.getString("sort_key", "date") ?: "date") }
    var sortAsc by remember { mutableStateOf(prefs.getBoolean("sort_asc", false)) }
    var sortMenu by remember { mutableStateOf(false) }

    // ---- Koneksi ke layanan audio ----
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var lastSeek by remember { mutableLongStateOf(0L) }
    var showNow by remember { mutableStateOf(false) }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                title = mediaMetadata.title?.toString() ?: ""
                artist = mediaMetadata.artist?.toString() ?: ""
            }
        }
        c.addListener(l)
        playing = c.isPlaying
        title = c.mediaMetadata.title?.toString() ?: ""
        artist = c.mediaMetadata.artist?.toString() ?: ""
        onDispose { c.removeListener(l) }
    }

    LaunchedEffect(controller) {
        while (isActive) {
            controller?.let { c ->
                if (SystemClock.elapsedRealtime() - lastSeek > 800) pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }

    val onSeek: (Long) -> Unit = { t ->
        controller?.seekTo(t)
        pos = t
        lastSeek = SystemClock.elapsedRealtime()
    }

    // ---- Menu titik tiga: hapus / bagikan / favorit / info ----
    var menuFor by remember { mutableStateOf<Media?>(null) }
    var infoFor by remember { mutableStateOf<Media?>(null) }
    var deleteFor by remember { mutableStateOf<Media?>(null) }
    var pendingDelete by remember { mutableStateOf<Media?>(null) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val m = pendingDelete
        if (res.resultCode == Activity.RESULT_OK && m != null) {
            if (Build.VERSION.SDK_INT == 29) {
                try { ctx.contentResolver.delete(m.uri, null, null) } catch (_: Exception) {}
            }
            saveFavs(favs - m.uri.toString())
            reloadKey++
            Toast.makeText(ctx, "File dihapus", Toast.LENGTH_SHORT).show()
        }
        pendingDelete = null
    }

    fun doDelete(m: Media) {
        pendingDelete = m
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, listOf(m.uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                ctx.contentResolver.delete(m.uri, null, null)
                saveFavs(favs - m.uri.toString())
                reloadKey++
                pendingDelete = null
                Toast.makeText(ctx, "File dihapus", Toast.LENGTH_SHORT).show()
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
            } else {
                pendingDelete = null
                Toast.makeText(ctx, "Tidak bisa menghapus: izin ditolak", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            pendingDelete = null
            Toast.makeText(ctx, "Gagal menghapus file", Toast.LENGTH_LONG).show()
        }
    }

    fun share(m: Media) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = m.mime.ifBlank { if (m.video) "video/*" else "audio/*" }
            putExtra(Intent.EXTRA_STREAM, m.uri)
            clipData = ClipData.newRawUri(null, m.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Bagikan ${m.title}"))
    }

    fun open(m: Media, siblings: List<Media>) {
        if (m.video) {
            controller?.pause()
            ctx.startActivity(Intent(ctx, VideoPlayerActivity::class.java).setData(m.uri))
        } else {
            controller?.let { c ->
                val q = siblings.filter { !it.video }
                c.setMediaItems(q.map { it.toItem() }, q.indexOf(m).coerceAtLeast(0), 0L)
                c.prepare(); c.play()
            }
        }
    }

    // ---- Daftar yang ditampilkan ----
    val base = when (tab) {
        0 -> videos
        1 -> audios
        else -> (videos + audios).filter { it.uri.toString() in favs }
    }
    val list = remember(base, sortKey, sortAsc) {
        val cmp: Comparator<Media> = when (sortKey) {
            "name" -> compareBy<Media> { it.title.lowercase() }
            "size" -> compareBy<Media> { it.size }
            else -> compareBy<Media> { it.dateAdded }
        }
        val sorted = base.sortedWith(cmp)
        if (sortAsc) sorted else sorted.reversed()
    }
    val favCount = (videos + audios).count { it.uri.toString() in favs }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Video (${videos.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Audio (${audios.size})") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Favorit ($favCount)") })
            }

            // Baris urutan
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                Text("${list.size} file", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Box {
                    val label = when (sortKey) { "name" -> "Nama"; "size" -> "Ukuran"; else -> "Tanggal" }
                    TextButton(onClick = { sortMenu = true }) {
                        Text("Urutkan: $label ${if (sortAsc) "↑" else "↓"}")
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("date" to "Tanggal", "name" to "Nama", "size" to "Ukuran").forEach { (k, l) ->
                            DropdownMenuItem(
                                text = { Text(if (k == sortKey) "✓ $l ${if (sortAsc) "↑" else "↓"}" else l) },
                                onClick = {
                                    if (k == sortKey) sortAsc = !sortAsc
                                    else { sortKey = k; sortAsc = (k == "name") }
                                    prefs.edit().putString("sort_key", sortKey).putBoolean("sort_asc", sortAsc).apply()
                                    sortMenu = false
                                }
                            )
                        }
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (!loading && list.isEmpty()) {
                    Text(
                        when (tab) {
                            0 -> "Belum ada file MP4 / MKV ditemukan."
                            1 -> "Belum ada file MP3 / OPUS ditemukan."
                            else -> "Belum ada favorit. Ketuk ⋮ pada sebuah file, lalu pilih Tambah ke favorit."
                        },
                        Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(list, key = { _, m -> m.uri.toString() }) { _, m ->
                        val isFav = m.uri.toString() in favs
                        Row(
                            Modifier.fillMaxWidth().clickable { open(m, list) }.padding(start = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                Text((if (isFav) "★ " else "") + m.title, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                val sub = listOfNotNull(
                                    if (tab == 2) (if (m.video) "Video" else "Audio") else null,
                                    m.artist, fmt(m.durationMs), fmtSize(m.size)
                                ).joinToString(" • ")
                                Text(sub, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box {
                                IconButton(onClick = { menuFor = m }) { Text("⋮", fontSize = 22.sp) }
                                DropdownMenu(expanded = menuFor == m, onDismissRequest = { menuFor = null }) {
                                    DropdownMenuItem(text = { Text("Bagikan") },
                                        onClick = { menuFor = null; share(m) })
                                    DropdownMenuItem(
                                        text = { Text(if (isFav) "Hapus dari favorit" else "Tambah ke favorit") },
                                        onClick = { menuFor = null; toggleFav(m) })
                                    DropdownMenuItem(text = { Text("Info") },
                                        onClick = { menuFor = null; infoFor = m })
                                    DropdownMenuItem(text = { Text("Hapus") }, onClick = {
                                        menuFor = null
                                        if (Build.VERSION.SDK_INT >= 30) doDelete(m) else deleteFor = m
                                    })
                                }
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
            val c = controller
            if (c != null && title.isNotBlank()) {
                MiniPlayer(c, title, playing, pos, dur, onSeek, onOpen = { showNow = true })
            }
        }

        val c = controller
        if (showNow && c != null && title.isNotBlank()) {
            NowPlaying(c, title, artist, playing, pos, dur, onSeek, onClose = { showNow = false })
        }
    }

    // ---- Dialog Info ----
    infoFor?.let { m ->
        AlertDialog(
            onDismissRequest = { infoFor = null },
            title = { Text("Info ${if (m.video) "video" else "audio"}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    infoLines(m).forEach { (k, v) ->
                        Text(k, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { infoFor = null }) { Text("Tutup") } }
        )
    }

    // ---- Konfirmasi hapus (Android 10 ke bawah; Android 11+ memakai dialog sistem) ----
    deleteFor?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Hapus file?") },
            text = { Text("\"${m.fileName}\" akan dihapus dari perangkat dan tidak bisa dikembalikan.") },
            confirmButton = { TextButton(onClick = { deleteFor = null; doDelete(m) }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal") } }
        )
    }
}

/** Seekbar halus: thumb mengikuti jari, seek hanya sekali saat jari dilepas. */
@Composable
fun SeekBar(pos: Long, dur: Long, preview: Long? = null, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shownFrac = if (preview != null && dur > 0) (preview.toFloat() / dur).coerceIn(0f, 1f) else (drag ?: frac)
    val shownMs = preview ?: drag?.let { (it * dur).toLong() } ?: pos
    Column {
        Slider(
            value = shownFrac,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { if (dur > 0) onSeek((it * dur).toLong()) }
                drag = null
            }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween) {
            Text(fmt(shownMs), style = MaterialTheme.typography.bodySmall)
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MiniPlayer(
    c: MediaController, title: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onOpen: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp)
    ) {
        Text("▲  $title", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp))
        SeekBar(pos, dur, null, onSeek)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) { Text(if (playing) "⏸" else "▶") }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭") }
        }
    }
}

/** Layar pemutar audio penuh. Geser kiri/kanan di MANA SAJA untuk maju/mundur. */
@Composable
fun NowPlaying(
    c: MediaController, title: String, artist: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    var swipe by remember { mutableStateOf<Long?>(null) }
    val posNow by rememberUpdatedState(pos)
    val durNow by rememberUpdatedState(dur)
    val seekNow by rememberUpdatedState(onSeek)

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                var start = 0L
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { start = posNow; total = 0f; swipe = start },
                    onDragEnd = { swipe?.let { seekNow(it) }; swipe = null },
                    onDragCancel = { swipe = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                        swipe = (start + total / size.width * 120_000f).toLong().coerceIn(0L, durNow)
                    }
                )
            }
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("⌄ Tutup", Modifier.align(Alignment.Start).clickable(onClick = onClose).padding(8.dp))
        Spacer(Modifier.weight(1f))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
        if (artist.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(artist, style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(32.dp))
        SeekBar(pos, dur, swipe, onSeek)
        Text("Geser kiri/kanan di mana saja untuk maju/mundur",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮", style = MaterialTheme.typography.headlineMedium) }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) {
                Text(if (playing) "⏸" else "▶", style = MaterialTheme.typography.headlineLarge)
            }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", style = MaterialTheme.typography.headlineMedium) }
        }
        Spacer(Modifier.weight(1f))
    }
}
