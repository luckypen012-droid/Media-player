@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun hasAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** Getaran singkat sebagai penanda (mis. masuk mode pilih). */
private fun vibrate(ctx: Context, ms: Long = 45) {
    try {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (_: Exception) {}
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    var ok by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = hasAccess(ctx)
    }
    LaunchedEffect(Unit) { if (!ok) launcher.launch(perms) }

    if (ok) Library() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Elarion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Izinkan akses ke video dan musik agar Elarion bisa menampilkan file di perangkatmu. Semua tetap offline.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Beri izin") }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            label, fontSize = 14.sp,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun FolderRow(g: FolderGroup, onClick: () -> Unit) {
    val first = g.items.maxByOrNull { it.dateAdded } ?: g.items.first()
    val unit = if (first.video) "video" else "musik"
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(first, Modifier.size(72.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(g.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text("${g.items.size} $unit", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider()
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("elarion", Context.MODE_PRIVATE) }
    val playPrefs = remember { ctx.getSharedPreferences("elarion_plays", Context.MODE_PRIVATE) }
    val focusManager = LocalFocusManager.current

    // 0 = Video, 1 = Musik, 2 = Favorit (menu bawah)
    var tab by remember { mutableIntStateOf(0) }
    // 0 = Semua, 1 = Folder, 2 = Sering diputar (chip, hanya untuk Video/Musik)
    var mode by remember { mutableIntStateOf(0) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    val effMode = if (tab == 2) 0 else mode

    var videos by remember { mutableStateOf(emptyList<Media>()) }
    var audios by remember { mutableStateOf(emptyList<Media>()) }
    var loading by remember { mutableStateOf(true) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            audios = Scanner.audios(ctx)
        }
        loading = false
    }

    // ---- Favorit ----
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet()) }
    fun saveFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s.toSet()).apply() }
    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        saveFavs(if (k in favs) favs - k else favs + k)
    }
    fun setFavs(items: List<Media>, add: Boolean) {
        val keys = items.map { it.uri.toString() }
        saveFavs(if (add) favs + keys else favs - keys.toSet())
    }

    // ---- Jumlah putar (untuk "Sering diputar") ----
    fun readPlays(): Map<String, Int> =
        playPrefs.all.mapNotNull { (k, v) -> (v as? Int)?.let { k to it } }.toMap()
    var plays by remember { mutableStateOf(readPlays()) }
    fun addPlay(id: String) {
        playPrefs.edit().putInt(id, playPrefs.getInt(id, 0) + 1).apply()
        plays = readPlays()
    }

    // ---- Urutan ----
    var sortKey by remember { mutableStateOf(prefs.getString("sort_key", "date") ?: "date") }
    var sortAsc by remember { mutableStateOf(prefs.getBoolean("sort_asc", false)) }
    var sortMenu by remember { mutableStateOf(false) }

    // ---- Pencarian ----
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val searchFocus = remember { FocusRequester() }
    LaunchedEffect(searching) {
        if (searching) {
            delay(120)
            try { searchFocus.requestFocus() } catch (_: Exception) {}
        }
    }

    // ---- Mode pilih (tekan lama) ----
    var selectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    fun exitSelect() { selectMode = false; selected = emptySet() }
    fun toggleSel(m: Media) {
        val k = m.uri.toString()
        selected = if (k in selected) selected - k else selected + k
    }
    fun switchTab(i: Int) { tab = i; openFolder = null; query = ""; searching = false; exitSelect() }

    BackHandler(enabled = searching && !selectMode) { searching = false; query = "" }
    BackHandler(enabled = openFolder != null && !selectMode) { openFolder = null }
    BackHandler(enabled = selectMode) { exitSelect() }

    // ---- Koneksi ke layanan musik ----
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var currentId by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var lastSeek by remember { mutableLongStateOf(0L) }
    var showNow by remember { mutableStateOf(false) }

    // ---- Mode putar: berurutan / ulangi semua / ulangi satu / acak ----
    var playMode by remember { mutableIntStateOf(prefs.getInt("play_mode", 0)) }
    LaunchedEffect(controller, playMode) { controller?.let { applyMode(it, playMode) } }
    fun cycleMode() {
        playMode = (playMode + 1) % 4
        prefs.edit().putInt("play_mode", playMode).apply()
        Toast.makeText(ctx, playModeName(playMode), Toast.LENGTH_SHORT).show()
    }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentId = mediaItem?.mediaId ?: ""
            }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                title = mediaMetadata.title?.toString() ?: ""
                artist = mediaMetadata.artist?.toString() ?: ""
            }
        }
        c.addListener(l)
        playing = c.isPlaying
        currentId = c.currentMediaItem?.mediaId ?: ""
        title = c.mediaMetadata.title?.toString() ?: ""
        artist = c.mediaMetadata.artist?.toString() ?: ""
        onDispose { c.removeListener(l) }
    }

    // Muat ulang jumlah putar saat lagu berganti atau chip diganti
    LaunchedEffect(title, effMode) { plays = readPlays() }

    LaunchedEffect(controller) {
        while (isActive) {
            controller?.let { c ->
                if (SystemClock.elapsedRealtime() - lastSeek > 800) pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }

    val onSeek: (Long) -> Unit = { t ->
        controller?.seekTo(t)
        pos = t
        lastSeek = SystemClock.elapsedRealtime()
    }

    // ---- Hapus (satu atau banyak) ----
    var infoFor by remember { mutableStateOf<Media?>(null) }
    var menuFor by remember { mutableStateOf<Media?>(null) }
    var deleteFor by remember { mutableStateOf<List<Media>?>(null) }
    var pendingDelete by remember { mutableStateOf<List<Media>>(emptyList()) }
    var delDone by remember { mutableIntStateOf(0) }
    var legacyRetry by remember { mutableIntStateOf(0) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val items = pendingDelete
        if (Build.VERSION.SDK_INT >= 30) {
            if (res.resultCode == Activity.RESULT_OK) {
                saveFavs(favs - items.map { it.uri.toString() }.toSet())
                reloadKey++
                Toast.makeText(ctx, "${items.size} file dihapus", Toast.LENGTH_SHORT).show()
            }
            pendingDelete = emptyList()
        } else {
            if (res.resultCode == Activity.RESULT_OK) legacyRetry++
            else { pendingDelete = emptyList(); reloadKey++ }
        }
    }

    // Android 10 ke bawah: hapus satu per satu
    fun legacyDeleteNext() {
        var q = pendingDelete
        while (q.isNotEmpty()) {
            val m = q.first()
            try {
                ctx.contentResolver.delete(m.uri, null, null)
                delDone++
                saveFavs(favs - m.uri.toString())
                q = q.drop(1)
                pendingDelete = q
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pendingDelete = q
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                    return
                }
                q = q.drop(1)
            } catch (e: Exception) {
                q = q.drop(1)
            }
        }
        pendingDelete = emptyList()
        reloadKey++
        Toast.makeText(ctx, "$delDone file dihapus", Toast.LENGTH_SHORT).show()
    }
    LaunchedEffect(legacyRetry) { if (legacyRetry > 0) legacyDeleteNext() }

    fun requestDelete(items: List<Media>) {
        if (items.isEmpty()) return
        delDone = 0
        pendingDelete = items
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, items.map { it.uri })
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                pendingDelete = emptyList()
                Toast.makeText(ctx, "Gagal menghapus file", Toast.LENGTH_LONG).show()
            }
        } else {
            legacyDeleteNext()
        }
    }

    // ---- Bagikan (satu atau banyak) ----
    fun share(items: List<Media>) {
        if (items.isEmpty()) return
        val send = if (items.size == 1) {
            val m = items[0]
            Intent(Intent.ACTION_SEND).apply {
                type = m.mime.ifBlank { if (m.video) "video/*" else "audio/*" }
                putExtra(Intent.EXTRA_STREAM, m.uri)
                clipData = ClipData.newRawUri(null, m.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            val uris = ArrayList(items.map { it.uri })
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = when {
                    items.all { it.video } -> "video/*"
                    items.none { it.video } -> "audio/*"
                    else -> "*/*"
                }
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                val cd = ClipData.newRawUri(null, uris[0])
                for (i in 1 until uris.size) cd.addItem(ClipData.Item(uris[i]))
                clipData = cd
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        ctx.startActivity(Intent.createChooser(send,
            if (items.size == 1) "Bagikan ${items[0].title}" else "Bagikan ${items.size} file"))
    }

    fun open(m: Media, siblings: List<Media>) {
        if (m.video) {
            controller?.pause()
            addPlay(m.uri.toString())
            ctx.startActivity(Intent(ctx, VideoPlayerActivity::class.java).setData(m.uri))
        } else {
            controller?.let { c ->
                val q = siblings.filter { !it.video }
                c.setMediaItems(q.map { it.toItem() }, q.indexOf(m).coerceAtLeast(0), 0L)
                c.prepare(); c.play()
            }
        }
    }

    // ---- Daftar yang ditampilkan: cari, urutkan, folder, sering diputar ----
    val allMedia = videos + audios
    val base = when (tab) {
        0 -> videos
        1 -> audios
        else -> allMedia.filter { it.uri.toString() in favs }
    }
    val filtered = remember(base, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) base else base.filter {
            it.title.lowercase().contains(q) || it.fileName.lowercase().contains(q) ||
                (it.artist?.lowercase()?.contains(q) == true) || (it.album?.lowercase()?.contains(q) == true)
        }
    }
    val flat = remember(filtered, sortKey, sortAsc) {
        val cmp: Comparator<Media> = when (sortKey) {
            "name" -> compareBy<Media> { it.title.lowercase() }
            "size" -> compareBy<Media> { it.size }
            else -> compareBy<Media> { it.dateAdded }
        }
        val sorted = filtered.sortedWith(cmp)
        if (sortAsc) sorted else sorted.reversed()
    }
    val folderGroups = remember(filtered, sortKey, sortAsc) {
        val groups = filtered.groupBy { it.folderKey }
            .map { (k, items) -> FolderGroup(k, items.first().folderName, items) }
        val cmp: Comparator<FolderGroup> = when (sortKey) {
            "name" -> compareBy<FolderGroup> { it.name.lowercase() }
            "size" -> compareBy<FolderGroup> { g -> g.items.sumOf { it.size } }
            else -> compareBy<FolderGroup> { g -> g.items.maxOf { it.dateAdded } }
        }
        val sorted = groups.sortedWith(cmp)
        if (sortAsc) sorted else sorted.reversed()
    }
    val frequent = remember(filtered, plays) {
        filtered.filter { (plays[it.uri.toString()] ?: 0) > 0 }
            .sortedByDescending { plays[it.uri.toString()] ?: 0 }
    }
    val showFolderList = effMode == 1 && openFolder == null
    val list: List<Media> = when {
        effMode == 2 -> frequent
        effMode == 1 && openFolder != null -> flat.filter { it.folderKey == openFolder }
        else -> flat
    }

    val favCount = allMedia.count { it.uri.toString() in favs }
    val selectedItems = allMedia.filter { it.uri.toString() in selected }
    val allVisibleSelected = list.isNotEmpty() && list.all { it.uri.toString() in selected }
    val allSelectedAreFav = selectedItems.isNotEmpty() && selectedItems.all { it.uri.toString() in favs }
    val currentMedia = audios.firstOrNull { it.uri.toString() == currentId }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            // ===== Bagian atas: cari + urutkan (atau bilah mode pilih) =====
            if (selectMode) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { exitSelect() }) { Text("✕") }
                    Text("${selected.size} dipilih", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = {
                        selected = if (allVisibleSelected) selected - list.map { it.uri.toString() }.toSet()
                        else selected + list.map { it.uri.toString() }
                    }) { Text(if (allVisibleSelected) "Batalkan semua" else "Pilih semua") }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        searching = !searching
                        if (!searching) query = ""
                    }) { Text(if (searching) "✕ Tutup" else "🔍 Cari") }

                    if (effMode != 2) {
                        Box {
                            val label = when (sortKey) { "name" -> "Nama"; "size" -> "Ukuran"; else -> "Tanggal" }
                            TextButton(onClick = { sortMenu = true }) {
                                Text("Urutkan: $label ${if (sortAsc) "↑" else "↓"}")
                            }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                listOf("date" to "Tanggal", "name" to "Nama", "size" to "Ukuran").forEach { (k, l) ->
                                    DropdownMenuItem(
                                        text = { Text(if (k == sortKey) "✓ $l ${if (sortAsc) "↑" else "↓"}" else l) },
                                        onClick = {
                                            if (k == sortKey) sortAsc = !sortAsc
                                            else { sortKey = k; sortAsc = (k == "name") }
                                            prefs.edit().putString("sort_key", sortKey).putBoolean("sort_asc", sortAsc).apply()
                                            sortMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                if (searching) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                            .focusRequester(searchFocus),
                        singleLine = true,
                        placeholder = {
                            Text(when (tab) { 0 -> "Cari video…"; 1 -> "Cari musik…"; else -> "Cari di favorit…" })
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("✕") }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
                    )
                }

                // Chip tampilan: Semua | Folder | Sering diputar
                if (tab != 2) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Chip("Semua", mode == 0) { mode = 0; openFolder = null }
                        Chip("Folder", mode == 1) { mode = 1; openFolder = null }
                        Chip("Sering diputar", mode == 2) { mode = 2; openFolder = null }
                    }
                }
            }

            // Judul folder yang sedang dibuka
            if (!selectMode && effMode == 1 && openFolder != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { openFolder = null }) { Text("‹ Folder") }
                    Text(
                        openFolder!!.substringAfterLast('/').ifBlank { "Penyimpanan internal" },
                        Modifier.weight(1f), fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // ===== Isi daftar =====
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val emptyNow = if (showFolderList) folderGroups.isEmpty() else list.isEmpty()
                if (!loading && emptyNow) {
                    Text(
                        when {
                            query.isNotBlank() -> "Tidak ada hasil untuk \"$query\"."
                            effMode == 2 -> "Belum ada yang sering diputar. Putar beberapa file dulu."
                            tab == 0 -> "Belum ada file MP4 / MKV ditemukan."
                            tab == 1 -> "Belum ada file MP3 / OPUS ditemukan."
                            else -> "Belum ada favorit. Tekan lama sebuah file, atau ketuk ⋮, lalu pilih favorit."
                        },
                        Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    if (showFolderList) {
                        items(folderGroups, key = { it.key }) { g ->
                            FolderRow(g) { openFolder = g.key }
                        }
                    } else {
                        itemsIndexed(list, key = { _, m -> m.uri.toString() }) { _, m ->
                            val key = m.uri.toString()
                            val isFav = key in favs
                            val isSel = key in selected
                            val count = plays[key] ?: 0
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent)
                                    .combinedClickable(
                                        onClick = { if (selectMode) toggleSel(m) else open(m, list) },
                                        onLongClick = {
                                            if (!selectMode) {
                                                selectMode = true
                                                selected = setOf(key)
                                                vibrate(ctx)
                                            } else toggleSel(m)
                                        }
                                    )
                                    .padding(start = 16.dp, top = if (m.video) 6.dp else 0.dp, bottom = if (m.video) 6.dp else 0.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (selectMode) {
                                    Checkbox(checked = isSel, onCheckedChange = { toggleSel(m) })
                                    Spacer(Modifier.width(4.dp))
                                }
                                if (m.video) {
                                    Thumb(m, Modifier.width(104.dp).height(62.dp), badge = fmt(m.durationMs))
                                    Spacer(Modifier.width(12.dp))
                                }
                                Column(Modifier.weight(1f).padding(vertical = if (m.video) 0.dp else 8.dp)) {
                                    Text((if (isFav) "★ " else "") + m.title,
                                        maxLines = if (m.video) 2 else 1,
                                        overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    val sub = if (m.video) {
                                        listOfNotNull(
                                            if (tab == 2) "Video" else null,
                                            fmtSize(m.size),
                                            if (effMode == 2 && count > 0) "Diputar ${count}×" else null
                                        )
                                    } else {
                                        listOfNotNull(
                                            if (tab == 2) "Musik" else null,
                                            m.artist, fmt(m.durationMs), fmtSize(m.size),
                                            if (effMode == 2 && count > 0) "Diputar ${count}×" else null
                                        )
                                    }.joinToString(" • ")
                                    Text(sub, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (!selectMode) {
                                    Box {
                                        IconButton(onClick = { menuFor = m }) { Text("⋮", fontSize = 22.sp) }
                                        DropdownMenu(expanded = menuFor == m, onDismissRequest = { menuFor = null }) {
                                            DropdownMenuItem(text = { Text("Bagikan") },
                                                onClick = { menuFor = null; share(listOf(m)) })
                                            DropdownMenuItem(
                                                text = { Text(if (isFav) "Hapus dari favorit" else "Tambah ke favorit") },
                                                onClick = { menuFor = null; toggleFav(m) })
                                            DropdownMenuItem(text = { Text("Info") },
                                                onClick = { menuFor = null; infoFor = m })
                                            DropdownMenuItem(text = { Text("Hapus") }, onClick = {
                                                menuFor = null
                                                if (Build.VERSION.SDK_INT >= 30) requestDelete(listOf(m))
                                                else deleteFor = listOf(m)
                                            })
                                        }
                                    }
                                } else Spacer(Modifier.width(16.dp))
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }

            // ===== Bilah aksi (mode pilih), dekat jempol =====
            if (selectMode) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { share(selectedItems) },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text("Bagikan") }
                    TextButton(
                        onClick = { setFavs(selectedItems, !allSelectedAreFav) },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text(if (allSelectedAreFav) "Hapus favorit" else "★ Favorit") }
                    TextButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 30) { requestDelete(selectedItems); exitSelect() }
                            else deleteFor = selectedItems
                        },
                        enabled = selectedItems.isNotEmpty(), modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text("Hapus") }
                }
            }

            val c = controller
            if (c != null && title.isNotBlank()) {
                MiniPlayer(c, title, playing, pos, dur, onSeek, onOpen = { showNow = true })
            }

            // ===== Menu bawah: Video | Musik | Favorit (dekat jempol) =====
            if (!selectMode) {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { switchTab(0) },
                        icon = { Text("▶", fontSize = 18.sp) },
                        label = { Text("Video (${videos.size})", fontSize = 12.sp, maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { switchTab(1) },
                        icon = { Text("♪", fontSize = 18.sp) },
                        label = { Text("Musik (${audios.size})", fontSize = 12.sp, maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { switchTab(2) },
                        icon = { Text("★", fontSize = 18.sp) },
                        label = { Text("Favorit ($favCount)", fontSize = 12.sp, maxLines = 1) }
                    )
                }
            }
        }

        val c = controller
        if (showNow && c != null && title.isNotBlank()) {
            NowPlaying(
                c = c, title = title, artist = artist,
                coverUri = if (currentId.isNotBlank()) Uri.parse(currentId) else null,
                playing = playing, pos = pos, dur = dur,
                isFav = currentId in favs, playMode = playMode,
                onSeek = onSeek,
                onFav = { currentMedia?.let { toggleFav(it) } },
                onCycleMode = { cycleMode() },
                onShare = { currentMedia?.let { share(listOf(it)) } },
                onInfo = { infoFor = currentMedia },
                onClose = { showNow = false }
            )
        }
    }

    // ---- Dialog Info ----
    infoFor?.let { m ->
        var dims by remember(m) { mutableStateOf<Pair<Int, Int>?>(null) }
        if (m.video) {
            LaunchedEffect(m) { dims = withContext(Dispatchers.IO) { loadVideoSize(ctx, m.uri) } }
        }
        AlertDialog(
            onDismissRequest = { infoFor = null },
            title = { Text("Info ${if (m.video) "video" else "musik"}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    infoLines(m, dims).forEach { (k, v) ->
                        Text(k, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { infoFor = null }) { Text("Tutup") } }
        )
    }

    // ---- Konfirmasi hapus (Android 10 ke bawah; Android 11+ memakai dialog sistem) ----
    deleteFor?.let { items ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text(if (items.size == 1) "Hapus file?" else "Hapus ${items.size} file?") },
            text = {
                Text(
                    if (items.size == 1) "\"${items[0].fileName}\" akan dihapus dari perangkat dan tidak bisa dikembalikan."
                    else "${items.size} file akan dihapus dari perangkat dan tidak bisa dikembalikan."
                )
            },
            confirmButton = {
                TextButton(onClick = { deleteFor = null; exitSelect(); requestDelete(items) }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal") } }
        )
    }
}
