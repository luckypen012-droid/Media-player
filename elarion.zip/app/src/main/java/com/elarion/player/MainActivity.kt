package com.elarion.player

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun hasAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    var ok by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = hasAccess(ctx)
    }
    LaunchedEffect(Unit) { if (!ok) launcher.launch(perms) }

    if (ok) Library() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Elarion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Izinkan akses ke video dan audio agar Elarion bisa menampilkan file di perangkatmu. Semua tetap offline.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Beri izin") }
    }
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf(emptyList<Media>()) }
    var audios by remember { mutableStateOf(emptyList<Media>()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            audios = Scanner.audios(ctx)
        }
        loading = false
    }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var lastSeek by remember { mutableLongStateOf(0L) }
    var showNow by remember { mutableStateOf(false) }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                title = mediaMetadata.title?.toString() ?: ""
                artist = mediaMetadata.artist?.toString() ?: ""
            }
        }
        c.addListener(l)
        playing = c.isPlaying
        title = c.mediaMetadata.title?.toString() ?: ""
        artist = c.mediaMetadata.artist?.toString() ?: ""
        onDispose { c.removeListener(l) }
    }

    // Perbarui posisi tiap 250 ms, tapi jangan menimpa posisi tepat setelah pengguna menggeser
    LaunchedEffect(controller) {
        while (isActive) {
            controller?.let { c ->
                if (SystemClock.elapsedRealtime() - lastSeek > 800) pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }

    val onSeek: (Long) -> Unit = { t ->
        controller?.seekTo(t)
        pos = t
        lastSeek = SystemClock.elapsedRealtime()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Video (${videos.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Audio (${audios.size})") })
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val list = if (tab == 0) videos else audios
                if (!loading && list.isEmpty()) {
                    Text("Belum ada file ${if (tab == 0) "MP4 / MKV" else "MP3 / OPUS"} ditemukan.",
                        Modifier.align(Alignment.Center).padding(24.dp))
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(list) { index, m ->
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                if (tab == 0) {
                                    controller?.pause()
                                    ctx.startActivity(
                                        Intent(ctx, VideoPlayerActivity::class.java).setData(m.uri)
                                    )
                                } else {
                                    controller?.let { c ->
                                        c.setMediaItems(list.map { it.toItem() }, index, 0L)
                                        c.prepare(); c.play()
                                    }
                                }
                            }.padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(m.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyLarge)
                            val sub = listOfNotNull(m.artist, fmt(m.durationMs), fmtSize(m.size)).joinToString(" • ")
                            Text(sub, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                }
            }
            val c = controller
            if (c != null && title.isNotBlank()) {
                MiniPlayer(c, title, playing, pos, dur, onSeek, onOpen = { showNow = true })
            }
        }

        val c = controller
        if (showNow && c != null && title.isNotBlank()) {
            NowPlaying(c, title, artist, playing, pos, dur, onSeek, onClose = { showNow = false })
        }
    }
}

/** Seekbar halus: thumb mengikuti jari, seek hanya sekali saat jari dilepas. */
@Composable
fun SeekBar(pos: Long, dur: Long, preview: Long? = null, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shownFrac = if (preview != null && dur > 0) (preview.toFloat() / dur).coerceIn(0f, 1f) else (drag ?: frac)
    val shownMs = preview ?: drag?.let { (it * dur).toLong() } ?: pos
    Column {
        Slider(
            value = shownFrac,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { if (dur > 0) onSeek((it * dur).toLong()) }
                drag = null
            }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween) {
            Text(fmt(shownMs), style = MaterialTheme.typography.bodySmall)
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MiniPlayer(
    c: MediaController, title: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onOpen: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp)
    ) {
        Text("▲  $title", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp))
        SeekBar(pos, dur, null, onSeek)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) { Text(if (playing) "⏸" else "▶") }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭") }
        }
    }
}

/** Layar pemutar audio penuh. Geser kiri/kanan di MANA SAJA untuk maju/mundur. */
@Composable
fun NowPlaying(
    c: MediaController, title: String, artist: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    var swipe by remember { mutableStateOf<Long?>(null) }
    val posNow by rememberUpdatedState(pos)
    val durNow by rememberUpdatedState(dur)
    val seekNow by rememberUpdatedState(onSeek)

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                var start = 0L
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { start = posNow; total = 0f; swipe = start },
                    onDragEnd = { swipe?.let { seekNow(it) }; swipe = null },
                    onDragCancel = { swipe = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                        swipe = (start + total / size.width * 120_000f).toLong().coerceIn(0L, durNow)
                    }
                )
            }
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("⌄ Tutup", Modifier.align(Alignment.Start).clickable(onClick = onClose).padding(8.dp))
        Spacer(Modifier.weight(1f))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
        if (artist.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(artist, style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(32.dp))
        SeekBar(pos, dur, swipe, onSeek)
        Text("Geser kiri/kanan di mana saja untuk maju/mundur",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮", style = MaterialTheme.typography.headlineMedium) }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) {
                Text(if (playing) "⏸" else "▶", style = MaterialTheme.typography.headlineLarge)
            }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", style = MaterialTheme.typography.headlineMedium) }
        }
        Spacer(Modifier.weight(1f))
    }
}
