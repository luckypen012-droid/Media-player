@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.elarion.player

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeStore.load(this)
        setContent { ElarionTheme { Root() } }
    }
}

private fun hasAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** Getaran singkat sebagai penanda (mis. masuk mode pilih). */
private fun vibrate(ctx: Context, ms: Long = 45) {
    try {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (_: Exception) {}
}

@Composable
fun Root() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1200); splash = false }
    val ctx = LocalContext.current
    val el = LocalEl.current
    val bg = ThemeStore.bg
    // Status bar & nav bar mengikuti warna tepi atas/bawah background yang dipilih
    val edges = remember(bg.res) { BgSample.edges(ctx, bg.res) }
    SideEffect {
        (ctx as? Activity)?.window?.let { w ->
            w.statusBarColor = edges.first.toArgb()
            w.navigationBarColor = edges.second.toArgb()
            WindowCompat.getInsetsController(w, w.decorView).apply {
                isAppearanceLightStatusBars = edges.first.luminance() > 0.5f
                isAppearanceLightNavigationBars = edges.second.luminance() > 0.5f
            }
        }
    }
    Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = el.text) {
        Box(Modifier.fillMaxSize()) {
            Crossfade(targetState = bg.res, animationSpec = tween(350), label = "bg") { r ->
                Image(
                    painter = painterResource(r), contentDescription = null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
            }
            App()
            AnimatedVisibility(visible = splash, exit = fadeOut(tween(450))) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {},
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(R.drawable.elarion_logo), contentDescription = null,
                        modifier = Modifier.fillMaxWidth(0.85f), contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    var ok by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = hasAccess(ctx)
    }
    LaunchedEffect(Unit) { if (!ok) launcher.launch(perms) }

    val elp = LocalEl.current
    if (ok) Library() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            Modifier.clip(RoundedCornerShape(24.dp)).background(elp.card).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Elarion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("Izinkan akses ke video dan musik agar Elarion bisa menampilkan file di perangkatmu. Semua tetap offline.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(perms) }) { Text("Beri izin") }
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val el = LocalEl.current
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) el.accentFill else el.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 14.sp, color = if (selected) Color.White else el.text,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun ActionBtn(ic: Ic, label: String, enabled: Boolean, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = if (enabled) tint else tint.copy(alpha = 0.35f)
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon24(ic, c, size = 22.dp)
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = c)
    }
}

@Composable
fun FolderRow(g: FolderGroup, onClick: () -> Unit) {
    val el = LocalEl.current
    val first = g.items.maxByOrNull { it.dateAdded } ?: g.items.first()
    val unit = if (first.video) "video" else "musik"
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp)).background(el.card)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(first, Modifier.size(64.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(g.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text("${g.items.size} $unit", style = MaterialTheme.typography.bodySmall, color = el.textSoft)
        }
        Icon24(Ic.ChevronDown, el.textSoft, Modifier.rotate(-90f), size = 22.dp)
    }
    
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("elarion", Context.MODE_PRIVATE) }
    val playPrefs = remember { ctx.getSharedPreferences("elarion_plays", Context.MODE_PRIVATE) }
    val focusManager = LocalFocusManager.current
    val el = LocalEl.current

    // 0 = Video, 1 = Musik, 2 = Favorit, 3 = Tampilan (menu bawah)
    var tab by remember { mutableIntStateOf(0) }
    // 0 = Semua, 1 = Folder, 2 = Sering diputar (chip, hanya untuk Video/Musik)
    var mode by remember { mutableIntStateOf(0) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    val effMode = if (tab == 2) 0 else mode

    var videos by remember { mutableStateOf(emptyList<Media>()) }
    var audios by remember { mutableStateOf(emptyList<Media>()) }
    var loading by remember { mutableStateOf(true) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        withContext(Dispatchers.IO) {
            videos = Scanner.videos(ctx)
            audios = Scanner.audios(ctx)
        }
        loading = false
    }

    // ---- Favorit ----
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet()) }
    fun saveFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s.toSet()).apply() }
    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        saveFavs(if (k in favs) favs - k else favs + k)
    }
    fun setFavs(items: List<Media>, add: Boolean) {
        val keys = items.map { it.uri.toString() }
        saveFavs(if (add) favs + keys else favs - keys.toSet())
    }

    // ---- Jumlah putar (untuk "Sering diputar") ----
    fun readPlays(): Map<String, Int> =
        playPrefs.all.mapNotNull { (k, v) -> (v as? Int)?.let { k to it } }.toMap()
    var plays by remember { mutableStateOf(readPlays()) }

    // Muat ulang daftar & jumlah putar setiap kembali ke layar ini (mis. setelah menonton / menghapus di pemutar video)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        var first = true
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                if (first) first = false else { reloadKey++; plays = readPlays() }
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // ---- Urutan: tanggal = terbaru, nama = A-Z, ukuran = terbesar ----
    var sortKey by remember { mutableStateOf(prefs.getString("sort_key", "date") ?: "date") }
    var sortMenu by remember { mutableStateOf(false) }

    // ---- Pencarian ----
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val searchFocus = remember { FocusRequester() }
    LaunchedEffect(searching) {
        if (searching) {
            delay(120)
            try { searchFocus.requestFocus() } catch (_: Exception) {}
        }
    }

    // ---- Mode pilih (tekan lama) ----
    var selectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    fun exitSelect() { selectMode = false; selected = emptySet() }
    fun toggleSel(m: Media) {
        val k = m.uri.toString()
        selected = if (k in selected) selected - k else selected + k
    }
    fun switchTab(i: Int) { tab = i; openFolder = null; query = ""; searching = false; exitSelect() }

    BackHandler(enabled = searching && !selectMode) { searching = false; query = "" }
    BackHandler(enabled = openFolder != null && !selectMode) { openFolder = null }
    BackHandler(enabled = selectMode) { exitSelect() }

    // ---- Koneksi ke layanan musik ----
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    var playing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var currentId by remember { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var lastSeek by remember { mutableLongStateOf(0L) }
    var showNow by remember { mutableStateOf(false) }

    // ---- Mode putar musik ----
    var playMode by remember { mutableIntStateOf(prefs.getInt("play_mode", 0)) }
    LaunchedEffect(controller, playMode) { controller?.let { applyMode(it, playMode) } }
    fun cycleMode() {
        playMode = (playMode + 1) % 4
        prefs.edit().putInt("play_mode", playMode).apply()
        Toast.makeText(ctx, playModeName(playMode), Toast.LENGTH_SHORT).show()
    }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentId = mediaItem?.mediaId ?: ""
            }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                title = mediaMetadata.title?.toString() ?: ""
                artist = mediaMetadata.artist?.toString() ?: ""
            }
        }
        c.addListener(l)
        playing = c.isPlaying
        currentId = c.currentMediaItem?.mediaId ?: ""
        title = c.mediaMetadata.title?.toString() ?: ""
        artist = c.mediaMetadata.artist?.toString() ?: ""
        onDispose { c.removeListener(l) }
    }

    LaunchedEffect(title, effMode) { plays = readPlays() }

    LaunchedEffect(controller) {
        while (isActive) {
            controller?.let { c ->
                if (SystemClock.elapsedRealtime() - lastSeek > 800) pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }

    val onSeek: (Long) -> Unit = { t ->
        controller?.seekTo(t)
        pos = t
        lastSeek = SystemClock.elapsedRealtime()
    }

    // ---- Hapus (satu atau banyak) ----
    var infoFor by remember { mutableStateOf<Media?>(null) }
    var menuFor by remember { mutableStateOf<Media?>(null) }
    var deleteFor by remember { mutableStateOf<List<Media>?>(null) }
    var pendingDelete by remember { mutableStateOf<List<Media>>(emptyList()) }
    var delDone by remember { mutableIntStateOf(0) }
    var legacyRetry by remember { mutableIntStateOf(0) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val items = pendingDelete
        if (Build.VERSION.SDK_INT >= 30) {
            if (res.resultCode == Activity.RESULT_OK) {
                saveFavs(favs - items.map { it.uri.toString() }.toSet())
                reloadKey++
                Toast.makeText(ctx, "${items.size} file dihapus", Toast.LENGTH_SHORT).show()
            }
            pendingDelete = emptyList()
        } else {
            if (res.resultCode == Activity.RESULT_OK) legacyRetry++
            else { pendingDelete = emptyList(); reloadKey++ }
        }
    }

    // Android 10 ke bawah: hapus satu per satu
    fun legacyDeleteNext() {
        var q = pendingDelete
        while (q.isNotEmpty()) {
            val m = q.first()
            try {
                ctx.contentResolver.delete(m.uri, null, null)
                delDone++
                saveFavs(favs - m.uri.toString())
                q = q.drop(1)
                pendingDelete = q
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pendingDelete = q
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                    return
                }
                q = q.drop(1)
            } catch (e: Exception) {
                q = q.drop(1)
            }
        }
        pendingDelete = emptyList()
        reloadKey++
        Toast.makeText(ctx, "$delDone file dihapus", Toast.LENGTH_SHORT).show()
    }
    LaunchedEffect(legacyRetry) { if (legacyRetry > 0) legacyDeleteNext() }

    fun requestDelete(items: List<Media>) {
        if (items.isEmpty()) return
        delDone = 0
        pendingDelete = items
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, items.map { it.uri })
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                pendingDelete = emptyList()
                Toast.makeText(ctx, "Gagal menghapus file", Toast.LENGTH_LONG).show()
            }
        } else {
            legacyDeleteNext()
        }
    }

    // ---- Bagikan (satu atau banyak) ----
    fun share(items: List<Media>) {
        if (items.isEmpty()) return
        val send = if (items.size == 1) {
            val m = items[0]
            Intent(Intent.ACTION_SEND).apply {
                type = m.mime.ifBlank { if (m.video) "video/*" else "audio/*" }
                putExtra(Intent.EXTRA_STREAM, m.uri)
                clipData = ClipData.newRawUri(null, m.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            val uris = ArrayList(items.map { it.uri })
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = when {
                    items.all { it.video } -> "video/*"
                    items.none { it.video } -> "audio/*"
                    else -> "*/*"
                }
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                val cd = ClipData.newRawUri(null, uris[0])
                for (i in 1 until uris.size) cd.addItem(ClipData.Item(uris[i]))
                clipData = cd
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        ctx.startActivity(Intent.createChooser(send,
            if (items.size == 1) "Bagikan ${items[0].title}" else "Bagikan ${items.size} file"))
    }

    fun open(m: Media, siblings: List<Media>) {
        if (m.video) {
            controller?.pause()
            // Daftar video di sekitar (urutan yang sedang tampil) dikirim agar bisa berpindah video di pemutar
            val vids = siblings.filter { it.video }
            ctx.startActivity(
                Intent(ctx, VideoPlayerActivity::class.java).setData(m.uri)
                    .putStringArrayListExtra("playlist", ArrayList(vids.map { it.uri.toString() }))
                    .putExtra("index", vids.indexOf(m).coerceAtLeast(0))
            )
        } else {
            controller?.let { c ->
                val q = siblings.filter { !it.video }
                c.setMediaItems(q.map { it.toItem() }, q.indexOf(m).coerceAtLeast(0), 0L)
                c.prepare(); c.play()
                // langsung tampilkan layar pemutar musik
                title = m.title; artist = m.artist ?: ""; currentId = m.uri.toString()
                pos = 0L; dur = m.durationMs
                showNow = true
            }
        }
    }

    // ---- Daftar yang ditampilkan: cari, urutkan, folder, sering diputar ----
    val allMedia = videos + audios
    val base = when (tab) {
        0 -> videos
        1 -> audios
        else -> allMedia.filter { it.uri.toString() in favs }
    }
    val filtered = remember(base, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) base else base.filter {
            it.title.lowercase().contains(q) || it.fileName.lowercase().contains(q) ||
                (it.artist?.lowercase()?.contains(q) == true) || (it.album?.lowercase()?.contains(q) == true)
        }
    }
    val flat = remember(filtered, sortKey) {
        when (sortKey) {
            "name" -> filtered.sortedBy { it.title.lowercase() }
            "size" -> filtered.sortedByDescending { it.size }
            else -> filtered.sortedByDescending { it.dateAdded }
        }
    }
    val folderGroups = remember(filtered, sortKey) {
        val groups = filtered.groupBy { it.folderKey }
            .map { (k, items) -> FolderGroup(k, items.first().folderName, items) }
        when (sortKey) {
            "name" -> groups.sortedBy { it.name.lowercase() }
            "size" -> groups.sortedByDescending { g -> g.items.sumOf { it.size } }
            else -> groups.sortedByDescending { g -> g.items.maxOf { it.dateAdded } }
        }
    }
    val frequent = remember(filtered, plays) {
        filtered.filter { (plays[it.uri.toString()] ?: 0) > 0 }
            .sortedByDescending { plays[it.uri.toString()] ?: 0 }
    }
    val showFolderList = effMode == 1 && openFolder == null
    val list: List<Media> = when {
        effMode == 2 -> frequent
        effMode == 1 && openFolder != null -> flat.filter { it.folderKey == openFolder }
        else -> flat
    }

    val favCount = allMedia.count { it.uri.toString() in favs }
    val selectedItems = allMedia.filter { it.uri.toString() in selected }
    val allVisibleSelected = list.isNotEmpty() && list.all { it.uri.toString() in selected }
    val allSelectedAreFav = selectedItems.isNotEmpty() && selectedItems.all { it.uri.toString() in favs }
    val currentMedia = audios.firstOrNull { it.uri.toString() == currentId }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            if (tab == 3) {
                ThemeScreen(Modifier.weight(1f).fillMaxWidth())
            } else {

            // ===== Bagian atas: cari + urutkan (atau bilah mode pilih) =====
            if (selectMode) {
                Row(
                    Modifier.fillMaxWidth().background(el.bar).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconBtn(Ic.Close, { exitSelect() }, tint = el.text)
                    Text("${selected.size} dipilih", Modifier.weight(1f).padding(start = 4.dp), fontWeight = FontWeight.Bold)
                    TextButton(onClick = {
                        selected = if (allVisibleSelected) selected - list.map { it.uri.toString() }.toSet()
                        else selected + list.map { it.uri.toString() }
                    }, colors = ButtonDefaults.textButtonColors(contentColor = el.accent)) {
                        Text(if (allVisibleSelected) "Batalkan semua" else "Pilih semua")
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { searching = !searching; if (!searching) query = "" },
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(el.card),
                        colors = ButtonDefaults.textButtonColors(contentColor = el.text)
                    ) {
                        Icon24(if (searching) Ic.Close else Ic.Search, LocalContentColor.current, size = 20.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(if (searching) "Tutup" else "Cari")
                    }

                    if (effMode != 2) {
                        Box {
                            val label = when (sortKey) { "name" -> "Nama"; "size" -> "Ukuran"; else -> "Tanggal" }
                            TextButton(
                                onClick = { sortMenu = true },
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(el.card),
                                colors = ButtonDefaults.textButtonColors(contentColor = el.text)
                            ) {
                                Text("Urutkan: $label")
                                Spacer(Modifier.width(4.dp))
                                Icon24(Ic.ChevronDown, LocalContentColor.current, size = 18.dp)
                            }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                listOf(
                                    Triple("date", "Tanggal", "terbaru"),
                                    Triple("name", "Nama", "A–Z"),
                                    Triple("size", "Ukuran", "terbesar")
                                ).forEach { (k, l, hint) ->
                                    DropdownMenuItem(
                                        text = { Text("$l ($hint)") },
                                        leadingIcon = {
                                            if (k == sortKey) Icon24(Ic.Check, Violet, size = 20.dp)
                                            else Spacer(Modifier.size(20.dp))
                                        },
                                        onClick = {
                                            sortKey = k
                                            prefs.edit().putString("sort_key", k).apply()
                                            sortMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                if (searching) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                            .focusRequester(searchFocus),
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = el.text, unfocusedTextColor = el.text, cursorColor = el.accent,
                            focusedPlaceholderColor = el.textSoft, unfocusedPlaceholderColor = el.textSoft,
                            focusedContainerColor = el.fieldFocus, unfocusedContainerColor = el.field,
                            focusedBorderColor = el.accent, unfocusedBorderColor = el.fieldBorder
                        ),
                        placeholder = {
                            Text(when (tab) { 0 -> "Cari video…"; 1 -> "Cari musik…"; else -> "Cari di favorit…" })
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) IconBtn(Ic.Close, { query = "" }, tint = el.text, box = 40.dp, icon = 20.dp)
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
                    )
                }

                // Chip tampilan: Semua | Folder | Sering diputar
                if (tab != 2) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Chip("Semua", mode == 0) { mode = 0; openFolder = null }
                        Chip("Folder", mode == 1) { mode = 1; openFolder = null }
                        Chip("Sering diputar", mode == 2) { mode = 2; openFolder = null }
                    }
                }
            }

            // Judul folder yang sedang dibuka
            if (!selectMode && effMode == 1 && openFolder != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
                        .clip(RoundedCornerShape(50)).background(el.card),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { openFolder = null },
                        colors = ButtonDefaults.textButtonColors(contentColor = el.text)
                    ) {
                        Icon24(Ic.ChevronDown, LocalContentColor.current, Modifier.rotate(90f), size = 18.dp)
                        Spacer(Modifier.width(4.dp))
                        Text("Folder")
                    }
                    Text(
                        openFolder!!.substringAfterLast('/').ifBlank { "Penyimpanan internal" },
                        Modifier.weight(1f).padding(end = 14.dp), color = el.text, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // ===== Isi daftar =====
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val emptyNow = if (showFolderList) folderGroups.isEmpty() else list.isEmpty()
                if (!loading && emptyNow) {
                    Text(
                        when {
                            query.isNotBlank() -> "Tidak ada hasil untuk \"$query\"."
                            effMode == 2 -> "Belum ada yang sering diputar. Putar beberapa file dulu."
                            tab == 0 -> "Belum ada file MP4 / MKV ditemukan."
                            tab == 1 -> "Belum ada file MP3 / OPUS ditemukan."
                            else -> "Belum ada favorit. Tekan lama sebuah file, atau ketuk titik tiga, lalu pilih favorit."
                        },
                        Modifier.align(Alignment.Center).padding(24.dp)
                            .clip(RoundedCornerShape(16.dp)).background(el.card).padding(16.dp),
                        color = el.text, textAlign = TextAlign.Center
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    if (showFolderList) {
                        items(folderGroups, key = { it.key }) { g ->
                            FolderRow(g) { openFolder = g.key }
                        }
                    } else {
                        itemsIndexed(list, key = { _, m -> m.uri.toString() }) { _, m ->
                            val key = m.uri.toString()
                            val isFav = key in favs
                            val isSel = key in selected
                            val count = plays[key] ?: 0
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSel) el.cardSel else el.card)
                                    .combinedClickable(
                                        onClick = { if (selectMode) toggleSel(m) else open(m, list) },
                                        onLongClick = {
                                            if (!selectMode) {
                                                selectMode = true
                                                selected = setOf(key)
                                                vibrate(ctx)
                                            } else toggleSel(m)
                                        }
                                    )
                                    .padding(start = 10.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (selectMode) {
                                    Checkbox(
                                        checked = isSel, onCheckedChange = { toggleSel(m) },
                                        colors = CheckboxDefaults.colors(checkedColor = el.accentFill, uncheckedColor = el.textSoft)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                }
                                if (m.video) {
                                    Thumb(m, Modifier.width(104.dp).height(62.dp), badge = fmt(m.durationMs))
                                } else {
                                    Box(
                                        Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(el.accent.copy(alpha = 0.33f)),
                                        contentAlignment = Alignment.Center
                                    ) { Icon24(Ic.Music, el.accent, size = 26.dp) }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (isFav) {
                                            Icon24(Ic.HeartFilled, HeartPink, size = 14.dp)
                                            Spacer(Modifier.width(5.dp))
                                        }
                                        Text(m.title, Modifier.weight(1f, fill = false),
                                            maxLines = if (m.video) 2 else 1,
                                            overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    }
                                    val sub = if (m.video) {
                                        listOfNotNull(
                                            if (tab == 2) "Video" else null,
                                            fmtSize(m.size),
                                            if (effMode == 2 && count > 0) "Diputar ${count}×" else null
                                        )
                                    } else {
                                        listOfNotNull(
                                            if (tab == 2) "Musik" else null,
                                            m.artist, fmt(m.durationMs), fmtSize(m.size),
                                            if (effMode == 2 && count > 0) "Diputar ${count}×" else null
                                        )
                                    }.joinToString(" • ")
                                    Text(sub, style = MaterialTheme.typography.bodySmall, color = el.textSoft)
                                }
                                if (!selectMode) {
                                    Box {
                                        IconBtn(Ic.More, { menuFor = m }, tint = el.text, box = 44.dp, icon = 22.dp)
                                        DropdownMenu(expanded = menuFor == m, onDismissRequest = { menuFor = null }) {
                                            DropdownMenuItem(
                                                text = { Text("Bagikan") },
                                                leadingIcon = { Icon24(Ic.Share, LocalContentColor.current, size = 20.dp) },
                                                onClick = { menuFor = null; share(listOf(m)) })
                                            DropdownMenuItem(
                                                text = { Text(if (isFav) "Hapus dari favorit" else "Tambah ke favorit") },
                                                leadingIcon = {
                                                    Icon24(if (isFav) Ic.HeartFilled else Ic.Heart,
                                                        if (isFav) HeartPink else LocalContentColor.current, size = 20.dp)
                                                },
                                                onClick = { menuFor = null; toggleFav(m) })
                                            DropdownMenuItem(
                                                text = { Text("Info") },
                                                leadingIcon = { Icon24(Ic.Info, LocalContentColor.current, size = 20.dp) },
                                                onClick = { menuFor = null; infoFor = m })
                                            DropdownMenuItem(
                                                text = { Text("Hapus") },
                                                leadingIcon = { Icon24(Ic.Trash, MaterialTheme.colorScheme.error, size = 20.dp) },
                                                onClick = {
                                                    menuFor = null
                                                    if (Build.VERSION.SDK_INT >= 30) requestDelete(listOf(m))
                                                    else deleteFor = listOf(m)
                                                })
                                        }
                                    }
                                } else Spacer(Modifier.width(16.dp))
                            }
                            
                        }
                    }
                }
            }

            }

            // ===== Bilah aksi (mode pilih), dekat jempol =====
            if (selectMode) {
                Row(
                    Modifier.fillMaxWidth().background(el.bar).padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ActionBtn(Ic.Share, "Bagikan", selectedItems.isNotEmpty(), el.text, Modifier.weight(1f)) {
                        share(selectedItems)
                    }
                    ActionBtn(
                        if (allSelectedAreFav) Ic.HeartFilled else Ic.Heart,
                        if (allSelectedAreFav) "Hapus favorit" else "Favorit",
                        selectedItems.isNotEmpty(), if (allSelectedAreFav) HeartPink else el.text, Modifier.weight(1f)
                    ) { setFavs(selectedItems, !allSelectedAreFav) }
                    ActionBtn(Ic.Trash, "Hapus", selectedItems.isNotEmpty(), el.danger, Modifier.weight(1f)) {
                        if (Build.VERSION.SDK_INT >= 30) { requestDelete(selectedItems); exitSelect() }
                        else deleteFor = selectedItems
                    }
                }
            }

            val c = controller
            val showMini = c != null && title.isNotBlank()
            if (showMini || !selectMode) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(28.dp)).background(el.glass)
                ) {
                    if (c != null && showMini) {
                        MiniPlayer(c, title, playing, pos, dur, onSeek, onOpen = { showNow = true })
                    }

                    // ===== Menu bawah: Video | Musik | Favorit (dekat jempol) =====
                    if (!selectMode) {
                        NavigationBar(containerColor = Color.Transparent) {
                            val itemColors = NavigationBarItemDefaults.colors(
                                selectedIconColor = el.accent, selectedTextColor = el.accent,
                                indicatorColor = el.navIndicator,
                                unselectedIconColor = el.textSoft, unselectedTextColor = el.textSoft
                            )
                            NavigationBarItem(
                                selected = tab == 0, onClick = { switchTab(0) }, colors = itemColors,
                                icon = { Icon24(Ic.Video, LocalContentColor.current) },
                                label = { Text("Video ${videos.size}", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                            )
                            NavigationBarItem(
                                selected = tab == 1, onClick = { switchTab(1) }, colors = itemColors,
                                icon = { Icon24(Ic.Music, LocalContentColor.current) },
                                label = { Text("Musik ${audios.size}", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                            )
                            NavigationBarItem(
                                selected = tab == 2, onClick = { switchTab(2) }, colors = itemColors,
                                icon = { Icon24(if (tab == 2) Ic.HeartFilled else Ic.Heart, LocalContentColor.current) },
                                label = { Text("Favorit $favCount", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                            )
                            NavigationBarItem(
                                selected = tab == 3, onClick = { switchTab(3) }, colors = itemColors,
                                icon = { Icon24(Ic.Palette, LocalContentColor.current) },
                                label = { Text("Tampilan", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                            )
                        }
                    }
                }
            }
        }

        val c = controller
        if (showNow && c != null && title.isNotBlank()) {
            NowPlaying(
                c = c, title = title, artist = artist,
                coverUri = if (currentId.isNotBlank()) Uri.parse(currentId) else null,
                playing = playing, pos = pos, dur = dur,
                isFav = currentId in favs, playMode = playMode,
                onSeek = onSeek,
                onFav = { currentMedia?.let { toggleFav(it) } },
                onCycleMode = { cycleMode() },
                onShare = { currentMedia?.let { share(listOf(it)) } },
                onInfo = { infoFor = currentMedia },
                onClose = { showNow = false }
            )
        }
    }

    // ---- Dialog Info ----
    infoFor?.let { m ->
        var dims by remember(m) { mutableStateOf<Pair<Int, Int>?>(null) }
        if (m.video) {
            LaunchedEffect(m) { dims = withContext(Dispatchers.IO) { loadVideoSize(ctx, m.uri) } }
        }
        AlertDialog(
            onDismissRequest = { infoFor = null },
            containerColor = PanelColor,
            title = { Text("Info ${if (m.video) "video" else "musik"}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    infoLines(m, dims).forEach { (k, v) ->
                        Text(k, style = MaterialTheme.typography.labelMedium, color = InkSoft)
                        Text(v, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { infoFor = null }) { Text("Tutup") } }
        )
    }

    // ---- Konfirmasi hapus (Android 10 ke bawah; Android 11+ memakai dialog sistem) ----
    deleteFor?.let { items ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            containerColor = PanelColor,
            title = { Text(if (items.size == 1) "Hapus file?" else "Hapus ${items.size} file?") },
            text = {
                Text(
                    if (items.size == 1) "\"${items[0].fileName}\" akan dihapus dari perangkat dan tidak bisa dikembalikan."
                    else "${items.size} file akan dihapus dari perangkat dan tidak bisa dikembalikan."
                )
            },
            confirmButton = {
                TextButton(onClick = { deleteFor = null; exitSelect(); requestDelete(items) }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Batal") } }
        )
    }
}
