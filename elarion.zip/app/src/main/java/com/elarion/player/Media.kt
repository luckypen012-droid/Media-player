package com.elarion.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/** Daftar format di SATU tempat. Untuk menambah format (flac, avi, webm...), cukup tambah di sini. */
object Formats {
    val VIDEO = setOf("mp4", "mkv")
    val AUDIO = setOf("mp3", "opus")
    fun ext(name: String) = name.substringAfterLast('.', "").lowercase()
}

data class Media(
    val uri: Uri,
    val title: String,
    val artist: String?,
    val durationMs: Long,
    val size: Long,
)

fun Media.toItem(): MediaItem = MediaItem.Builder()
    .setUri(uri)
    .setMediaId(uri.toString())
    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
    .build()

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String =
    if (b >= 1_000_000_000) "%.1f GB".format(b / 1e9) else "%.1f MB".format(b / 1e6)

object Scanner {
    fun videos(ctx: Context) = query(
        ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
        MediaStore.Video.Media.DURATION, null, Formats.VIDEO,
        "${MediaStore.MediaColumns.DATE_ADDED} DESC"
    )

    fun audios(ctx: Context) = query(
        ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ARTIST, Formats.AUDIO,
        "${MediaStore.MediaColumns.DISPLAY_NAME} COLLATE NOCASE ASC"
    )

    private fun query(
        ctx: Context, base: Uri, durCol: String, artistCol: String?,
        exts: Set<String>, order: String,
    ): List<Media> {
        val proj = listOfNotNull(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE, durCol, artistCol
        ).toTypedArray()
        val out = ArrayList<Media>()
        ctx.contentResolver.query(base, proj, null, null, order)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDur = c.getColumnIndexOrThrow(durCol)
            val iArt = artistCol?.let { c.getColumnIndexOrThrow(it) } ?: -1
            while (c.moveToNext()) {
                val name = c.getString(iName) ?: continue
                if (Formats.ext(name) !in exts) continue
                var artist = if (iArt >= 0) c.getString(iArt) else null
                if (artist == "<unknown>") artist = null
                out += Media(
                    ContentUris.withAppendedId(base, c.getLong(iId)),
                    name.substringBeforeLast('.'), artist, c.getLong(iDur), c.getLong(iSize)
                )
            }
        }
        return out
    }
}
