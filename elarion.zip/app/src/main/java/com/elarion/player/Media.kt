package com.elarion.player

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Daftar format di SATU tempat. Untuk menambah format (flac, avi, webm...), cukup tambah di sini. */
object Formats {
    val VIDEO = setOf("mp4", "mkv")
    val AUDIO = setOf("mp3", "opus")
    fun ext(name: String) = name.substringAfterLast('.', "").lowercase()
}

data class Media(
    val uri: Uri,
    val title: String,
    val fileName: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val size: Long,
    val dateAdded: Long,   // detik
    val mime: String,
    val path: String,
    val width: Int,
    val height: Int,
    val video: Boolean,
)

fun Media.toItem(): MediaItem = MediaItem.Builder()
    .setUri(uri)
    .setMediaId(uri.toString())
    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
    .build()

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String =
    if (b >= 1_000_000_000) "%.1f GB".format(b / 1e9) else "%.1f MB".format(b / 1e6)

/** Nama resolusi yang mudah dipahami, mis. 1280x720 -> "720p (HD)". Tetap akurat untuk video lebar/sinema dan potret. */
fun resolutionLabel(w: Int, h: Int): String {
    val shortSide = minOf(w, h)
    val longSide = maxOf(w, h)
    val eff = maxOf(shortSide, longSide * 9 / 16)
    val name = when {
        eff >= 2000 -> "2160p (4K)"
        eff >= 1300 -> "1440p (2K)"
        eff >= 1000 -> "1080p (Full HD)"
        eff >= 680 -> "720p (HD)"
        eff >= 460 -> "480p (SD)"
        eff >= 340 -> "360p"
        eff >= 220 -> "240p"
        else -> "144p"
    }
    return "$name\n$w × $h piksel (lebar × tinggi)"
}

/** Baca ukuran video langsung dari file (memperhitungkan rotasi), dipakai di dialog Info. */
fun loadVideoSize(ctx: Context, uri: Uri): Pair<Int, Int>? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) Pair(h, w) else Pair(w, h)
    } catch (e: Exception) {
        null
    } finally {
        try { r.release() } catch (_: Exception) {}
    }
}

fun infoLines(m: Media, dims: Pair<Int, Int>? = null): List<Pair<String, String>> = buildList {
    add("Nama file" to m.fileName)
    val fmtName = Formats.ext(m.fileName).uppercase()
    add("Jenis" to (if (m.video) "Video" else "Musik") + " • " + fmtName +
        (if (m.mime.isNotBlank()) " (${m.mime})" else ""))
    add("Durasi" to fmt(m.durationMs))
    if (m.video) {
        val d = dims ?: if (m.width > 0 && m.height > 0) Pair(m.width, m.height) else null
        if (d != null) add("Resolusi" to resolutionLabel(d.first, d.second))
    }
    add("Ukuran" to "${fmtSize(m.size)} (${"%,d".format(m.size)} byte)")
    if (m.durationMs > 0) add("Perkiraan bitrate" to "${m.size * 8 / m.durationMs} kbps")
    if (!m.video) {
        m.artist?.let { add("Artis" to it) }
        m.album?.let { add("Album" to it) }
    }
    add("Ditambahkan" to SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(m.dateAdded * 1000)))
    if (m.path.isNotBlank()) add("Lokasi" to m.path)
}

object Scanner {
    fun videos(ctx: Context) = query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    fun audios(ctx: Context) = query(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)

    private fun query(ctx: Context, base: Uri, video: Boolean): List<Media> {
        val exts = if (video) Formats.VIDEO else Formats.AUDIO
        val durCol = if (video) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION
        val cols = mutableListOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE, durCol
        )
        if (!video) { cols += MediaStore.Audio.Media.ARTIST; cols += MediaStore.Audio.Media.ALBUM }
        if (Build.VERSION.SDK_INT >= 29) {
            cols += MediaStore.MediaColumns.RELATIVE_PATH
            if (video) { cols += MediaStore.MediaColumns.WIDTH; cols += MediaStore.MediaColumns.HEIGHT }
        } else {
            @Suppress("DEPRECATION")
            cols += MediaStore.MediaColumns.DATA
        }

        val out = ArrayList<Media>()
        ctx.contentResolver.query(base, cols.toTypedArray(), null, null,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            fun idx(n: String) = c.getColumnIndex(n)
            fun str(n: String): String? { val i = idx(n); return if (i >= 0) c.getString(i) else null }
            fun lng(n: String): Long { val i = idx(n); return if (i >= 0) c.getLong(i) else 0L }

            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            while (c.moveToNext()) {
                val name = str(MediaStore.MediaColumns.DISPLAY_NAME) ?: continue
                if (Formats.ext(name) !in exts) continue
                var artist = if (!video) str(MediaStore.Audio.Media.ARTIST) else null
                if (artist == "<unknown>") artist = null
                var album = if (!video) str(MediaStore.Audio.Media.ALBUM) else null
                if (album == "<unknown>") album = null
                val path = if (Build.VERSION.SDK_INT >= 29) {
                    str(MediaStore.MediaColumns.RELATIVE_PATH) ?: ""
                } else {
                    @Suppress("DEPRECATION")
                    (str(MediaStore.MediaColumns.DATA) ?: "").substringBeforeLast('/')
                }
                val w = if (video && Build.VERSION.SDK_INT >= 29) lng(MediaStore.MediaColumns.WIDTH).toInt() else 0
                val h = if (video && Build.VERSION.SDK_INT >= 29) lng(MediaStore.MediaColumns.HEIGHT).toInt() else 0
                out += Media(
                    uri = ContentUris.withAppendedId(base, c.getLong(iId)),
                    title = name.substringBeforeLast('.'),
                    fileName = name,
                    artist = artist,
                    album = album,
                    durationMs = lng(durCol),
                    size = lng(MediaStore.MediaColumns.SIZE),
                    dateAdded = lng(MediaStore.MediaColumns.DATE_ADDED),
                    mime = str(MediaStore.MediaColumns.MIME_TYPE) ?: "",
                    path = path,
                    width = w,
                    height = h,
                    video = video,
                )
            }
        }
        return out
    }
}

/** Kunci folder (path lengkap) dan nama folder untuk tampilan "Folder". */
val Media.folderKey: String get() = path.trimEnd('/')
val Media.folderName: String get() = folderKey.substringAfterLast('/').ifBlank { "Penyimpanan internal" }

data class FolderGroup(val key: String, val name: String, val items: List<Media>)
