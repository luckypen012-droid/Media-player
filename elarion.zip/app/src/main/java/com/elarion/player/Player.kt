package com.elarion.player

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Mode putar: 0 berurutan, 1 ulangi semua, 2 ulangi satu, 3 acak. */
fun playModeIcon(m: Int) = when (m) { 1 -> Ic.Repeat; 2 -> Ic.RepeatOne; 3 -> Ic.Shuffle; else -> Ic.Sequential }
fun playModeName(m: Int) = when (m) { 1 -> "Ulangi semua"; 2 -> "Ulangi satu"; 3 -> "Acak"; else -> "Berurutan" }

fun applyMode(c: Player, m: Int) {
    c.repeatMode = when (m) {
        1, 3 -> Player.REPEAT_MODE_ALL
        2 -> Player.REPEAT_MODE_ONE
        else -> Player.REPEAT_MODE_OFF
    }
    c.shuffleModeEnabled = (m == 3)
}

/** Seekbar halus: thumb mengikuti jari, seek hanya sekali saat jari dilepas. */
@Composable
fun SeekBar(pos: Long, dur: Long, preview: Long? = null, onSeek: (Long) -> Unit) {
    val el = LocalEl.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shownFrac = if (preview != null && dur > 0) (preview.toFloat() / dur).coerceIn(0f, 1f) else (drag ?: frac)
    val shownMs = preview ?: drag?.let { (it * dur).toLong() } ?: pos
    Column {
        Slider(
            value = shownFrac,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { if (dur > 0) onSeek((it * dur).toLong()) }
                drag = null
            },
            colors = SliderDefaults.colors(
                thumbColor = el.accent, activeTrackColor = el.accent, inactiveTrackColor = el.accent.copy(alpha = 0.27f)
            )
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween) {
            Text(fmt(shownMs), style = MaterialTheme.typography.bodySmall)
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Mini player ramping satu baris: cover (atau logo Elarion), judul, tombol putar/jeda. Ketuk baris = buka layar pemutar penuh. */
@Composable
fun MiniPlayer(
    c: MediaController, title: String, artist: String, coverUri: Uri?, playing: Boolean,
    pos: Long, dur: Long, onOpen: () -> Unit,
) {
    val el = LocalEl.current
    val ctx = LocalContext.current
    val cover by produceState<Bitmap?>(null, coverUri) {
        value = if (coverUri == null) null else withContext(Dispatchers.IO) { Thumbs.cover(ctx, coverUri) }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen)
            .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black)) {
            val b = cover
            if (b != null) {
                Image(bitmap = b.asImageBitmap(), contentDescription = null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Image(painter = painterResource(R.drawable.elarion_logo), contentDescription = null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            if (artist.isNotBlank()) {
                Text(artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = el.textSoft)
            }
            // Garis progres tipis
            val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(1.dp))
                    .background(el.accent.copy(alpha = 0.25f))
            ) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(el.accent))
            }
        }
        Spacer(Modifier.width(8.dp))
        IconBtn(
            if (playing) Ic.Pause else Ic.Play, { if (playing) c.pause() else c.play() },
            tint = Color.White, bg = el.accentFill, box = 44.dp, icon = 22.dp
        )
    }
}

/** Layar pemutar musik penuh: cover art (atau logo Elarion bila tidak ada), favorit, mode putar. */
@Composable
fun NowPlaying(
    c: MediaController, title: String, artist: String, coverUri: Uri?, playing: Boolean,
    pos: Long, dur: Long, isFav: Boolean, playMode: Int,
    onSeek: (Long) -> Unit, onFav: () -> Unit, onCycleMode: () -> Unit,
    onShare: () -> Unit, onInfo: () -> Unit, onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    var swipe by remember { mutableStateOf<Long?>(null) }
    var menu by remember { mutableStateOf(false) }
    val posNow by rememberUpdatedState(pos)
    val durNow by rememberUpdatedState(dur)
    val seekNow by rememberUpdatedState(onSeek)

    val cover by produceState<Bitmap?>(null, coverUri) {
        value = if (coverUri == null) null else withContext(Dispatchers.IO) { Thumbs.cover(ctx, coverUri) }
    }

    CompositionLocalProvider(LocalEl provides ElLight, LocalContentColor provides InkDark) {
    Column(
        Modifier.fillMaxSize()
            .background(ElarionGradient)
            .pointerInput(Unit) {
                var start = 0L
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { start = posNow; total = 0f; swipe = start },
                    onDragEnd = { swipe?.let { seekNow(it) }; swipe = null },
                    onDragCancel = { swipe = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                        swipe = (start + total / size.width * 120_000f).toLong().coerceIn(0L, durNow)
                    }
                )
            }
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Ic.ChevronDown, onClose, tint = InkDark)
            Spacer(Modifier.weight(1f))
        }

        // Cover art; tanpa cover -> logo Elarion
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(1f).clip(RoundedCornerShape(28.dp)).background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                val b = cover
                if (b != null) {
                    Image(bitmap = b.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Image(painter = painterResource(R.drawable.elarion_logo), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }

        // Judul, artis, favorit
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                if (artist.isNotBlank()) {
                    Text(artist, style = MaterialTheme.typography.bodyLarge, color = InkSoft,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            IconBtn(
                if (isFav) Ic.HeartFilled else Ic.Heart, onFav,
                tint = if (isFav) HeartPink else InkDark, bg = Color(0x55FFFFFF), box = 48.dp, icon = 24.dp
            )
        }

        Spacer(Modifier.height(8.dp))
        SeekBar(pos, dur, swipe, onSeek)
        Spacer(Modifier.height(4.dp))

        // Kontrol: mode putar, sebelumnya, putar/jeda, berikutnya, menu
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            IconBtn(playModeIcon(playMode), onCycleMode, tint = InkDark, box = 48.dp, icon = 26.dp)
            IconBtn(Ic.Prev, { c.seekToPreviousMediaItem() }, tint = InkDark, box = 52.dp, icon = 30.dp)
            IconBtn(
                if (playing) Ic.Pause else Ic.Play, { if (playing) c.pause() else c.play() },
                tint = Color.White, bg = Violet, box = 72.dp, icon = 36.dp
            )
            IconBtn(Ic.Next, { c.seekToNextMediaItem() }, tint = InkDark, box = 52.dp, icon = 30.dp)
            Box {
                IconBtn(Ic.More, { menu = true }, tint = InkDark, box = 48.dp, icon = 26.dp)
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Bagikan") },
                        leadingIcon = { Icon24(Ic.Share, LocalContentColor.current, size = 20.dp) },
                        onClick = { menu = false; onShare() })
                    DropdownMenuItem(
                        text = { Text("Info") },
                        leadingIcon = { Icon24(Ic.Info, LocalContentColor.current, size = 20.dp) },
                        onClick = { menu = false; onInfo() })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    }
}
