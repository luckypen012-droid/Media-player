package com.elarion.player

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Mode putar: 0 berurutan, 1 ulangi semua, 2 ulangi satu lagu, 3 acak. */
fun playModeIcon(m: Int) = when (m) { 1 -> "🔁"; 2 -> "🔂"; 3 -> "🔀"; else -> "➡️" }
fun playModeName(m: Int) = when (m) { 1 -> "Ulangi semua"; 2 -> "Ulangi satu lagu"; 3 -> "Acak"; else -> "Berurutan" }

fun applyMode(c: MediaController, m: Int) {
    c.repeatMode = when (m) {
        1, 3 -> Player.REPEAT_MODE_ALL
        2 -> Player.REPEAT_MODE_ONE
        else -> Player.REPEAT_MODE_OFF
    }
    c.shuffleModeEnabled = (m == 3)
}

/** Seekbar halus: thumb mengikuti jari, seek hanya sekali saat jari dilepas. */
@Composable
fun SeekBar(pos: Long, dur: Long, preview: Long? = null, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val shownFrac = if (preview != null && dur > 0) (preview.toFloat() / dur).coerceIn(0f, 1f) else (drag ?: frac)
    val shownMs = preview ?: drag?.let { (it * dur).toLong() } ?: pos
    Column {
        Slider(
            value = shownFrac,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { if (dur > 0) onSeek((it * dur).toLong()) }
                drag = null
            }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween) {
            Text(fmt(shownMs), style = MaterialTheme.typography.bodySmall)
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MiniPlayer(
    c: MediaController, title: String, playing: Boolean, pos: Long, dur: Long,
    onSeek: (Long) -> Unit, onOpen: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp)
    ) {
        Text("▲  $title", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp))
        SeekBar(pos, dur, null, onSeek)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { if (playing) c.pause() else c.play() }) { Text(if (playing) "⏸" else "▶") }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭") }
        }
    }
}

/** Layar pemutar musik penuh: cover art besar, favorit, mode putar. Geser kiri/kanan di MANA SAJA untuk maju/mundur. */
@Composable
fun NowPlaying(
    c: MediaController, title: String, artist: String, coverUri: Uri?, playing: Boolean,
    pos: Long, dur: Long, isFav: Boolean, playMode: Int,
    onSeek: (Long) -> Unit, onFav: () -> Unit, onCycleMode: () -> Unit,
    onShare: () -> Unit, onInfo: () -> Unit, onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    var swipe by remember { mutableStateOf<Long?>(null) }
    var menu by remember { mutableStateOf(false) }
    val posNow by rememberUpdatedState(pos)
    val durNow by rememberUpdatedState(dur)
    val seekNow by rememberUpdatedState(onSeek)

    val cover by produceState<Bitmap?>(null, coverUri) {
        value = if (coverUri == null) null else withContext(Dispatchers.IO) { Thumbs.cover(ctx, coverUri) }
    }

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                var start = 0L
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { start = posNow; total = 0f; swipe = start },
                    onDragEnd = { swipe?.let { seekNow(it) }; swipe = null },
                    onDragCancel = { swipe = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                        swipe = (start + total / size.width * 120_000f).toLong().coerceIn(0L, durNow)
                    }
                )
            }
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text("⌄ Tutup", Modifier.clickable(onClick = onClose).padding(8.dp))

        // Cover art
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(1f).clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val b = cover
                if (b != null) {
                    Image(bitmap = b.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text("♪", fontSize = 96.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Judul, artis, favorit
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                if (artist.isNotBlank()) {
                    Text(artist, style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onFav),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isFav) "♥" else "♡", fontSize = 24.sp,
                    color = if (isFav) Color(0xFFFF5C7A) else MaterialTheme.colorScheme.onSurface)
            }
        }

        Spacer(Modifier.height(8.dp))
        SeekBar(pos, dur, swipe, onSeek)
        Spacer(Modifier.height(4.dp))

        // Kontrol: mode putar, sebelumnya, putar/jeda, berikutnya, menu
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(
                Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onCycleMode).padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(playModeIcon(playMode), fontSize = 24.sp)
                Text(playModeName(playMode), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { c.seekToPreviousMediaItem() }) { Text("⏮", fontSize = 30.sp) }
            Box(
                Modifier.size(68.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                    .clickable { if (playing) c.pause() else c.play() },
                contentAlignment = Alignment.Center
            ) {
                Text(if (playing) "⏸" else "▶", fontSize = 30.sp, color = MaterialTheme.colorScheme.onPrimary)
            }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", fontSize = 30.sp) }
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 26.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Bagikan") }, onClick = { menu = false; onShare() })
                    DropdownMenuItem(text = { Text("Info") }, onClick = { menu = false; onInfo() })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
