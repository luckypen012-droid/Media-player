package com.elarion.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---- Palet Elarion: violet cerah berpadu gradasi putih ----
val ViolTop = Color(0xFF9D80FF)
val ViolMid = Color(0xFFBDA6FF)
val ViolBottom = Color(0xFFF1EBFF)
val ElarionGradient = Brush.verticalGradient(listOf(ViolTop, ViolMid, ViolBottom))
val Violet = Color(0xFF5B2EE0)
val InkDark = Color(0xFF1C1033)
val InkSoft = Color(0xFF2E2150)
val BarColor = Color(0xFFE6DDFF)
val PanelColor = Color(0xFFF6F2FF)
val HeartPink = Color(0xFFE0457B)

val ElarionScheme = lightColorScheme(
    primary = Violet, onPrimary = Color.White,
    primaryContainer = Color(0xFFD9CCFF), onPrimaryContainer = Color(0xFF21005D),
    secondary = Color(0xFF7A5AF8), onSecondary = Color.White,
    background = ViolBottom, onBackground = InkDark,
    surface = PanelColor, onSurface = InkDark,
    surfaceVariant = Color(0xFFE3D9FF), onSurfaceVariant = InkSoft,
    outline = Color(0xFF6F5FA6), error = Color(0xFFBA1A1A),
)

enum class Ic {
    Play, Pause, Next, Prev, Lock, LockOpen, Volume, VolumeOff, Pip, Speed, Trash, Rotate,
    Repeat, RepeatOne, Shuffle, Sequential, Heart, HeartFilled, More, Close, ChevronDown,
    Subtitle, Share, Info, Search, Music, Video, Sun, Check
}

/** Ikon seragam: garis 2 unit, ujung membulat, grid 24x24. */
@Composable
fun Icon24(ic: Ic, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) { drawIcon(ic, tint) }
}

@Composable
fun IconBtn(
    ic: Ic, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = InkDark,
    bg: Color = Color.Transparent, box: Dp = 44.dp, icon: Dp = 24.dp,
) {
    Box(
        modifier.size(box).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon24(ic, tint, size = icon) }
}

private fun DrawScope.drawIcon(ic: Ic, tint: Color) {
    val s = this.size.width / 24f
    val sw = 2f * s
    val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val soft = Stroke(width = 1.4f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun o(x: Float, y: Float) = Offset(x * s, y * s)
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(tint, o(x1, y1), o(x2, y2), strokeWidth = sw, cap = StrokeCap.Round)
    fun Path.m(x: Float, y: Float) = moveTo(x * s, y * s)
    fun Path.l(x: Float, y: Float) = lineTo(x * s, y * s)
    fun Path.q(x1: Float, y1: Float, x2: Float, y2: Float) = quadraticBezierTo(x1 * s, y1 * s, x2 * s, y2 * s)
    fun Path.c(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) =
        cubicTo(x1 * s, y1 * s, x2 * s, y2 * s, x3 * s, y3 * s)
    fun Path.a(l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float) =
        arcTo(Rect(l * s, t * s, r * s, b * s), start, sweep, false)
    fun stroke(block: Path.() -> Unit) { drawPath(Path().apply(block), tint, style = st) }
    fun solid(block: Path.() -> Unit) {
        val p = Path().apply(block)
        drawPath(p, tint, style = Fill)
        drawPath(p, tint, style = soft)
    }
    fun rrStroke(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        drawRoundRect(tint, o(l, t), Size((r - l) * s, (b - t) * s), CornerRadius(rad * s), style = st)
    fun rrFill(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        drawRoundRect(tint, o(l, t), Size((r - l) * s, (b - t) * s), CornerRadius(rad * s))
    fun dot(x: Float, y: Float, r: Float) = drawCircle(tint, r * s, o(x, y))
    fun ring(x: Float, y: Float, r: Float) = drawCircle(tint, r * s, o(x, y), style = st)
    fun Path.heart() {
        m(12f, 20f)
        c(5f, 15f, 3f, 11.8f, 3f, 8.6f)
        c(3f, 6f, 5f, 4f, 7.5f, 4f)
        c(9.4f, 4f, 11f, 5f, 12f, 6.6f)
        c(13f, 5f, 14.6f, 4f, 16.5f, 4f)
        c(19f, 4f, 21f, 6f, 21f, 8.6f)
        c(21f, 11.8f, 19f, 15f, 12f, 20f)
        close()
    }
    fun speaker() = stroke {
        m(4f, 9.5f); l(8f, 9.5f); l(12.5f, 5.5f); l(12.5f, 18.5f); l(8f, 14.5f); l(4f, 14.5f); close()
    }
    fun repeatBase() {
        stroke { m(4f, 11f); l(4f, 10f); q(4f, 7f, 7f, 7f); l(19.5f, 7f) }
        stroke { m(17f, 4.5f); l(19.5f, 7f); l(17f, 9.5f) }
        stroke { m(20f, 13f); l(20f, 14f); q(20f, 17f, 17f, 17f); l(4.5f, 17f) }
        stroke { m(7f, 14.5f); l(4.5f, 17f); l(7f, 19.5f) }
    }

    when (ic) {
        Ic.Play -> solid { m(8f, 5f); l(19f, 12f); l(8f, 19f); close() }
        Ic.Pause -> { rrFill(6f, 5f, 10f, 19f, 1.5f); rrFill(14f, 5f, 18f, 19f, 1.5f) }
        Ic.Next -> { solid { m(6f, 5f); l(16f, 12f); l(6f, 19f); close() }; ln(18.5f, 5f, 18.5f, 19f) }
        Ic.Prev -> { solid { m(18f, 5f); l(8f, 12f); l(18f, 19f); close() }; ln(5.5f, 5f, 5.5f, 19f) }
        Ic.Lock -> {
            rrStroke(5f, 11f, 19f, 21f, 2.5f)
            stroke { m(8f, 11f); l(8f, 8f); a(8f, 4f, 16f, 12f, 180f, 180f); l(16f, 11f) }
            dot(12f, 16f, 1.2f)
        }
        Ic.LockOpen -> {
            rrStroke(5f, 11f, 19f, 21f, 2.5f)
            stroke { m(8f, 11f); l(8f, 7f); a(8f, 3f, 16f, 11f, 180f, 180f); l(16f, 8f) }
            dot(12f, 16f, 1.2f)
        }
        Ic.Volume -> {
            speaker()
            stroke { a(9f, 8f, 17f, 16f, -50f, 100f) }
            stroke { a(5f, 4f, 21f, 20f, -50f, 100f) }
        }
        Ic.VolumeOff -> {
            speaker()
            ln(16f, 9.5f, 21f, 14.5f); ln(21f, 9.5f, 16f, 14.5f)
        }
        Ic.Pip -> { rrStroke(3f, 5f, 21f, 19f, 2.5f); rrFill(12f, 11f, 18.5f, 16f, 1.2f) }
        Ic.Speed -> {
            drawCircle(
                tint, 9f * s, o(12f, 12f),
                style = Stroke(width = sw, cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.2f * s, 3.4f * s)))
            )
            solid { m(10.2f, 8.8f); l(15.5f, 12f); l(10.2f, 15.2f); close() }
        }
        Ic.Trash -> {
            ln(4.5f, 7f, 19.5f, 7f)
            stroke { m(9f, 7f); l(9f, 4.5f); l(15f, 4.5f); l(15f, 7f) }
            stroke { m(6.5f, 7f); l(7.5f, 19.5f); q(7.6f, 20.5f, 8.6f, 20.5f); l(15.4f, 20.5f); q(16.4f, 20.5f, 16.5f, 19.5f); l(17.5f, 7f) }
            ln(10.5f, 11f, 10.5f, 16.5f); ln(13.5f, 11f, 13.5f, 16.5f)
        }
        Ic.Rotate -> {
            rrStroke(5f, 9f, 13f, 21f, 2f)
            stroke { a(9f, 2f, 21f, 14f, -120f, 130f) }
            stroke { m(19f, 7f); l(20.9f, 9.2f); l(22.6f, 7f) }
        }
        Ic.Repeat -> repeatBase()
        Ic.RepeatOne -> { repeatBase(); stroke { m(10.8f, 10.6f); l(12.4f, 9.3f); l(12.4f, 14.8f) } }
        Ic.Shuffle -> {
            stroke { m(4f, 7f); l(7f, 7f); c(11f, 7f, 11.5f, 17f, 15.5f, 17f); l(19f, 17f) }
            stroke { m(4f, 17f); l(7f, 17f); c(8.6f, 17f, 9.6f, 16f, 10.4f, 14.7f) }
            stroke { m(13.6f, 9.3f); c(14.4f, 8f, 15.3f, 7f, 17f, 7f); l(19f, 7f) }
            stroke { m(17f, 4.8f); l(19.3f, 7f); l(17f, 9.2f) }
            stroke { m(17f, 14.8f); l(19.3f, 17f); l(17f, 19.2f) }
        }
        Ic.Sequential -> {
            ln(4f, 12f, 17f, 12f)
            stroke { m(13f, 8f); l(17f, 12f); l(13f, 16f) }
            ln(20.5f, 8f, 20.5f, 16f)
        }
        Ic.Heart -> stroke { heart() }
        Ic.HeartFilled -> solid { heart() }
        Ic.More -> { dot(12f, 5f, 1.9f); dot(12f, 12f, 1.9f); dot(12f, 19f, 1.9f) }
        Ic.Close -> { ln(6f, 6f, 18f, 18f); ln(18f, 6f, 6f, 18f) }
        Ic.ChevronDown -> stroke { m(6f, 9f); l(12f, 15f); l(18f, 9f) }
        Ic.Subtitle -> {
            rrStroke(3f, 5f, 21f, 19f, 3f)
            ln(7f, 10.5f, 10.5f, 10.5f); ln(13f, 10.5f, 17f, 10.5f)
            ln(7f, 14f, 12f, 14f); ln(14.5f, 14f, 17f, 14f)
        }
        Ic.Share -> {
            ring(6f, 12f, 2.4f); ring(18f, 6f, 2.4f); ring(18f, 18f, 2.4f)
            ln(8.2f, 10.9f, 15.8f, 7.1f); ln(8.2f, 13.1f, 15.8f, 16.9f)
        }
        Ic.Info -> { ring(12f, 12f, 9f); dot(12f, 7.8f, 1.2f); ln(12f, 11f, 12f, 16.5f) }
        Ic.Search -> { ring(10.5f, 10.5f, 6f); ln(15f, 15f, 20f, 20f) }
        Ic.Music -> {
            ln(9f, 17.5f, 9f, 6.5f); ln(9f, 6.5f, 18.5f, 4.5f); ln(18.5f, 4.5f, 18.5f, 15.5f)
            dot(6.8f, 17.8f, 2.4f); dot(16.3f, 15.8f, 2.4f)
        }
        Ic.Video -> { rrStroke(3f, 5f, 21f, 19f, 3.5f); solid { m(10f, 9f); l(15f, 12f); l(10f, 15f); close() } }
        Ic.Sun -> {
            ring(12f, 12f, 4f)
            for (k in 0 until 8) {
                val ang = k * PI.toFloat() / 4f
                ln(12f + 7f * cos(ang), 12f + 7f * sin(ang), 12f + 9.5f * cos(ang), 12f + 9.5f * sin(ang))
            }
        }
        Ic.Check -> stroke { m(5f, 12.5f); l(10f, 17.5f); l(19f, 7f) }
    }
}
