package com.elarion.player

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** Thumbnail kecil untuk daftar video / folder. */
    fun thumb(ctx: Context, m: Media, px: Int): Bitmap? {
        val key = "${m.uri}#$px"
        cache.get(key)?.let { return it }
        val bmp: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(m.uri, Size(px, px), null)
            } else if (m.video) {
                MediaStore.Video.Thumbnails.getThumbnail(
                    ctx.contentResolver, ContentUris.parseId(m.uri),
                    MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            } else null
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    /** Cover art besar untuk layar pemutar musik (gambar tertanam di file, atau dari MediaStore). */
    fun cover(ctx: Context, uri: Uri): Bitmap? {
        val key = "$uri#cover"
        cache.get(key)?.let { return it }
        var bmp: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / s > 1200 && o.outHeight / s > 1200) s *= 2
                bmp = BitmapFactory.decodeByteArray(
                    bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        if (bmp == null && Build.VERSION.SDK_INT >= 29) {
            bmp = try { ctx.contentResolver.loadThumbnail(uri, Size(1024, 1024), null) } catch (_: Exception) { null }
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}

@Composable
fun Thumb(m: Media, modifier: Modifier, badge: String? = null) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, m.uri) {
        value = withContext(Dispatchers.IO) { Thumbs.thumb(ctx, m, 256) }
    }
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(if (m.video) "▶" else "♪", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (badge != null) {
            Text(
                badge, fontSize = 11.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}
