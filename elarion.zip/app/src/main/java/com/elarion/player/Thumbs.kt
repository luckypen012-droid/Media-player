package com.elarion.player

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** Thumbnail kecil untuk daftar video / folder. */
    fun thumb(ctx: Context, m: Media, px: Int): Bitmap? {
        val key = "${m.uri}#$px"
        cache.get(key)?.let { return it }
        if (m.uri.scheme == "file") {
            val fb = fileThumb(m, px)
            if (fb != null) cache.put(key, fb)
            return fb
        }
        val bmp: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(m.uri, Size(px, px), null)
            } else if (m.video) {
                MediaStore.Video.Thumbnails.getThumbnail(
                    ctx.contentResolver, ContentUris.parseId(m.uri),
                    MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            } else if (m.mime.startsWith("image/")) {
                @Suppress("DEPRECATION")
                MediaStore.Images.Thumbnails.getThumbnail(
                    ctx.contentResolver, ContentUris.parseId(m.uri),
                    MediaStore.Images.Thumbnails.MINI_KIND, null
                )
            } else null
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    /** Thumbnail untuk berkas privat Asylum (file://), video maupun foto. */
    private fun fileThumb(m: Media, px: Int): Bitmap? {
        val path = m.uri.path ?: return null
        val side = maxOf(px, 384)
        if (!m.video) return imageFile(path, side)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val f = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L)
            if (f == null) null else {
                val k = side.toFloat() / maxOf(f.width, f.height)
                if (k >= 1f) f else Bitmap.createScaledBitmap(f, (f.width * k).toInt().coerceAtLeast(1), (f.height * k).toInt().coerceAtLeast(1), true)
            }
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Baca foto dari berkas, diperkecil (sisi terpanjang sekitar maxPx) dan diputar sesuai EXIF. */
    fun imageFile(path: String, maxPx: Int): Bitmap? {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= maxPx || o.outHeight / (s * 2) >= maxPx) s *= 2
            val b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
            val deg = when (android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
            if (deg == 0f) return b
            return Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
        } catch (e: Throwable) {
            return null
        }
    }

    /** Cover art besar: HANYA gambar yang tertanam di file musik itu sendiri. Tanpa cover -> null (diganti logo Elarion). */
    fun cover(ctx: Context, uri: Uri): Bitmap? {
        val key = "$uri#cover"
        cache.get(key)?.let { return it }
        var bmp: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / s > 1200 && o.outHeight / s > 1200) s *= 2
                bmp = BitmapFactory.decodeByteArray(
                    bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}

@Composable
fun Thumb(m: Media, modifier: Modifier, badge: String? = null) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, m.uri) {
        value = withContext(Dispatchers.IO) { Thumbs.thumb(ctx, m, 256) }
    }
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(
                when { m.video -> "▶"; m.mime.startsWith("image/") -> ""; else -> "♪" },
                fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (badge != null) {
            Text(
                badge, fontSize = 11.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}
