package com.elarion.player

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

class VideoPlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var overlay: TextView
    private lateinit var rotateBtn: ImageButton
    private lateinit var detector: GestureDetector
    private var key = ""
    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    // status geser kiri/kanan
    private var downX = 0f
    private var downY = 0f
    private var startPos = 0L
    private var target = 0L
    private var tracking = false
    private var seeking = false
    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: run { finish(); return }
        key = "pos_$uri"

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
        }

        overlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(12), dp(24), dp(12))
            setBackgroundResource(R.drawable.bg_overlay)
            visibility = View.GONE
        }

        rotateBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_rotate)
            setBackgroundResource(R.drawable.bg_round)
            scaleType = android.widget.ImageView.ScaleType.CENTER
            contentDescription = "Putar layar"
            setOnClickListener {
                val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        }
        // tombol putar ikut muncul/hilang bersama kontrol pemutar
        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            rotateBtn.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })

        val root = FrameLayout(this)
        root.addView(view, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(rotateBtn, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(24), dp(108))
        })
        setContentView(root)

        // Dobel tap kiri = mundur 10 detik, kanan = maju 10 detik
        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val delta = if (e.x < view.width / 2) -10_000L else 10_000L
                val max = if (p.duration > 0) p.duration else Long.MAX_VALUE
                p.seekTo((p.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
    }

    /** Geser kiri/kanan di MANA SAJA pada layar untuk maju/mundur. Seek dilakukan saat jari dilepas. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!::detector.isInitialized) return super.dispatchTouchEvent(ev)
        detector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                seeking = false
                startPos = player?.currentPosition ?: 0L
                // jangan ganggu garis seekbar bawaan saat kontrol terlihat
                tracking = !(view.isControllerFullyVisible && downY > view.height * 0.7f)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                val p = player
                if (tracking && !seeking && p != null && abs(dx) > slop * 3 && abs(dx) > abs(dy) * 1.5f) {
                    seeking = true
                    handler.removeCallbacks(hideOverlay)
                    val c = MotionEvent.obtain(ev)
                    c.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(c)
                    c.recycle()
                }
                if (seeking && p != null) {
                    val max = if (p.duration > 0) p.duration else Long.MAX_VALUE
                    target = (startPos + dx / view.width * 120_000f).toLong().coerceIn(0L, max)
                    val diff = (target - startPos) / 1000
                    val sign = if (diff >= 0) "+" else "-"
                    overlay.text = "${fmt(target)}  ($sign${fmt(abs(diff) * 1000)})"
                    overlay.visibility = View.VISIBLE
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracking = false
                if (seeking) {
                    seeking = false
                    player?.seekTo(target)
                    handler.postDelayed(hideOverlay, 600)
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        val uri = intent.data ?: return
        val p = ExoPlayer.Builder(this).build()
        view.player = p
        p.setMediaItem(MediaItem.fromUri(uri))
        val saved = getSharedPreferences("elarion", MODE_PRIVATE).getLong(key, 0L)
        if (saved > 0) p.seekTo(saved)   // lanjut dari posisi terakhir
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    override fun onStop() {
        player?.let { p ->
            val prefs = getSharedPreferences("elarion", MODE_PRIVATE).edit()
            val nearEnd = p.duration > 0 && p.currentPosition > p.duration - 3000
            if (nearEnd) prefs.remove(key) else prefs.putLong(key, p.currentPosition)
            prefs.apply()
            view.player = null
            p.release()
        }
        player = null
        super.onStop()
    }
}
