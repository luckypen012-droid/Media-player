package com.elarion.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.app.RecoverableSecurityException
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class VideoPlayerActivity : ComponentActivity() {
    private var player by mutableStateOf<ExoPlayer?>(null)
    private val playlist = mutableStateListOf<String>()
    private var startIndex = 0
    private var counted = false

    private var isPlaying by mutableStateOf(false)
    private var curIndex by mutableIntStateOf(0)
    private var tracks by mutableStateOf(Tracks.EMPTY)
    private var inPip by mutableStateOf(false)
    private var videoMode by mutableIntStateOf(0)
    private var muted by mutableStateOf(false)

    private val prefs by lazy { getSharedPreferences("elarion", MODE_PRIVATE) }
    private val playPrefs by lazy { getSharedPreferences("elarion_plays", MODE_PRIVATE) }
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    // ---------- siklus hidup ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent.data
        val list = intent.getStringArrayListExtra("playlist")
        val initial = if (!list.isNullOrEmpty()) list else listOfNotNull(data?.toString())
        if (initial.isEmpty()) { finish(); return }
        playlist.addAll(initial)
        val idx = intent.getIntExtra("index", -1)
        startIndex = if (idx in playlist.indices) idx else playlist.indexOf(data?.toString()).coerceAtLeast(0)
        curIndex = startIndex
        videoMode = prefs.getInt("video_mode", 0)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        setContent { MaterialTheme(colorScheme = ElarionScheme) { VideoScreen() } }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            player?.let { curIndex = it.currentMediaItemIndex }
            val id = mediaItem?.mediaId ?: return
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) addPlay(id)
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) {
                val r = resumeFor(id)
                if (r > 0) player?.seekTo(r)
            }
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int
        ) {
            if (oldPosition.mediaItemIndex != newPosition.mediaItemIndex) {
                val id = oldPosition.mediaItem?.mediaId ?: return
                val e = prefs.edit()
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) e.remove("pos_$id")
                else e.putLong("pos_$id", oldPosition.positionMs)
                e.apply()
            }
        }

        override fun onTracksChanged(t: Tracks) { tracks = t }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(this@VideoPlayerActivity, "Video ini tidak bisa diputar", Toast.LENGTH_SHORT).show()
            val p = player ?: return
            if (p.hasNextMediaItem()) { p.seekToNextMediaItem(); p.prepare(); p.play() }
        }
    }

    override fun onStart() {
        super.onStart()
        if (player != null || playlist.isEmpty()) return
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(listener)
        val items = playlist.map { MediaItem.Builder().setUri(Uri.parse(it)).setMediaId(it).build() }
        val idx = startIndex.coerceIn(0, items.lastIndex)
        p.setMediaItems(items, idx, resumeFor(items[idx].mediaId))
        applyMode(p, videoMode)
        p.volume = if (muted) 0f else 1f
        p.prepare()
        p.playWhenReady = true
        player = p
        curIndex = idx
        if (!counted) { counted = true; addPlay(items[idx].mediaId) }
    }

    override fun onStop() {
        player?.let { p ->
            startIndex = p.currentMediaItemIndex
            saveProgress(p)
            p.removeListener(listener)
            p.release()
        }
        player = null
        super.onStop()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    // ---------- bantuan ----------
    private fun resumeFor(id: String): Long {
        val v = prefs.getLong("pos_$id", 0L)
        return if (v > 2000) v else 0L
    }

    private fun addPlay(id: String) {
        playPrefs.edit().putInt(id, playPrefs.getInt(id, 0) + 1).apply()
    }

    private fun saveProgress(p: ExoPlayer) {
        val id = p.currentMediaItem?.mediaId ?: return
        val e = prefs.edit()
        val nearEnd = p.duration > 0 && p.currentPosition > p.duration - 3000
        if (nearEnd) e.remove("pos_$id") else e.putLong("pos_$id", p.currentPosition)
        e.apply()
    }

    private fun displayName(uri: Uri): String {
        val n: String? = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) { null }
        return n?.substringBeforeLast('.') ?: (uri.lastPathSegment ?: "Video")
    }

    private fun switchTo(i: Int) {
        val pl = player ?: return
        val id = playlist.getOrNull(i) ?: return
        if (i == pl.currentMediaItemIndex) return
        pl.seekTo(i, resumeFor(id))
        pl.play()
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else {
            if (p.playbackState == Player.STATE_ENDED) p.seekToDefaultPosition()
            p.play()
        }
    }

    private fun toggleMute() {
        muted = !muted
        player?.volume = if (muted) 0f else 1f
    }

    private fun toggleRotation() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        val vs = player?.videoSize
        var ratio = Rational(16, 9)
        if (vs != null && vs.width > 0 && vs.height > 0) {
            val r = vs.width.toFloat() / vs.height
            if (r in 0.45f..2.3f) ratio = Rational(vs.width, vs.height)
        }
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (e: Exception) {
            Toast.makeText(this, "Mode jendela kecil tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) { 0.5f }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    private fun volumeFraction(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max > 0) audio.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat() else 0f
    }

    private fun setVolume(f: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt().coerceIn(0, max), 0)
    }

    private fun trackName(g: Tracks.Group, i: Int): String {
        val f = g.getTrackFormat(0)
        val lang = f.language?.takeIf { it != "und" }
            ?.let { Locale.forLanguageTag(it).displayLanguage }?.takeIf { it.isNotBlank() }
        return listOfNotNull(f.label, lang).distinct().joinToString(" • ").ifBlank { "Trek ${i + 1}" }
    }

    private fun selectTrack(g: Tracks.Group, type: Int) {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
            .build()
    }

    private fun disableText() {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
    }

    private fun afterDeleted(id: String) {
        val idx = playlist.indexOf(id)
        if (idx < 0) return
        playlist.removeAt(idx)
        player?.removeMediaItem(idx)
        Toast.makeText(this, "Video dihapus", Toast.LENGTH_SHORT).show()
        if (playlist.isEmpty()) { finish(); return }
        curIndex = (player?.currentMediaItemIndex ?: 0).coerceIn(0, playlist.lastIndex)
    }

    // ---------- tampilan ----------
    @Composable
    private fun RoundBtn(ic: Ic, small: Boolean, onClick: () -> Unit) {
        IconBtn(
            ic, onClick, tint = Color.White, bg = Color(0x66000000),
            box = if (small) 40.dp else 46.dp, icon = if (small) 22.dp else 24.dp
        )
    }

    @Composable
    private fun VideoScreen() {
        val act = this@VideoPlayerActivity
        val p = player

        var metas by remember { mutableStateOf<Map<String, Media>>(emptyMap()) }
        LaunchedEffect(Unit) {
            metas = withContext(Dispatchers.IO) { Scanner.videos(act).associateBy { it.uri.toString() } }
        }
        val curId = playlist.getOrNull(curIndex) ?: ""
        val fallbackName = remember(curId) { if (curId.isEmpty()) "Video" else displayName(Uri.parse(curId)) }
        val title = metas[curId]?.title ?: fallbackName

        var controls by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(false) }
        var lockHint by remember { mutableStateOf(false) }
        var touch by remember { mutableIntStateOf(0) }
        var pos by remember { mutableLongStateOf(0L) }
        var dur by remember { mutableLongStateOf(0L) }
        var swipeInfo by remember { mutableStateOf<String?>(null) }
        var hud by remember { mutableStateOf<Pair<Ic, Int>?>(null) }
        var dialog by remember { mutableIntStateOf(0) }   // 1 suara, 2 subtitle, 3 kecepatan, 4 hapus
        var speed by remember { mutableFloatStateOf(1f) }
        var pendingDeleteId by remember { mutableStateOf("") }
        var stripScrolling by remember { mutableStateOf(false) }
        val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

        LaunchedEffect(p) {
            while (isActive) {
                p?.let { pos = it.currentPosition; dur = it.duration.coerceAtLeast(0L) }
                delay(250)
            }
        }
        // Kontrol tidak hilang selama daftar video sedang digeser; hitung mundur mulai setelah berhenti
        LaunchedEffect(controls, isPlaying, touch, locked, stripScrolling) {
            if (controls && isPlaying && !locked && !stripScrolling) { delay(4000); controls = false }
        }
        LaunchedEffect(hud) { if (hud != null) { delay(800); hud = null } }
        LaunchedEffect(lockHint) { if (lockHint) { delay(2500); lockHint = false } }

        val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK) {
                if (Build.VERSION.SDK_INT == 29) {
                    try { contentResolver.delete(Uri.parse(pendingDeleteId), null, null) } catch (_: Exception) {}
                }
                afterDeleted(pendingDeleteId)
            }
        }
        fun requestDelete() {
            val id = curId
            if (id.isEmpty()) return
            pendingDeleteId = id
            val uri = Uri.parse(id)
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                    deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else {
                    contentResolver.delete(uri, null, null)
                    afterDeleted(id)
                }
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } else Toast.makeText(act, "Tidak bisa menghapus: izin ditolak", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(act, "Tidak bisa menghapus video ini", Toast.LENGTH_LONG).show()
            }
        }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false
                        setBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                update = { it.player = p },
                modifier = Modifier.fillMaxSize()
            )

            // ===== Lapisan gestur: ketuk, dobel ketuk, geser =====
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(locked, inPip) {
                        detectTapGestures(
                            onTap = {
                                if (locked) lockHint = !lockHint
                                else if (!inPip) { controls = !controls; touch++ }
                            },
                            onDoubleTap = { off ->
                                val pl = player
                                if (!locked && !inPip && pl != null) {
                                    val delta = if (off.x < size.width / 2f) -10_000L else 10_000L
                                    val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                                    pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                                }
                            }
                        )
                    }
                    .pointerInput(locked, inPip) {
                        if (locked || inPip) return@pointerInput
                        var mode = 0            // 0 belum jelas, 1 seek, 2 kecerahan, 3 volume
                        var totX = 0f
                        var totY = 0f
                        var startX = 0f
                        var startPos = 0L
                        var base = 0f
                        var target = 0L
                        detectDragGestures(
                            onDragStart = { off ->
                                mode = 0; totX = 0f; totY = 0f; startX = off.x
                                startPos = player?.currentPosition ?: 0L
                            },
                            onDragEnd = {
                                if (mode == 1) player?.seekTo(target)
                                swipeInfo = null; mode = 0
                            },
                            onDragCancel = { swipeInfo = null; mode = 0 },
                            onDrag = { change, amount ->
                                change.consume()
                                totX += amount.x; totY += amount.y
                                if (mode == 0 && (abs(totX) > 20f || abs(totY) > 20f)) {
                                    mode = if (abs(totX) > abs(totY)) 1 else if (startX < size.width / 2f) 2 else 3
                                    if (mode == 2) base = currentBrightness()
                                    if (mode == 3) base = volumeFraction()
                                }
                                when (mode) {
                                    1 -> {
                                        val pl = player
                                        val max = if (pl != null && pl.duration > 0) pl.duration else Long.MAX_VALUE
                                        target = (startPos + (totX / size.width * 120_000f).toLong()).coerceIn(0L, max)
                                        val diff = (target - startPos) / 1000
                                        val sign = if (diff >= 0) "+" else "-"
                                        swipeInfo = "${fmt(target)}  ($sign${fmt(abs(diff) * 1000)})"
                                    }
                                    2 -> {
                                        val v = (base - totY / size.height * 1.3f).coerceIn(0.02f, 1f)
                                        setBrightness(v)
                                        hud = Ic.Sun to (v * 100).roundToInt()
                                    }
                                    3 -> {
                                        val v = (base - totY / size.height * 1.3f).coerceIn(0f, 1f)
                                        if (muted) toggleMute()
                                        setVolume(v)
                                        hud = (if (v == 0f) Ic.VolumeOff else Ic.Volume) to (v * 100).roundToInt()
                                    }
                                }
                            }
                        )
                    }
            )

            // ===== Info seek / kecerahan / volume =====
            swipeInfo?.let {
                Text(
                    it, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(16.dp))
                        .background(Color(0x99000000)).padding(horizontal = 24.dp, vertical = 12.dp)
                )
            }
            hud?.let { (ic, pct) ->
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 72.dp).clip(RoundedCornerShape(24.dp))
                        .background(Color(0x99000000)).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon24(ic, Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("$pct%", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            // ===== Tombol buka kunci =====
            AnimatedVisibility(
                visible = locked && lockHint && !inPip, enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                    IconBtn(
                        Ic.Lock, { locked = false; lockHint = false; controls = true; touch++ },
                        Modifier.align(Alignment.CenterStart).padding(start = 24.dp),
                        tint = Color.White, bg = Color(0x99000000), box = 52.dp, icon = 26.dp
                    )
                }
            }

            // ===== Kontrol =====
            AnimatedVisibility(
                visible = controls && !locked && !inPip, enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    Modifier.fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent, Color.Transparent, Color(0xCC000000))))
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                ) {
                    // Atas: tutup, judul, subtitle
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconBtn(Ic.ChevronDown, { finish() }, tint = Color.White)
                        Text(
                            title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        IconBtn(Ic.Subtitle, {
                            touch++
                            val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
                            val multiAudio = tracks.groups.count { it.type == C.TRACK_TYPE_AUDIO } > 1
                            if (hasText || multiAudio) dialog = 2
                            else Toast.makeText(act, "Tidak ada subtitle atau trek audio tambahan", Toast.LENGTH_SHORT).show()
                        }, tint = Color.White)
                    }

                    // Tengah: sebelumnya, putar/jeda, berikutnya
                    Row(
                        Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(28.dp)
                    ) {
                        IconBtn(Ic.Prev, { p?.seekToPreviousMediaItem(); touch++ }, tint = Color.White, box = 52.dp, icon = 28.dp)
                        IconBtn(
                            if (isPlaying) Ic.Pause else Ic.Play, { togglePlay(); touch++ },
                            tint = Color.White, bg = Color(0x66000000), box = 72.dp, icon = 40.dp
                        )
                        IconBtn(Ic.Next, { p?.seekToNextMediaItem(); touch++ }, tint = Color.White, box = 52.dp, icon = 28.dp)
                    }

                    // Bawah: deretan tombol, seekbar, daftar video
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 8.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), Arrangement.SpaceBetween) {
                            RoundBtn(Ic.LockOpen, landscape) { locked = true; controls = false }
                            RoundBtn(if (muted) Ic.VolumeOff else Ic.Volume, landscape) { toggleMute(); touch++ }
                            RoundBtn(Ic.Pip, landscape) { enterPip() }
                            RoundBtn(playModeIcon(videoMode), landscape) {
                                videoMode = (videoMode + 1) % 4
                                prefs.edit().putInt("video_mode", videoMode).apply()
                                player?.let { applyMode(it, videoMode) }
                                touch++
                            }
                            RoundBtn(Ic.Speed, landscape) { dialog = 3; touch++ }
                            RoundBtn(Ic.Trash, landscape) {
                                touch++
                                if (Build.VERSION.SDK_INT >= 30) requestDelete() else dialog = 4
                            }
                            RoundBtn(Ic.Rotate, landscape) { toggleRotation(); touch++ }
                        }

                        var drag by remember { mutableStateOf<Float?>(null) }
                        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
                        val timeNow = fmt(drag?.let { (it * dur).toLong() } ?: pos)
                        val sliderColors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = Color.White,
                            inactiveTrackColor = Color(0x55FFFFFF)
                        )
                        if (landscape) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(timeNow, color = Color.White, fontSize = 12.sp)
                                Slider(
                                    value = drag ?: frac,
                                    onValueChange = { drag = it; touch++ },
                                    onValueChangeFinished = {
                                        drag?.let { if (dur > 0) player?.seekTo((it * dur).toLong()) }
                                        drag = null
                                    },
                                    colors = sliderColors,
                                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
                                )
                                Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                            }
                        } else {
                            Slider(
                                value = drag ?: frac,
                                onValueChange = { drag = it; touch++ },
                                onValueChangeFinished = {
                                    drag?.let { if (dur > 0) player?.seekTo((it * dur).toLong()) }
                                    drag = null
                                },
                                colors = sliderColors,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), Arrangement.SpaceBetween) {
                                Text(timeNow, color = Color.White, fontSize = 13.sp)
                                Text(fmt(dur), color = Color.White, fontSize = 13.sp)
                            }
                        }

                        if (playlist.size > 1) {
                            val listState = rememberLazyListState()
                            LaunchedEffect(curIndex) {
                                if (curIndex in playlist.indices) listState.animateScrollToItem(curIndex)
                            }
                            LaunchedEffect(listState.isScrollInProgress) {
                                stripScrolling = listState.isScrollInProgress
                                if (!listState.isScrollInProgress) touch++
                            }
                            DisposableEffect(Unit) { onDispose { stripScrolling = false } }
                            LazyRow(
                                state = listState,
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().height(if (landscape) 58.dp else 80.dp).padding(top = if (landscape) 2.dp else 6.dp)
                            ) {
                                itemsIndexed(playlist) { i, id ->
                                    val m = metas[id]
                                    val sel = i == curIndex
                                    Box(
                                        Modifier.width(if (landscape) (if (sel) 92.dp else 78.dp) else (if (sel) 118.dp else 100.dp))
                                            .height(if (landscape) (if (sel) 52.dp else 44.dp) else (if (sel) 68.dp else 56.dp))
                                            .clip(RoundedCornerShape(12.dp))
                                            .then(if (sel) Modifier.border(2.5.dp, Color.White, RoundedCornerShape(12.dp)) else Modifier)
                                            .clickable { switchTo(i); touch++ }
                                    ) {
                                        if (m != null) Thumb(m, Modifier.fillMaxSize())
                                        else Box(Modifier.fillMaxSize().background(Color(0xFF222222)))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== Dialog =====
        when (dialog) {
            2 -> {
                val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                val anyText = textGroups.any { it.isSelected }
                AlertDialog(
                    onDismissRequest = { dialog = 0 },
                    containerColor = PanelColor,
                    title = { Text("Audio & subtitle") },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            if (audioGroups.size > 1) {
                                Text("Trek audio", style = MaterialTheme.typography.labelMedium, color = InkSoft)
                                audioGroups.forEachIndexed { i, g ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { selectTrack(g, C.TRACK_TYPE_AUDIO) }.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = g.isSelected, onClick = { selectTrack(g, C.TRACK_TYPE_AUDIO) })
                                        Text(trackName(g, i))
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                            }
                            if (textGroups.isNotEmpty()) {
                                Text("Subtitle", style = MaterialTheme.typography.labelMedium, color = InkSoft)
                                Row(
                                    Modifier.fillMaxWidth().clickable { disableText() }.padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = !anyText, onClick = { disableText() })
                                    Text("Mati")
                                }
                                textGroups.forEachIndexed { i, g ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { selectTrack(g, C.TRACK_TYPE_TEXT) }.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = g.isSelected, onClick = { selectTrack(g, C.TRACK_TYPE_TEXT) })
                                        Text(trackName(g, i))
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { dialog = 0 }) { Text("Tutup") } }
                )
            }
            3 -> AlertDialog(
                onDismissRequest = { dialog = 0 },
                containerColor = PanelColor,
                title = { Text("Kecepatan putar") },
                text = {
                    Column {
                        listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f).forEach { v ->
                            Row(
                                Modifier.fillMaxWidth().clickable { speed = v; player?.setPlaybackSpeed(v); dialog = 0 }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = speed == v, onClick = { speed = v; player?.setPlaybackSpeed(v); dialog = 0 })
                                Text(if (v == 1f) "Normal (1x)" else "${v}x")
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = 0 }) { Text("Tutup") } }
            )
            4 -> AlertDialog(
                onDismissRequest = { dialog = 0 },
                containerColor = PanelColor,
                title = { Text("Hapus video?") },
                text = { Text("\"$title\" akan dihapus dari perangkat dan tidak bisa dikembalikan.") },
                confirmButton = { TextButton(onClick = { dialog = 0; requestDelete() }) { Text("Hapus") } },
                dismissButton = { TextButton(onClick = { dialog = 0 }) { Text("Batal") } }
            )
        }
    }
}
