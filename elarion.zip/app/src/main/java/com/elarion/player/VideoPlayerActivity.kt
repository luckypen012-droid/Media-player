package com.elarion.player

import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class VideoPlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private var key = ""
    private lateinit var detector: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: run { finish(); return }
        key = "pos_$uri"

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        view = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
        }
        setContentView(view)

        // Dobel tap kiri = mundur 10 detik, kanan = maju 10 detik
        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val delta = if (e.x < view.width / 2) -10_000L else 10_000L
                val max = if (p.duration > 0) p.duration else Long.MAX_VALUE
                p.seekTo((p.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::detector.isInitialized) detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        val uri = intent.data ?: return
        val p = ExoPlayer.Builder(this).build()
        view.player = p
        p.setMediaItem(MediaItem.fromUri(uri))
        val saved = getSharedPreferences("elarion", MODE_PRIVATE).getLong(key, 0L)
        if (saved > 0) p.seekTo(saved)   // lanjut dari posisi terakhir
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    override fun onStop() {
        player?.let { p ->
            val prefs = getSharedPreferences("elarion", MODE_PRIVATE).edit()
            val nearEnd = p.duration > 0 && p.currentPosition > p.duration - 3000
            if (nearEnd) prefs.remove(key) else prefs.putLong(key, p.currentPosition)
            prefs.apply()
            view.player = null
            p.release()
        }
        player = null
        super.onStop()
    }
}
